/*
 * DBC - Database Control Utility
 * DB move functions
 *
 * Author: Alexander S.Kresin <alex@kresin.ru>
 *         www - http://www.kresin.ru/
 * Released to Public Domain
*/

#include "deflist.ch"
#include "dbc.ch"

MEMVAR aFiles

STATIC cLocate := "", cFilter := "", cSeek := ""

FUNCTION F_LOCATE

   LOCAL nrec, i, block, res := .F.

   cLocate := hu_Get( aMsg[64], , cLocate )

   IF !Empty( cLocate )
      IF Type( cLocate ) $ "UEUI"
         MsgSay( aMsg[ 4 ] )
         RETURN 0
      ENDIF
      IF ValType( &cLocate ) == "L"
         nrec := RecNo()
         MsgInf( "���� ..." )
         block := &( "{||" + iif( lWinChar, DosToWin( cLocate ), cLocate ) + "}" )
         IF LI_PRFLT
            FOR i := 1 TO LI_KOLZ
               FGOTO( mslist, i )
               IF Eval( block )
                  res := .T.
                  EXIT
               ENDIF
            NEXT
            IF !res .AND. i < LI_KOLZ
               SKIP
               DO WHILE !Eof()
                  IF Eval( block )
                     res := .T.
                     EXIT
                  ENDIF
                  i ++
                  SKIP
               ENDDO
            ENDIF
         ELSE
            __dbLocate( block, , , , .F. )
         ENDIF
         IF ( LI_PRFLT .AND. !res ) .OR. ( !LI_PRFLT .AND. ! Found() )
            GO nrec
            MsgInf( aMsg[63] )
         ELSE
            Msginf( aMsg[8] )
            IF LI_PRFLT
               LI_TEKZP := i
            ENDIF
         ENDIF
      ELSE
         MsgSay( aMsg[4] )
      ENDIF
   ENDIF

   RETURN 0

FUNCTION F_CONTIN

   LOCAL nrec, i, block, res := .F.

   MsgInf( aMsg[7] )
   nrec := RecNo()
   IF LI_PRFLT
      block := &( "{||" + iif( lWinChar, DosToWin( cLocate ), cLocate ) + "}" )
      FOR i := LI_TEKZP + 1 TO LI_KOLZ
         FGOTO( mslist, i )
         IF Eval( block )
            res := .T.
            EXIT
         ENDIF
      NEXT
      IF !res .AND. i < LI_KOLZ
         SKIP
         DO WHILE !Eof()
            IF Eval( block )
               res := .T.
               EXIT
            ENDIF
            i ++
            SKIP
         ENDDO
      ENDIF
   ELSE
      CONTINUE
   ENDIF
   IF ( LI_PRFLT .AND. !res ) .OR. ( !LI_PRFLT .AND. ! Found() )
      GO nrec
      MsgInf( aMsg[63] )
   ELSE
      Msginf( aMsg[8] )
      IF LI_PRFLT
         LI_TEKZP := i
      ENDIF
   ENDIF

   RETURN Nil

FUNCTION F_FILTER( strfnd )

   LOCAL nrec

   IF strfnd == Nil
      cFilter := hu_Get( aMsg[65], , cFilter )
   ELSE
      cFilter := strfnd
   ENDIF
   IF !Empty( cFilter ) .AND. !( Type( cFilter ) $ "UEUI" )
      IF ValType( &cFilter ) == "L"
         nrec := RecNo()
         MsgInf( aMsg[7] )
         IF lWinChar
            dbSetFilter( &( "{||" + DosToWin( cFilter ) + "}" ), DosToWin( cFilter ) )
         ELSE
            dbSetFilter( &( "{||" + cFilter + "}" ), cFilter )
         ENDIF
         GO TOP
         LI_KOLZ := 0
         carr_Init( @LI_CARR, 512 )
         DO WHILE !Eof()
            LI_KOLZ ++
            carr_Put( @LI_CARR, RecNo(), LI_KOLZ )
            IF Inkey() = 27
               LI_KOLZ := 0
               EXIT
            ENDIF
            SKIP
         ENDDO
         LI_TEKZP := 1
         IF LI_KOLZ > 0
            FGOTO( mslist, 1 )
            LI_PRFLT := .T.
            MsgInf( aMsg[8] )
         ELSE
            LI_PRFLT := .F.
            SET FILTER TO
            GO nrec
            MsgInf( aMsg[63] )
         ENDIF
      ELSE
         MsgSay( aMsg[4] )
      ENDIF
   ELSEIF LastKey() <> 27
      LI_PRFLT := .F.
      SET FILTER TO
      MsgInf( aMsg[66] )
      IF !Empty( cFilter )
         MsgSay( aMsg[ 4 ] )
      ENDIF
   ENDIF

   RETURN Nil

FUNCTION F_SEEK

   LOCAL KEY

   cSeek := hu_Get( aMsg[67], , cSeek )
   IF ! Empty( cSeek )
      nrec := RecNo()
      IF Type( OrdKey() ) = "N"
         key := Val( cSeek )
      ELSEIF Type( OrdKey() ) = "D"
         key := CToD( Trim( cSeek ) )
      ELSEIF lWinChar
         key := DosToWin( cSeek )
      ELSE
         key := cSeek
      ENDIF
      SEEK KEY
      IF ! Found()
         GO nrec
         MsgSay( aMsg[63] )
      ENDIF
   ENDIF

   RETURN Nil

FUNCTION F_GO

   strfnd := hu_Get( aMsg[68], "999999999" )
   IF ( nrec := Val( strfnd ) ) <> 0
      GO nrec
   ENDIF

   RETURN Nil
