#!/bin/bash

# Dando permissões totais a porta
sudo chmod 777 /dev/ttyA*

# Copiando o filtro para o diretório de filtros do cups
sudo cp DARUMACupsFilter /usr/lib/cups/filter/

# Dando permissão de execução para o filtro
sudo chmod +x /usr/lib/cups/filter/DARUMACupsFilter
sudo chmod 655 /usr/lib/cups/filter/DARUMACupsFilter

# Usar sed para inserir a linha antes da linha específica
sudo sed -i '/\/dev\/ttyS\* rw,/i \  /dev/ttyA* rw,' /etc/apparmor.d/usr.sbin.cupsd

# Verificar se a operação foi bem-sucedida
if [ $? -eq 0 ]; then
    echo "Linha adicionada com sucesso."
else
    echo "Ocorreu um erro ao adicionar a linha."
fi

# Restart no server cups
sudo /etc/init.d/cups restart
