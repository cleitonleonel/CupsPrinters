#!/bin/bash
#                   M  H      DIAS       DIRETÓRIO          COMANDO                SAÍDA
(crontab -l ; echo "0 12,18 * 1-5 cd ~/path/backupy && sudo python3 main.py > /tmp/output.log queue:work") | sort - | uniq - | crontab -
