/*
 * DBC - Database Control Utility
 * Menu functions
 *
 * Author: Alexander S.Kresin <alex@kresin.ru>
 *         www - http://www.kresin.ru/
 * Released to Public Domain
*/

#include "color.ch"
#include "inkey.ch"
MEMVAR mwidth, horiz
/*
 �᫨ ����� ������, �����頥� 0 ��� ����� ��࠭���� �������.
 �᫨ ����� ������ ���: (�ࠢ��) - 0,
 (�����) - �᫨ ����� �� �������, � ����� ��࠭���� �������,
           �᫨ ���� � ��� ����.�㭪樨 - 501,
           �᫨ ���� ����.�㭪�� - 0,����� ��࠭���� �������, ���
           >1000 (��।-�� ����.�㭪樥�)
*/

FUNCTION MainMenu( y1, x1, y2, x2, aMenu, aDostup, bUserF, choic, level, menu_len, prenter )

LOCAL laSimple
LOCAL ykoor, xkoor
LOCAL i, j, xm, ym, res, oldcurs, box_len, fitem := 1, delta, key, nind
PRIVATE mwidth, horiz
   choic    := Iif( choic = Nil .OR. choic > Len( aMenu ), 1, choic )
   level    := Iif( level = Nil, 0, level )
   menu_len := Iif( menu_len = Nil, Len( aMenu ), menu_len )
   box_len  := Iif( y1 <> Nil, Min( y2 - y1 + 1, menu_len ), menu_len )
   laSimple := ( Valtype( aMenu[ 1 ] ) <> "A" )
   IF laSimple .OR. Len( aMenu[ 1 ] ) < 3
      horiz := .F.
   ELSE
      horiz := ( aMenu[ 1, 3 ] == aMenu[ 2, 3 ] )
   ENDIF
   IF ! horiz
      IF x1 <> Nil
         mwidth := x2 - x1 + 1
      ELSE
         mwidth := 0
         FOR i := 1 TO menu_len
            mwidth := Max( mwidth, Len( aMenu[ i, 1 ] ) )
         NEXT
      ENDIF
   ENDIF
   oldcurs := Setcursor( 0 )
   DO WHILE choic <= menu_len .AND. ( ( aDostup <> Nil .AND. ! aDostup[ choic ] ) .OR. Asc( Iif( laSimple, aMenu[ choic ], aMenu[ choic, 1 ] ) ) = 196 )
      choic ++
   ENDDO
   IF box_len <> menu_len
      fitem := choic
   ENDIF
   OutMenu( aMenu, aDostup, y1, x1, y2, x2, fitem, menu_len )
   DO WHILE .T.
      IF laSimple .OR. Len( aMenu[ 1 ] ) < 3
         ykoor := y1 + choic - fitem
         xkoor := x1
      ELSE
         ykoor := aMenu[ choic - fitem + 1, 3 ]
         xkoor := aMenu[ choic - fitem + 1, 4 ]
      ENDIF
      IF choic <= menu_len .AND. choic > 0
         COLORSELECT( CLR_ENHANCED )
         IF horiz
            @ ykoor, xkoor SAY Iif( laSimple, aMenu[ choic ], aMenu[ choic, 1 ] )         
         ELSE
            @ ykoor, xkoor SAY Padr( Iif( laSimple, aMenu[ choic ], aMenu[ choic, 1 ] ), mwidth )         
         ENDIF
         COLORSELECT( CLR_STANDARD )
      ENDIF
#ifdef VER_MOUSE
      key := IN_KM( .F. )
#else
      key := Inkey( 0 )
#endif
      IF choic <= menu_len .AND. choic > 0
         IF horiz
            @ ykoor, xkoor SAY Iif( laSimple, aMenu[ choic ], aMenu[ choic, 1 ] )         
         ELSE
            @ ykoor, xkoor SAY Padr( Iif( laSimple, aMenu[ choic ], aMenu[ choic, 1 ] ), mwidth )         
         ENDIF
      ENDIF
      IF key < 500
         DO CASE
         CASE ( ! horiz .AND. key = K_UP ) .OR. ( horiz .AND. key = K_LEFT ) .OR. key = K_END
            IF key = K_END
               choic := menu_len + 1
            ENDIF
            IF choic <> fitem .OR. fitem > 1
               delta := 1
               choic --
               DO WHILE choic > 0 .AND. ( ( aDostup <> Nil .AND. ! aDostup[ choic ] ) .OR. Asc( Iif( laSimple, aMenu[ choic ], aMenu[ choic, 1 ] ) ) = 196 )
                  choic --
                  delta ++
               ENDDO
               IF choic = 0
                  choic += delta
                  delta := 0
               ENDIF
               IF key = K_END .AND. fitem <> choic - box_len + 1
                  fitem := choic - box_len + 1
                  OutMenu( aMenu, aDostup, y1, x1, y2, x2, fitem, menu_len )
               ELSEIF fitem > 1 .AND. choic - delta < fitem
                  fitem := choic
                  OutMenu( aMenu, aDostup, y1, x1, y2, x2, fitem, menu_len )
               ENDIF
            ENDIF
         CASE ( ! horiz .AND. key = K_DOWN ) .OR. ( horiz .AND. key = K_RIGHT ) .OR. key = K_HOME
            IF key = K_HOME
               choic := 0
            ENDIF
            IF choic <> fitem + box_len - 1 .OR. ( box_len <> menu_len .AND. choic < menu_len )
               delta := 1
               choic ++
               DO WHILE choic <= menu_len .AND. ( ( aDostup <> Nil .AND. ! aDostup[ choic ] ) .OR. Asc( Iif( laSimple, aMenu[ choic ], aMenu[ choic, 1 ] ) ) = 196 )
                  choic ++
                  delta ++
               ENDDO
               IF choic > menu_len
                  choic -= delta
                  delta := 0
               ENDIF
               IF key = K_HOME .AND. fitem <> choic
                  fitem := choic
                  OutMenu( aMenu, aDostup, y1, x1, y2, x2, fitem, menu_len )
               ELSEIF box_len <> menu_len .AND. choic - fitem + 1 > box_len
                  fitem := choic - box_len + 1
                  OutMenu( aMenu, aDostup, y1, x1, y2, x2, fitem, menu_len )
               ENDIF
            ENDIF
         CASE key = K_PGDN .AND. ! horiz .AND. menu_len > fitem + box_len - 1
            fitem += box_len - 1
            IF fitem > menu_len - box_len + 1
               fitem := menu_len - box_len + 1
            ENDIF
            choic := fitem
            OutMenu( aMenu, aDostup, y1, x1, y2, x2, fitem, menu_len )
         CASE key = K_PGUP .AND. ! horiz .AND. choic > 1
            IF choic > fitem
               choic := fitem
            ELSE
               fitem := Iif( fitem >= box_len, fitem - box_len + 1, 1 )
               choic := fitem
               OutMenu( aMenu, aDostup, y1, x1, y2, x2, fitem, menu_len )
            ENDIF
         CASE key = K_ESC
            res := 0
            EXIT
         CASE ! horiz .AND. level > 0 .AND. key = K_LEFT
            res := 0
            KEYBOARD Chr( K_LEFT ) + Chr( K_ENTER )
            EXIT
         CASE ! horiz .AND. level > 0 .AND. key = K_RIGHT
            res := 0
            KEYBOARD Chr( K_RIGHT ) + Chr( K_ENTER )
            EXIT
         CASE key = K_ENTER .OR. ( key >= 49 .AND. key <= 57 )
            IF key >= 49
               res := key - 48
            ELSE
               res := choic
            ENDIF
            COLORSELECT( CLR_ENHANCED )
            IF choic <= Len( aMenu )
               IF horiz
                  @ ykoor, xkoor SAY Iif( laSimple, aMenu[ choic ], aMenu[ choic, 1 ] )
               ELSE
                  @ ykoor, xkoor SAY Padr( Iif( laSimple, aMenu[ choic ], aMenu[ choic, 1 ] ), mwidth )
               ENDIF
            ENDIF
            EXIT
         OTHERWISE
            IF Ascan( { K_DOWN, K_UP, K_RIGHT, K_LEFT, K_HOME, K_END, K_PGDN, K_PGUP }, key ) == 0
               IF bUserf <> Nil
                  nind := choic
                  res  := Eval( bUserf, nind, key )
                  IF res < 2
                     res := Iif( res == 0, 0, res )
                     EXIT
                  ELSEIF res == 2
                     res := choic
                     EXIT
                  ELSE
                     EXIT
                  ENDIF
               ENDIF
            ENDIF
         ENDCASE
#ifdef VER_MOUSE
      ELSE
         IF key = 502
            DO WHILE M_STAT() <> 0
            ENDDO
            res := 0
            EXIT
         ELSEIF key = 501
            ym := M_YTEXT()
            xm := M_XTEXT()
            i  := F_CTRL( aMenu, aDostup, y1, x1, y2, x2, fitem, ym, xm )
            IF i <> 0 .AND. ( aDostup = Nil .OR. aDostup[ i ] )
               IF i = choic
                  res := choic
                  EXIT
               ELSE
                  res := choic := i
                  IF prenter = Nil .OR. ! prenter
                     EXIT
                  ENDIF
               ENDIF
            ELSEIF i = 0 .AND. ! horiz .AND. box_len < menu_len .AND. xm >= x1 .AND. xm <= x2 .AND. ( ym = y2 + 1 .OR. ym = y1 - 1 )
               IF ym = y2 + 1
                  DO WHILE M_STAT() <> 0 .AND. M_YTEXT() = ym .AND. fitem < menu_len - box_len + 1
                     fitem ++
                     OutMenu( aMenu, aDostup, y1, x1, y2, x2, fitem, menu_len )
                     M_SHOW()
                     j := Seconds()
                     DO WHILE Seconds() - j < 0.1
                     ENDDO
                     M_HIDE()
                  ENDDO
                  choic := fitem
               ELSEIF ym = y1 - 1
                  DO WHILE M_STAT() <> 0 .AND. M_YTEXT() = ym .AND. fitem > 1
                     fitem --
                     OutMenu( aMenu, aDostup, y1, x1, y2, x2, fitem, menu_len )
                     M_SHOW()
                     j := Seconds()
                     DO WHILE Seconds() - j < 0.1
                     ENDDO
                     M_HIDE()
                  ENDDO
                  choic := fitem
               ENDIF
            ELSE
               M_SHOW()
               DO WHILE M_STAT() <> 0
               ENDDO
               M_HIDE()
               IF bUserf = Nil
                  res := 501
                  EXIT
               ELSE
                  nind := choic
                  res  := Eval( bUserf, nind, key )
                  IF res < 2
                     res := Iif( res = 0, 0, res )
                     EXIT
                  ELSEIF res = 2
                  ELSE
                     EXIT
                  ENDIF
               ENDIF
            ENDIF
         ENDIF
#endif
      ENDIF
   ENDDO
   Setcursor( oldcurs )
   COLORSELECT( CLR_STANDARD )
RETURN res

FUNCTION OutMenu( aMenu, aDostup, y1, x1, y2, x2, choic, menu_len )

LOCAL i, ykoor, xkoor, laSimple, stmp
   laSimple := ( Valtype( aMenu[ 1 ] ) <> "A" )
   choic    := Iif( choic = Nil, 1, choic )
   menu_len := Iif( menu_len = Nil, Len( aMenu ), menu_len )
   FOR i := choic TO menu_len
      IF laSimple .OR. Len( aMenu[ 1 ] ) < 3
         ykoor := y1 + i - choic
         xkoor := x1
      ELSE
         ykoor := aMenu[ i + choic - 1, 3 ]
         xkoor := aMenu[ i + choic - 1, 4 ]
      ENDIF
      IF y2 <> Nil .AND. ykoor > y2
         EXIT
      ENDIF
      IF aDostup <> Nil
         IF ! aDostup[ i ]
            COLORSELECT( CLR_UNSELECTED )
         ELSE
            COLORSELECT( CLR_STANDARD )
         ENDIF
      ENDIF
      stmp := Iif( laSimple, aMenu[ i ], aMenu[ i, 1 ] )
      IF stmp = '�'
         stmp := Replicate( '�', mwidth )
      ENDIF
      IF horiz
         @ ykoor, xkoor SAY stmp         
      ELSE
         @ ykoor, xkoor SAY Padr( stmp, mwidth )         
      ENDIF
   NEXT
   RETURN Nil

#ifdef VER_MOUSE

FUNCTION F_CTRL( mctrl, aDostup, y1, x1, y2, x2, fitem, ym, xm )

LOCAL i, mlen, xkoor, ykoor, bufc, laSimple, ilen
   laSimple := ( Valtype( mctrl[ 1 ] ) <> "A" )
   mlen     := Len( mctrl )
   mlen     := Iif( y1 <> Nil, Min( y2 - y1 + 1, mlen ), mlen )
   FOR i := 1 TO mlen
      IF laSimple .OR. Len( mctrl[ 1 ] ) < 3
         ykoor := y1 + i - 1
         xkoor := x1
         ilen  := x2 - x1 + 1
      ELSE
         ykoor := mctrl[ i + fitem - 1, 3 ]
         xkoor := mctrl[ i + fitem - 1, 4 ]
         IF Len( mctrl[ i ] ) = 6
            ilen := 0
         ELSE
            ilen := Len( mctrl[ i + fitem - 1, 1 ] )
         ENDIF
      ENDIF
      IF ( ( ilen = 0 .AND. ym <= mctrl[ i + fitem - 1, 5 ] .AND. ym >= ykoor .AND. xm >= xkoor .AND. xm < mctrl[ i + fitem - 1, 6 ] ) .OR. ;
             ( ilen <> 0 .AND. ym = ykoor .AND. xm >= xkoor .AND. xm < xkoor + ilen ) ) ;
             .AND. ( aDostup = Nil .OR. aDostup[ i + fitem - 1 ] )
         IF ilen > 0
            COLORSELECT( CLR_ENHANCED )
            @ ykoor, xkoor SAY Padr( Iif( laSimple, mctrl[ i + fitem - 1 ], mctrl[ i + fitem - 1, 1 ] ), ilen )         
            COLORSELECT( CLR_STANDARD )
         ENDIF
         M_SHOW()
         DO WHILE M_STAT() <> 0
         ENDDO
         M_HIDE()
         EXIT
      ENDIF
   NEXT
RETURN Iif( i > mlen, 0, i + fitem - 1 )

FUNCTION IN_KM( w_0 )

LOCAL rez, mstat
   IF Type( "is_mpresent" ) <> "L"
PUBLIC is_mpresent := ( M_INIT() <> 0 )
   ENDIF
   IF is_mpresent
      M_SHOW()
   ENDIF
   DO WHILE .T.
      IF ( rez := Inkey() ) <> 0
         EXIT
      ENDIF
      IF is_mpresent .AND. ( mstat := M_STAT() ) <> 0
         IF w_0 = Nil .OR. w_0
            DO WHILE M_STAT() <> 0
            ENDDO
         ENDIF
         rez := mstat + 500
         EXIT
      ENDIF
   ENDDO
   IF is_mpresent
      M_HIDE()
   ENDIF
RETURN rez

FUNCTION M_XTEXT

RETURN M_XPOS() / 8

FUNCTION M_YTEXT

   RETURN M_YPOS() / 8
#endif

