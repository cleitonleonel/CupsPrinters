#!/bin/sh
if ! [ -e o ]; then
   mkdir o
   chmod a+w+r+x o
fi

rm -f o/*.c
rm -f o/*.o
rm -f _a1.log
rm -f _a2.log
if [ -n "$1" ]; then
  if [ $1 = "clean" ]; then
     rm -f dbc
  fi     
else
  make -f Makefile >_a1.log 2>_a2.log
fi    
