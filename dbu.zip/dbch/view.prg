/*
 * DBC - Database Control Utility
 * Views
 *
 * Author: Alexander S.Kresin <alex@kresin.ru>
 *         www - http://www.kresin.ru/
 * Released to Public Domain
*/

#ifdef RDD_ADS
#include "ads.ch"
#endif
#include "deflist.ch"
#include "dbc.ch"
#include "fileio.ch"

MEMVAR aFiles, numdriv, mypath, aMsg, improc, prkorf, prkorst, lShared, lRdonly

STATIC crlf := e"\r\n"

FUNCTION RdView( fname )

   LOCAL aLines, nLine, nPos
   LOCAL cPath := mypath
   LOCAL scom, sword, i, n
   LOCAL aRel := {}, aFlt := {}
   PRIVATE mslist

   mypath := ""
   IF !Empty( fname ) .AND. !Empty( aLines := hb_aTokens( MemoRead( fname ), crlf  ) )
      FOR nLine := 1 TO Len( aLines )
         nPos := 0
         IF ( scom := Upper( hb_TokenPtr( aLines[nLine], @nPos, " " ) ) ) == "DRIVER"
            IF Empty( sword := hb_TokenPtr( aLines[nLine], @nPos, " " ) )
               MsgSay( aMsg[11] )
               mypath := cPath
               RETURN Nil
            ELSE
               IF hb_TokenPtr( aLines[nLine], @nPos, " " ) == "REMOTE"
#if defined( RDD_ADS )
                  AdsSetServerType( 6 )
#elif !defined( RDD_LETO )
                  res := .F.
                  EXIT
#endif
               ELSE
                  nServerType := LOCAL_SERVER
#if defined( RDD_ADS )
                  AdsSetServerType( ADS_LOCAL_SERVER )
#elif defined( RDD_LETO )
                  res := .F.
                  EXIT
#endif
               ENDIF

               IF ( n := ASCAN( aDrivers, sword ) ) == 0
                  MsgSay( aMsg[10] )
                  mypath := cPath
                  RETURN Nil
               ELSE
                  numdriv := n
#if defined( RDD_ADS )
                  AdsSetFileType( Iif( n == 1,2,Iif( n == 2,1,3 ) ) )
#elif !defined( RDD_LETO )
                  rddSetDefault( aDrivers[n] )
#endif
               ENDIF
            ENDIF
         ELSEIF scom == "FILE"
            lShared := ( hb_TokenPtr( aLines[nLine], @nPos, " " ) == "SHARED" )
            Set( _SET_EXCLUSIVE, !lShared )
            lRdonly := ( hb_TokenPtr( aLines[nLine], @nPos, " " ) == "READ" )
            IF Empty( sword := LTrim( SubStr( aLines[nLine], nPos + 1 ) ) )
               MsgSay( aMsg[12] )
               mypath := cPath
               RETURN Nil
            ELSE
               fdbopen( sword, , .T. )
               IF numdriv > 1
                  numdriv := 1
                  rddSetDefault( aDrivers[ 1 ] )
               ENDIF
            ENDIF
         ELSEIF scom == "ORDER"
            IF !Empty( sword := LTrim( SubStr( aLines[nLine], nPos + 1 ) ) )
               OrdSetFocus( sword )
            ENDIF
         ELSEIF scom = "FILTER"
            AAdd( aFlt, { improc, LTrim( SubStr( aLines[nLine], nPos + 1 ) ) } )
         ELSEIF scom == "RELATION"
            sword := hb_TokenPtr( aLines[nLine], @nPos, " " )
            AAdd( aRel, { improc, sword, LTrim( SubStr( aLines[nLine], nPos + 1 ) ) } )
         ENDIF
      NEXT

      FOR i := 1 TO Len( aRel )
         SELECT( aRel[ i, 1 ] )
         dbSetRelation( aRel[i,2], &( "{||" + aRel[i,3] + "}" ), aRel[i,3] )
      NEXT

      FOR i := 1 TO Len( aFlt )
         SELECT( improc := aFlt[ i, 1 ] )
         mslist := aFiles[ improc,AF_BRW ]
         F_FILTER( aFlt[ i, 2 ] )
      NEXT

      prkorf  := .T.
      prkorst := .F.
   ELSE
      MsgSay( aMsg[1] + fname )
   ENDIF
   mypath := cPath

   RETURN Nil

FUNCTION WrView( fname )

   LOCAL i, han, j, strlen, cTmp, obl := Select()

   IF ( han := FCreate( fname, FC_NORMAL ) ) != - 1
      FOR i := 1 TO lenmsf
         IF !Empty( aFiles[i,AF_NAME] )
            dbSelectArea( aFiles[i,AF_ALIAS] )
            FWrite( han, "DRIVER " +  aDrivers[ aFiles[ improc,AF_DRIVER ] ] +  ;
               iif( nServerType == LOCAL_SERVER, " LOCAL", " REMOTE" ) + crlf )

            FWrite( han, "FILE " + Iif(aFiles[i,AF_EXCLU],"EXCLUSIVE ","SHARED ") + ;
                  Iif(aFiles[i,AF_RDONLY],"READ ","WRITE ") + ;
                  aFiles[i,AF_NAME] + crlf )

            IF !Empty( cTmp := OrdSetFocus() )
               FWrite( han, "ORDER " + cTmp + crlf )
            ENDIF

            IF !Empty( cTmp := dbFilter() )
               FWrite( han, "FILTER " + cTmp + crlf )
            ENDIF

            j := 0
            DO WHILE !Empty( cTmp := dbRelation( ++ j ) )
               FWrite( han, "RELATION " + Alias( dbRSelect( j ) ) + " " + cTmp + crlf )
            ENDDO
         ENDIF
      NEXT
      FClose( han )
   ELSE
      MsgSay( aMsg[9] + fname )
   ENDIF
   SELECT( obl )

   RETURN Nil
