#!/bin/bash

# Dando permissões totais a porta
sudo chmod 777 /dev/ttyA*

# Copiando o filtro para o diretório de filtros do cups
sudo cp DARUMACupsFilter /usr/lib/cups/filter/

# Dando permissão de execução para o filtro
sudo chmod +x /usr/lib/cups/filter/DARUMACupsFilter

# sudo nano /etc/apparmor.d/usr.sbin.cupsd
# Definir o arquivo a ser editado
file_to_edit="/etc/apparmor.d/usr.sbin.cupsd"

# Definir a linha a ser adicionada
line_to_add="  /dev/ttyA* rw,"

# Definir a linha após a qual queremos adicionar a nova linha
line_to_match="/dev/ttyS* rw,"

# Usar sed para inserir a linha antes da linha específica
sed -i "/${line_to_match}/i ${line_to_add}" "${file_to_edit}"

# Verificar se a operação foi bem-sucedida
if [ $? -eq 0 ]; then
    echo "Linha adicionada com sucesso em ${file_to_edit}."
else
    echo "Ocorreu um erro ao adicionar a linha em ${file_to_edit}."
fi

# Restart no server cups
sudo /etc/init.d/cups restart
