/*
 * Common procedures
 * Db browse ( use with dbflist, procs1.prg )
 *
 * Author: Alexander S.Kresin <alex@kresin.ru>
 *         www - http://www.kresin.ru/
 * Released to Public Domain
*/

#include "fileio.ch"
#include "deflist.ch"

#define MSLIST_LENGTH  1024
#define CARR_LENGTH     512

FUNCTION InitList

LOCAL mslist := Array( LI_LEN )
   LI_NSTR      := LI_MSED := 1
   LI_CLR       := "W+/B"
   LI_CLRV      := LI_CLRV2 := "R/W"
   LI_CLRMSK    := "GR+/N"
   LI_BSKIP     := { | a, x | FSKIP( a, x ) }
   LI_BGTOP     := { | a | FGOTOP( a ) }
   LI_BGBOT     := { | a | FGOBOT( a ) }
   LI_BEOF      := { | a | FEOF( a ) }
   LI_BBOF      := { | a | FBOF( a ) }
   LI_B1        := { | a | Devpos( LI_Y2, LI_X1 + 2 ), Devoutpict( Iif( LI_PRFLT, "������" + Str( LI_TEKZP, 5 ), Str( Recno(), 6 ) ) + "/" + Str( LI_KOLZ, 6 ) ) }
   LI_FREEZE    := 0
   LI_RCOU      := { || Reccount() }
   LI_RECNO     := { || Recno() }
   LI_BGOTO     := { | a, n | Dbgoto( n ) }
   LI_PRFLT     := LI_LVIEW := LI_LADD := LI_UPDATED := .F.
   LI_LSOHR     := .T.
   LI_BDESHIN   := LI_BDESHOUT := LI_MSF := LI_MSTYP := LI_MSREC := LI_CARR := Nil
   LI_TEKZP     := 1
   LI_SEPARATOR := " "
RETURN mslist

FUNCTION FGOTOP( mslist )

   IF LI_PRFLT
      IF LI_KOLZ > 0
         LI_TEKZP := 1
         GO Iif( LI_CARR == Nil, LI_MSREC[ 1 ], carr_Get( LI_CARR, 1 ) )
      ENDIF
   ELSE
      GO TOP
   ENDIF
RETURN Nil

FUNCTION FGOTO( mslist, nRec )

   IF LI_PRFLT
      IF LI_KOLZ >= nRec .AND. nRec > 0
         GO Iif( LI_CARR == Nil, LI_MSREC[ nRec ], carr_Get( LI_CARR, nRec ) )
      ENDIF
   ELSE
      GO nRec
   ENDIF
RETURN Nil

FUNCTION FGOBOT( mslist )

   IF LI_PRFLT
      LI_TEKZP := LI_KOLZ
      GO Iif( LI_CARR == Nil, ;
              Iif( LI_KOLZ < MSLIST_LENGTH, LI_MSREC[ LI_KOLZ ], LI_MSREC[ MSLIST_LENGTH ] ), ;
              carr_Get( LI_CARR, LI_KOLZ ) )
   ELSE
      GO BOTTOM
   ENDIF
RETURN Nil

PROCEDURE FSKIP( mslist, kolskip )

LOCAL tekzp1

   IF LI_PRFLT
      IF LI_KOLZ == 0
         RETURN
      ENDIF
      tekzp1   := LI_TEKZP
      LI_TEKZP := LI_TEKZP + kolskip + Iif( tekzp1 = 0, 1, 0 )
      IF LI_TEKZP < 1
         LI_TEKZP := 0
         GO Iif( LI_CARR == Nil, LI_MSREC[ 1 ], carr_Get( LI_CARR, 1 ) )

      ELSEIF LI_TEKZP > LI_KOLZ
         LI_TEKZP := LI_KOLZ + 1
         GO Iif( LI_CARR == Nil, ;
                 Iif( LI_KOLZ < MSLIST_LENGTH, LI_MSREC[ LI_KOLZ ], LI_MSREC[ MSLIST_LENGTH ] ), ;
                 carr_Get( LI_CARR, LI_KOLZ ) )

      ELSE
         IF LI_CARR == Nil .AND. LI_TEKZP > MSLIST_LENGTH - 1
            SKIP Iif( tekzp1 = LI_KOLZ + 1, kolskip + 1, kolskip )
         ELSE
            GO Iif( LI_CARR == Nil, LI_MSREC[ LI_TEKZP ], carr_Get( LI_CARR, LI_TEKZP ) )
         ENDIF
      ENDIF
   ELSE
      SKIP kolskip
   ENDIF
RETURN

FUNCTION FBOF( mslist )

   IF LI_PRFLT
      RETURN Iif( LI_TEKZP = 0, .T., .F. )
   ENDIF
RETURN Bof()

FUNCTION FEOF( mslist )

   IF LI_PRFLT
      RETURN Iif( LI_TEKZP > LI_KOLZ, .T., .F. )
   ENDIF
RETURN Eof()

PROCEDURE FLMSFLD( mspic, lValue, maxlen )

LOCAL i, varname, mslen := Fcount()

   FOR i := 1 TO mslen
      varname := "GET" + Padl( i, 2, "0" )
      IF dbFieldInfo( 2, i ) != "M"
         &varname := Iif( lValue, Fieldget( i ), Empvar( i ) )
      ELSE
         &varname := Nil
      ENDIF
      IF mspic <> Nil
         mspic[ i ] := Defpict( i, maxlen )
      ENDIF
   NEXT
RETURN

FUNCTION Defpict( i, maxlen )

LOCAL spict, fldd, fldtype := dbFieldInfo( 2, i ), fldlen := dbFieldInfo( 3, i )

   DO CASE
   CASE fldtype == "C"
      spict := Iif( maxlen = Nil, Replicate( "X", fldlen ), "@S" + Padl( maxlen, 2, "0" ) )
   CASE fldtype == "N"
      fldd := dbFieldInfo( 4, i )
      spict := Iif( fldd = 0, Replicate( "9", fldlen ), Replicate( "9", fldlen - 1 - fldd ) + "." + Replicate( "9", fldd ) )
   CASE fldtype == "D"
      spict := "@D"
   CASE fldtype $ "T=@"
      spict := Iif( fldlen==4, "@T", Nil )
   ENDCASE
RETURN spict

FUNCTION EMPVAR( numf )

LOCAL rez, fldtype := dbFieldInfo( 2, numf )
   DO CASE
   CASE fldtype = "C"
      rez := Space( dbFieldInfo( 3, numf ) )
   CASE fldtype = "N"
      rez := 0
   CASE fldtype = "D"
      rez := Ctod( Space( 8 ) )
   CASE fldtype = "L"
      rez := .F.
   ENDCASE
RETURN rez

FUNCTION FLDS( numf, znch, pr )

LOCAL fldtype, rez
   fldtype := dbFieldInfo( 2, numf )
   DO CASE
   CASE fldtype = "C"
      rez := '"' + Rtrim( znch ) + '"'
   CASE fldtype = "N"
      rez := Ltrim( Str( znch, dbFieldInfo( 3, numf ), dbFieldInfo( 4, numf ) ) )
   CASE fldtype = "D"
      IF pr
         rez := 'STOD("' + Dtos( znch ) + '")'
      ELSE
         rez := Dtoc( znch )
      ENDIF
   CASE fldtype = "L"
      rez := Iif( znch, '".T."', '".F."' )
   ENDCASE
RETURN rez
