#define AF_LEN                7
#define AF_NAME               1
#define AF_EXCLU              2
#define AF_RDONLY             3
#define AF_DRIVER             4
#define AF_ALIAS              5
#define AF_FLD                6
#define AF_BRW                7

#define N_MAX_FILES          15

#define LOCAL_SERVER          1
#define REMOTE_SERVER         2
