/*
 * DBC - Database Control Utility
 * SQL queries implementation
 *
 * Author: Alexander S.Kresin <alex@kresin.ru>
 *         www - http://www.kresin.ru/
 * Released to Public Domain
*/

#ifdef RDD_ADS
#include "ads.ch"
#endif
#include "dbc.ch"
#include "fileio.ch"

MEMVAR aFiles

STATIC msquery, textquery[ 7 ], fileque, que_upd := .F.

FUNCTION OpenQuery( fname )

   LOCAL poz2, poz3, i
   LOCAL stroka, pos1, quebuf := "", sword

   IF que_upd
      IF MsgYesNo( aMsg[13] )
         WriteQuery()
      ENDIF
      que_upd := .F.
   ENDIF

   IF !Empty( stroka := Memoread( fname ) )
      Afill( textquery, "" )
      fileque := fname

      pos1 := 1
      DO WHILE ( sword := NextItem( stroka, @pos1, ' ' ) ) != Nil
         IF !Empty( sword )
            quebuf += Upper( sword ) + ' '
         ENDIF
      ENDDO
      IF ( pos1 := At( "SELECT ", quebuf ) ) = 0
         MsgSay( "? SELECT" )
         RETURN Nil
      ENDIF
      IF ( poz2 := At( "FROM ", quebuf ) ) = 0
         MsgSay( "? FROM" )
         RETURN Nil
      ENDIF
      textquery[ 1 ] := SubStr( quebuf, pos1 + 7, poz2 - pos1 - 8 )
      quebuf := SubStr( quebuf, poz2 + 5 )
      pos1   := At( "WHERE ", quebuf )
      poz2   := At( "GROUP BY ", quebuf )
      poz3   := At( "ORDER BY ", quebuf )
      IF pos1 = 0 .AND. poz2 = 0 .AND. poz3 = 0
         textquery[ 2 ] := quebuf
         RETURN Nil
      ENDIF
      textquery[ 2 ] := SubStr( quebuf, 1, Iif( pos1 <> 0, pos1, Iif( poz2 <> 0, poz2, poz3 ) ) - 1 )
      IF pos1 <> 0
         IF poz2 = 0 .AND. poz3 = 0
            textquery[ 3 ] = SubStr( quebuf, pos1 + 6 )
            RETURN Nil
         ENDIF
         textquery[ 3 ] = SubStr( quebuf, pos1 + 6, Iif( poz2 <> 0, poz2, poz3 ) - pos1 - 7 )
      ENDIF
      pos1 := poz2
      poz2 := At( "HAVING ", quebuf )
      IF pos1 <> 0
         IF poz2 = 0 .AND. poz3 = 0
            textquery[ 4 ] = SubStr( quebuf, pos1 + 9 )
            RETURN Nil
         ENDIF
         textquery[ 4 ] = SubStr( quebuf, pos1 + 9, Iif( poz2 <> 0, poz2, poz3 ) - pos1 - 10 )
      ENDIF
      IF poz2 <> 0
         IF poz3 = 0
            textquery[ 5 ] = SubStr( quebuf, poz2 + 7 )
            RETURN Nil
         ENDIF
         textquery[ 5 ] = SubStr( quebuf, poz2 + 7, poz3 - poz2 - 8 )
      ENDIF
      IF poz3 <> 0
         textquery[ 6 ] = SubStr( quebuf, poz3 + 9 )
      ENDIF
   ELSE
      MsgSay( aMsg[1] + fname )
      RETURN Nil
   ENDIF

   RETURN Nil

FUNCTION EditQuery

   LOCAL bufc, oldc, i, lkey, prupdt
   PRIVATE Ctrlist := { "+GR/B,+W/RB", { { aMsg[15], { || DoQuery() }, 19, 10 } } }
   PRIVATE GetList := {}

   bufsc := SaveScreen( 4, 3, 20, 76 )
   oldc  := Setcolor()
   SET COLOR TO + GR/B
   @  4,  3, 20, 76 BOX "�Ŀ����� "
   OutCtrls( Ctrlist )
   @  5,  5 SAY "SELECT"
   @  7,  5 SAY "FROM"
   @  8,  5 SAY "WHERE"
   @ 10,  5 SAY "GROUP BY"
   @ 11,  5 SAY "HAVING"
   @ 13,  5 SAY "ORDER BY"
   @ 14,  5 SAY "TO"
   SET COLOR TO + W/B, N/W, , , + W/B
   SET KEY - 4 TO DoQuery

   textquery[1] := Padr( textquery[1], 250 )
   textquery[2] := Padr( textquery[2], 120 )
   textquery[3] := Padr( textquery[3], 200 )
   textquery[4] := Padr( textquery[4], 50 )
   textquery[5] := Padr( textquery[5], 70 )
   textquery[6] := Padr( textquery[6], 40 )
   textquery[7] := Padr( textquery[7], 40 )

   @  6,  5 GET textquery[ 1 ] PICTURE "@S70"
   @  7, 14 GET textquery[ 2 ] PICTURE "@S70"
   @  9,  5 GET textquery[ 3 ] PICTURE "@S70"
   @ 10, 14 GET textquery[ 4 ] PICTURE Replicate( "X",50 )
   @ 12,  5 GET textquery[ 5 ] PICTURE Replicate( "X",70 )
   @ 13, 14 GET textquery[ 6 ] PICTURE Replicate( "X",40 )
   @ 14, 14 GET textquery[ 7 ] PICTURE Replicate( "X",40 )
   READ
   SET KEY - 4 TO
   IF Updated()
      que_upd := .T.
      IF LastKey() <> 27
         IF MsgYesNo( aMsg[13] )
            WriteQuery()
         ENDIF
      ENDIF
   ENDIF
   Setcolor( oldc )
   RestScreen( 4, 3, 20, 76, bufsc )
   SET KEY - 4 TO

   RETURN Nil

FUNCTION WriteQuery

   LOCAL han, fname

   IF textquery[ 1 ] != Nil
      fname := FileMan( quepath, "*.que", .T. )
      IF !Empty( fname )
         han := FCreate( fname, FC_NORMAL )
         FWrite( han, "SELECT " + Trim(textquery[1]) + Chr( 13 ) + Chr( 10 ) )
         FWrite( han, "FROM " + Trim(textquery[2]) + Chr( 13 ) + Chr( 10 ) )
         IF !Empty( textquery[ 3 ] )
            FWrite( han, "WHERE " + Trim(textquery[3]) + Chr( 13 ) + Chr( 10 ) )
         ENDIF
         IF !Empty( textquery[ 4 ] )
            FWrite( han, "GROUP BY " + Trim(textquery[4]) + Chr( 13 ) + Chr( 10 ) )
         ENDIF
         IF !Empty( textquery[ 5 ] )
            FWrite( han, "HAVING " + Trim(textquery[5]) + Chr( 13 ) + Chr( 10 ) )
         ENDIF
         IF !Empty( textquery[ 6 ] )
            FWrite( han, "ORDER BY " + Trim(textquery[6]) + Chr( 13 ) + Chr( 10 ) )
         ENDIF
         FClose( han )
         que_upd := .F.
      ENDIF
   ENDIF

   RETURN Nil

FUNCTION CreatQuery( lEdit )

   IF lEdit != Nil .AND. lEdit .AND. textquery[ 1 ] != Nil
      RETURN EditQuery()
   ENDIF
   IF que_upd
      IF MsgYesNo( aMsg[14] )
         WriteQuery()
         que_upd := .F.
      ENDIF
   ENDIF
   Afill( textquery, "" )
   fileque := Space( 8 )
   EditQuery()

   RETURN Nil

FUNCTION DoQuery()

   LOCAL sword, i, j, sw2, vartmp, ordexp := "", pragr := .F. , screc, startsec
   LOCAL groupexp, groupkey, groupbl, prbegin, msgr, nrec, ocher, msals, msqname := {}
   LOCAL distbl, qfname, stroka, poz1
   PRIVATE f_impr, f_usl := "", max_len, max_dec, msrelat := {}, msaccum

   msquery := Array( 6 )
   // ���� �� SELECT - � ���ᨢ msquery[1]
   stroka       := textquery[ 1 ]
   poz1         := 1
   msquery[ 1 ] := {}
   DO WHILE ( sword := NextItem( stroka, @poz1, ',' ) ) != Nil
      AAdd( msquery[ 1 ], Upper( LTrim( RTrim( sword ) ) ) )
   ENDDO
   // ����� �� FROM - � ���ᨢ msquery[2]
   stroka       := textquery[ 2 ]
   poz1         := 1
   msquery[ 2 ] := {}
   DO WHILE ( sword := NextItem( stroka, @poz1, ',' ) ) != Nil
      sword := Upper( LTrim( RTrim( sword ) ) )
      IF ( i := At( ' ', sword ) ) <> 0
         sw2   := SubStr( sword, i + 1 )
         sword := Left( sword, i - 1 )
      ELSE
         sw2 := sword
      ENDIF
      AAdd( msquery[ 2 ], { sword, sw2, Nil, Nil } )
   ENDDO
   // ���뢠�� 䠩�� ��� ������
   FOR i := 1 TO Len( msquery[ 2 ] )
      IF ( poz1 := Select( msquery[ 2, i, 2 ] ) ) = 0
         IF !fdbopen( msquery[ 2, i, 1 ], msquery[ 2, i, 2 ] )
            RETURN Nil
         ENDIF
      ELSE
         SELECT( poz1 )
      ENDIF
      IF i = 1
         f_impr := Select()
      ENDIF
      msquery[ 2, i, 4 ] := Select()
      msquery[ 2, i, 3 ] := dbStruct()
   NEXT
   // ��ࠡ�⪠ WHERE
   IF !Empty( textquery[ 3 ] )
      IF Empty( sword := AnaWhere( textquery[ 3 ] ) )
         RETURN Nil
      ELSE
         msquery[ 3 ] := sword
      ENDIF
   ENDIF
   // ��ࠡ�⪠ GROUP BY
   IF !Empty( textquery[ 4 ] )
      groupexp := MainInd( textquery[ 4 ] )
      groupbl  := &( "{||" + groupexp + "}" )
      msgr     := Array( Len( msquery[ 1 ] ) )
      AFill( msgr, .F. )
      IF !Empty( textquery[ 5 ] )       // Having
         IF Empty( sword := AnaHavi( RTrim( textquery[ 5 ] ) ) )
            RETURN Nil
         ELSE
            msquery[ 5 ] := &( "{||" + sword + "}" )
         ENDIF
      ELSE
         msquery[ 5 ] := { || .T. }
      ENDIF
   ENDIF
   IF ( i := IsAgr( msquery[ 1, 1 ] ) ) <> 0 .AND. groupbl = Nil
      // �᫨ ����訢����� ��ॣ�⭠� �㭪��
      sword := AllTrim( msquery[ 1, 1 ] )
      IF Empty( sword := ConvAgr( sword, i ) )
         RETURN Nil
      ENDIF
      msquery[ 1, 1 ] := &( "{|p3|" + sword + "}" )
      pragr           := .T.
   ELSE
      // �������� ��室���� 䠩��
      SELECT 20
      CREATE ( mypath + "Q0STRU" )
      FOR i := 1 TO Len( msquery[ 1 ] )
         APPEND BLANK
         sword := msquery[ 1, i ]
         IF SubStr( sword, 1, 8 ) = "DISTINCT"
            IF groupbl <> Nil
               MsgSay( aMsg[16] )
               RETURN Nil
            ENDIF
            sword    := SubStr( sword, 10 )
            groupexp := MainInd( sword )
            distbl   := &( "{||" + groupexp + "}" )
            SELECT 20
         ENDIF
         IF IsExp( sword ) <> 0
            // �᫨ � ᯨ᪥ ��ࠦ����
            max_len := max_dec := 0
            REPLACE Field_Name WITH "EXP_" + NUM_STR( i, 2 )
            sw2   := ""
            sword := AnalyzExp( AllTrim( sword ), @sw2 )
            IF ( j := IsAgr( sword ) ) <> 0
               msgr[ i ] = .T.
               IF Empty( sword := ConvAgr( sword, j ) )
                  RETURN Nil
               ENDIF
               REPLACE Field_Type WITH "N"
               IF j = 1
                  REPLACE Field_Len WITH 10, Field_Dec WITH 0
               ELSE
                  j   := At( "(", sword )
                  sw2 := SubStr( sw2, j + 1, Len( sw2 ) - j - 1 )
                  sw2 := RTrim( Transform( &sw2, "@B" ) )
                  j   := Max( Len( sw2 ), max_len ) + 1
                  REPLACE Field_Len WITH Iif( j > 18, 18, j )
                  j := At( '.', sw2 )
                  j := Iif( j = 0, 0, Len( sw2 ) - j )
                  REPLACE Field_Dec WITH Max( max_dec, j )
               ENDIF
            ELSE
               vartmp := &sw2
               sw2    := RTrim( Transform( vartmp, "@B" ) )
               REPLACE Field_Type WITH ValType( vartmp ), Field_Len WITH Max( Len( sw2 ), max_len )
               IF Field_Type = "C"
                  REPLACE Field_Dec WITH 0
               ELSE
                  j := At( '.', sw2 )
                  j := Iif( j = 0, 0, Len( sw2 ) - j )
                  REPLACE Field_Dec WITH Max( max_dec, j )
               ENDIF
            ENDIF
            sw2             := sword
            msquery[ 1, i ] := Iif( groupbl <> Nil .AND. msgr[ i ], &( "{|p3|" + sw2 + "}" ), ;
               &( "{||" + sw2 + "}" ) )
         ELSE
            // ���� (����)
            IF !FindFiel( @sword, @sw2, @poz1, @j )
               RETURN Nil
            ENDIF
            vartmp := sw2
            IF ASCAN( msqname, vartmp ) <> 0
               vartmp := Left( Chr( poz1 + 64 ) + "_" + vartmp, 10 )
               DO WHILE ASCAN( msqname, vartmp ) <> 0
                  vartmp := Left( "X" + vartmp, 10 )
               ENDDO
            ENDIF
            REPLACE Field_Name WITH vartmp, Field_Type WITH msquery[ 2, poz1, 3, j, 2 ], ;
               Field_Len WITH msquery[ 2, poz1, 3, j, 3 ], Field_Dec WITH msquery[ 2, poz1, 3, j, 4 ]
            msquery[ 1, i ] := &( "{||" + Iif( Empty( sword ), "", sword + '->' ) + sw2 + "}" )
            AAdd( msqname, vartmp )
         ENDIF
      NEXT
      USE
      qfname := CutExten( Iif( Empty( textquery[ 7 ] ), "QUERY", Trim( textquery[ 7 ] ) ) )
      IF ( i := ASCAN( aFiles, { |a|a[AF_NAME] = qfname }, 1, lenmsf ) ) != 0
         improc := i
         fdbclose()
         SELECT 20
      ENDIF
      CREATE ( mypath + qfname ) FROM ( mypath + "Q0STRU" )
      // FERASE( "Q0STRU.DBF" )
      // ��ࠡ�⪠ ORDER BY
      IF !Empty( textquery[ 6 ] )
         AAdd( msquery[ 2 ], { qfname, qfname, dbStruct() } )
         stroka := textquery[ 6 ]
         poz1   := 1
         DO WHILE ( sword := NextItem( stroka, @poz1, ',' ) ) != Nil
            ordexp += Iif( Empty( ordexp ), "", "+" ) + INDEXP( Iif( IsDigit( sword ), FieldName( Val( sword ) ), Upper( Trim( sword ) ) ), .F. )
         ENDDO
      ENDIF
      IF !Empty( ordexp )
         MsgInf( aMsg[17] + Alias() )
         INDEX ON &ordexp TAG "N1" TO &qfname
      ENDIF
   ENDIF
   // �믮������ �����
   SELECT( f_impr )
   IF groupbl <> Nil
      msaccum := Array( Len( msquery[ 1 ] ) )
   ELSEIF pragr
      msaccum := 0
   ENDIF
   MsgInf( aMsg[7] )
   SET DELETED ON
   SET EXACT ON
   IF !Empty( f_usl )
      SET FILTER TO &f_usl
   ENDIF
   msquery[ 3 ] := &( "{||" + Iif( msquery[ 3 ] = Nil, ".T.", msquery[ 3 ] ) + "}" )
   GO TOP
   groupkey := "~~~"
   prbegin  := .T.
   max_len  := Len( msrelat )
   IF que_simpl .OR. Len( msquery[ 2 ] ) = 1
      FOR i := 1 TO max_len
         msrelat[ i, 5 ] = &( "{||" + msrelat[ i, 5 ] + "}" )
      NEXT
      screc := 0
      /*
      IF empty(f_usl)
         Alert("Empty...")
      ELSE
         Alert( f_usl )
      ENDIF
      */
      startsec := Seconds()
      DO WHILE !Eof()
         IF Eval( msquery[ 3 ] )
            FOR i := 1 TO max_len
               IF !Eval( msrelat[ i, 5 ] )
                  EXIT
               ENDIF
            NEXT
            IF i <= max_len
               SKIP
               LOOP
            ENDIF
            IF groupbl <> Nil           // �᫨ 㪠��� GROUP BY
               IF groupkey <> Eval( groupbl )               // �᫨ ��稭����� ����� ��㯯�
                  IF groupkey <> "~~~" .AND. Eval( msquery[ 5 ] )
                     SELECT 20
                     APPEND BLANK
                     FOR i := 1 TO Len( msaccum )
                        FieldPut( i, msaccum[ i ] )
                     NEXT
                     SELECT( f_impr )
                  ENDIF
                  groupkey := Eval( groupbl )
                  FOR i := 1 TO Len( msgr )
                     IF msgr[ i ]
                        msaccum[ i ] := Eval( msquery[ 1, i ], 0 )
                     ELSE
                        msaccum[ i ] := Eval( msquery[ 1, i ] )
                     ENDIF
                  NEXT
               ELSE                     // �᫨ �த�������� ⥪��� ��㯯�
                  FOR i := 1 TO Len( msgr )
                     IF msgr[ i ]
                        msaccum[ i ] := Eval( msquery[ 1, i ], msaccum[ i ] )
                     ENDIF
                  NEXT
               ENDIF
            ELSE    //
               IF distbl <> Nil         // �᫨ 㪠��� DISTINCT
                  IF groupkey <> Eval( distbl )
                     groupkey := Eval( distbl )
                     prbegin  := .T.
                  ELSE
                     prbegin := .F.
                  ENDIF
               ENDIF
               IF prbegin
                  IF pragr
                     msaccum := Eval( msquery[ 1, 1 ], msaccum )
                  ELSE
                     SELECT 20
                     APPEND BLANK
                     SELECT( f_impr )
                     FOR i := 1 TO Len( msquery[ 1 ] )
                        sword := Eval( msquery[ 1, i ] )
                        ( qfname ) -> ( FieldPut( i, sword ) )
                     NEXT
                  ENDIF
               ENDIF
            ENDIF
         ENDIF
         SKIP
         screc ++
         IF screc % 10 = 0
            @  2, 10 SAY LTrim( Str( screc, 8 ) ) COLOR "N/W"
         ENDIF
      ENDDO
      // Alert( Str( Seconds()-startsec ) )
   ELSE
      //
      max_len := Len( msrelat )
      FOR i := 1 TO max_len
         msrelat[ i, 5 ] = &( "{||" + msrelat[ i, 5 ] + "}" )
      NEXT
      msals := Array( max_len )
      AFill( msals, 0 )
      DO WHILE !Eof()
         ocher := max_len
         DO WHILE .T.
            IF ocher = max_len
               sw2 := msquery[ 2, msrelat[ ocher, 2 ], 2 ]
               IF msals[ ocher ] = 0
                  nrec := &sw2 -> ( RecNo() )
               ENDIF
               DO WHILE Eval( msrelat[ ocher, 5 ] )
                  IF Eval( msquery[ 3 ] )                   // �᫨ �믮����� �᫮��� WHERE
                     IF groupbl <> Nil  // �᫨ 㪠��� GROUP BY
                        IF groupkey <> Eval( groupbl )      // �᫨ ��稭����� ����� ��㯯�
                           IF groupkey <> "~~~" .AND. Eval( msquery[ 5 ] )
                              SELECT 20
                              APPEND BLANK
                              FOR i := 1 TO Len( msaccum )
                                 FieldPut( i, msaccum[ i ] )
                              NEXT
                              SELECT( f_impr )
                           ENDIF
                           groupkey := Eval( groupbl )
                           FOR i := 1 TO Len( msgr )
                              IF msgr[ i ]
                                 msaccum[ i ] := Eval( msquery[ 1, i ], 0 )
                              ELSE
                                 msaccum[ i ] := Eval( msquery[ 1, i ] )
                              ENDIF
                           NEXT
                        ELSE            // �᫨ �த�������� ⥪��� ��㯯�
                           FOR i := 1 TO Len( msgr )
                              IF msgr[ i ]
                                 msaccum[ i ] := Eval( msquery[ 1, i ], msaccum[ i ] )
                              ENDIF
                           NEXT
                        ENDIF
                     ELSE               //
                        IF distbl <> Nil                    // �᫨ 㪠��� DISTINCT
                           IF groupkey <> Eval( distbl )
                              groupkey := Eval( distbl )
                              prbegin  := .T.
                           ELSE
                              prbegin := .F.
                           ENDIF
                        ENDIF
                        IF prbegin
                           IF pragr
                              msaccum := Eval( msquery[ 1, 1 ], msaccum )
                           ELSE
                              SELECT 20
                              APPEND BLANK
                              SELECT( f_impr )
                              FOR i := 1 TO Len( msquery[ 1 ] )
                                 sword := Eval( msquery[ 1, i ] )
                                 ( qfname ) -> ( FieldPut( i, sword ) )
                              NEXT
                           ENDIF
                        ENDIF
                     ENDIF
                  ENDIF
                  &sw2 -> ( dbSkip( 1 ) )
               ENDDO
               &sw2 -> ( dbGoto( msals[ ocher ] ) )
               ocher --
            ELSEIF ocher < 1
               EXIT
            ELSE
               sw2 := msquery[ 2, msrelat[ ocher, 2 ], 2 ]
               IF msals[ ocher ] = 0
                  nrec := &sw2 -> ( RecNo() )
               ENDIF
               &sw2 -> ( dbSkip( 1 ) )
               IF Eval( msrelat[ ocher, 5 ] )
                  ocher := 1
               ELSE
                  &sw2 -> ( dbGoto( msals[ ocher ] ) )
                  ocher --
               ENDIF
            ENDIF
         ENDDO
         SELECT( f_impr )
         SKIP
      ENDDO
   ENDIF
   IF groupbl <> Nil                    // �᫨ 㪠��� GROUP BY
      IF groupkey <> "~~~" .AND. Eval( msquery[ 5 ] )
         SELECT 20
         APPEND BLANK
         FOR i := 1 TO Len( msaccum )
            FieldPut( i, msaccum[ i ] )
         NEXT
         SELECT( f_impr )
      ENDIF
   ENDIF
   SET DELETED OFF
   SET EXACT OFF
   MsgInf( aMsg[8] )
   IF pragr
      MsgSay( aMsg[6] + Transform( msaccum, "@(" ), "R/W" )
   ELSE
      SELECT 20
      IF !Empty( ordexp )
         OrdSetFocus( "N1" )
         COPY ALL TO QUERYTMP
         USE
         FErase( qfname + ".DBF" )
         FRename( "QUERYTMP.DBF", qfname + ".DBF" )
      ELSE
         USE
      ENDIF
      FErase( qfname + ".CDX" )
      fdbopen( qfname )
      prkorf  := .T.
      prkorst := .T.
      KEYBOARD Chr( 27 ) + Chr( 27 )
   ENDIF

   RETURN Nil

FUNCTION AnaWhere( strexp )

   LOCAL i, j := 0, j1, strrez := "", sword, sdop, sw1, sw2 := "", ileft, swleft2, leftexi := .F.
   LOCAL lastand := "", lastlen := 0, alsinusl := 0, pror := .F.
   LOCAL stroka, pos1 := 1

   stroka := strexp
   strexp := ""
   DO WHILE ( sword := NextItem( stroka, @pos1, ' ' ) ) != Nil
      IF ( i := ASCAN( { "AND", "OR", "NOT", "IN", "BETWEEN" }, sword ) ) = 0
         strexp += sword
      ELSE
         IF i > 1
            pror := .T.
         ENDIF
         strexp += "|" + sword + "|"
      ENDIF
   ENDDO
   DO WHILE !Empty( strexp )
      IF ( i := IsExp( strexp, "=><()-+*|" ) ) = 0
         sword  := strexp
         strexp := ""
         sdop   := ""
      ELSE
         sword := Left( strexp, i - 1 )
         sdop  := SubStr( strexp, i, 1 )
         IF ( sdop $ "=<>" .AND. SubStr( strexp, i + 1, 1 ) $ "=<>" ) .OR. ( sdop = "(" .AND. SubStr( strexp, i + 1, 1 ) = ")" )
            i ++
            sdop += SubStr( strexp, i, 1 )
         ENDIF
         strexp := SubStr( strexp, i + 1 )
      ENDIF
      IF !Empty( sword )
         IF ASCAN( { "AND", "OR", "NOT" }, sword ) <> 0
            lastand := sword
            sword   := "." + sword + "."
            IF !pror .AND. alsinusl < 2
               sword  := ""
               f_usl  += Iif( Empty( f_usl ), "", ".AND." ) + SubStr( strrez, lastlen + 1 )
               strrez := SubStr( strrez, 1, lastlen )
            ENDIF
            alsinusl := 0
            lastlen  := Len( strrez ) + Len( sword )
         ENDIF
         IF Asc( sword ) > 63
            IF sword = "IN"
            ELSEIF sword = "BETWEEN"
            ELSE
               sw1 := sword
               IF Left( sdop, 1 ) <> "("
                  IF !FindFiel( @sw1, @sw2, @i, @j )
                     RETURN ""
                  ENDIF
                  sword    := Iif( Empty( sw1 ), "", sw1 + "->" ) + sw2
                  alsinusl := Max( alsinusl, i )
                  IF Len( msquery[ 2 ] ) > 1
                     IF Left( sdop, 1 ) == "=" .AND. ( Empty( lastand ) .OR. lastand = "AND" )
                        // ������� ����� ���� �᫮���
                        ileft   := i
                        swleft2 := sw2
                        leftexi := .T.
                        lastlen := Len( strrez )
                     ELSEIF leftexi .AND. ( Empty( sdop ) .OR. sdop = "|" ) .AND. i <> ileft
                        // �ࠢ�� ����
                        IF ileft < i
                           j1      := ileft
                           ileft   := i
                           i       := j1
                           sw1     := swleft2
                           swleft2 := sw2
                           sw2     := sw1
                        ENDIF
                        FOR j1 := 1 TO Len( msrelat )
                           IF msrelat[ j1, 1 ] = i .AND. msrelat[ j1, 2 ] = ileft
                              msrelat[ j1, 3 ] += "+" + INDEXP( msquery[ 2, ileft, 2 ] + "." + swleft2, .F. )
                              msrelat[ j1, 4 ] += "+" + INDEXP( msquery[ 2, i, 2 ] + "." + sw2, .F. )
                              sw2 := ".AND." + SubStr( strrez, lastlen + 1 ) + sword
                              msrelat[ j1, 5 ] += sw2
                              EXIT
                           ENDIF
                        NEXT
                        IF j1 > Len( msrelat )
                           AAdd( msrelat, { i, ileft, INDEXP( msquery[ 2, i, 2 ] + "." + sw2, .F. ), ;
                              INDEXP( msquery[ 2, ileft, 2 ] + "." + swleft2, .F. ), ;
                              SubStr( strrez, lastlen + 1 ) + sword } )
                        ENDIF
                        IF Empty( lastand )
                           sword  := ".T."
                           strrez := ""
                        ELSE
                           sword  := ""
                           strrez := SubStr( strrez, 1, lastlen - 5 )
                        ENDIF
                     ENDIF
                  ENDIF
               ENDIF
            ENDIF
         ELSE
            IF Len( sword ) = 8 .AND. SubStr( sword, 3, 1 ) = "/" .AND. SubStr( sword, 6, 1 ) = "/"
               sword := "CTOD('" + sword + "')"
            ENDIF
         ENDIF
         IF leftexi .AND. Left( sdop, 1 ) <> "="
            leftexi := .F.
         ENDIF
         IF Empty( strexp ) .AND. !pror .AND. alsinusl < 2
            f_usl  += Iif( Empty( f_usl ), "", ".AND." ) + SubStr( strrez, lastlen + 1 ) + sword
            strrez := SubStr( strrez, 1, Iif( lastand = "AND", lastlen - 5, lastlen ) )
            sword  := ""
         ENDIF
      ENDIF
      strrez += sword + Iif( sdop <> "|", sdop, "" )
   ENDDO
   FOR i := 1 TO Len( msrelat )
      j := msrelat[ i, 2 ]
      SELECT( msquery[ 2, j, 4 ] )
      SetInd( msrelat[ i, 4 ], "WHE_" + NUM_STR( j, 2 ) )
      SELECT( msquery[ 2, msrelat[ i, 1 ], 4 ] )
      sw1 := msrelat[ i, 3 ]
      sw2 := msquery[ 2, j, 2 ]
      SET RELATION TO &sw1 INTO &sw2 ADDITIVE
   NEXT

   RETURN Iif( Empty( strrez ), ".T.", strrez )

FUNCTION AnaHavi( strexp )

   LOCAL i, strrez := "", sword, sdop

   DO WHILE !Empty( strexp )
      IF ( i := IsExp( strexp, "=>< " ) ) = 0
         sword  := strexp
         strexp := ""
         sdop   := ""
      ELSE
         sword := Left( strexp, i - 1 )
         sdop  := SubStr( strexp, i, 1 )
         IF sdop $ "=<>" .AND. SubStr( strexp, i + 1, 1 ) $ "=<>"
            i ++
            sdop += SubStr( strexp, i, 1 )
         ENDIF
         strexp := SubStr( strexp, i + 1 )
      ENDIF
      IF !Empty( sword )
         IF ASCAN( { "AND", "OR", "NOT" }, sword ) <> 0
            sword := "." + sword + "."
         ENDIF
         IF Asc( sword ) > 63
            IF ( i := ASCAN( msquery[ 1 ], Upper( sword ) ) ) = 0
               MsgSay( sword + aMsg[18] )
               RETURN ""
            ELSE
               sword := "msaccum[" + NUM_STR( i, 2 ) + "]"
            ENDIF
         ELSE
            IF Len( sword ) = 8 .AND. SubStr( sword, 3, 1 ) = "/" .AND. SubStr( sword, 6, 1 ) = "/"
               sword := "CTOD('" + sword + "')"
            ENDIF
         ENDIF
      ENDIF
      strrez += sword + sdop
   ENDDO

   RETURN strrez

FUNCTION ConvAgr( sword, i )

   LOCAL j, pos1

   j := At( "(", sword )
   IF ( pos1 := j + FIND_Z( SubStr( sword, j + 1 ), ')' ) ) = j
      MsgSay( aMsg[19] + " ')'" )
      RETURN ""
   ENDIF
   IF SubStr( sword, j + 1, 1 ) = "*"
      IF i = 1
         sword := "COUNT(,'*',p3)"
      ELSE
         MsgSay( aMsg[20] )
         RETURN ""
      ENDIF
   ELSEIF SubStr( sword, j + 1, 8 ) = "DISTINCT"
      sword := SubStr( sword, 1, j ) + SubStr( sword, j + 9, pos1 - j - 9 ) + ",'D',p3)"
   ELSE
      sword := SubStr( sword, 1, pos1 - 1 ) + ",,p3)"
   ENDIF
   IF i = 4 .OR. i = 5
      sword := SubStr( sword, 1, j - 1 ) + "_F" + SubStr( sword, j )
   ENDIF

   RETURN sword

FUNCTION AnalyzExp( strexp, str2 )

   LOCAL i, j, poz, sword, sw2, strrez := "", strvar := ""
   LOCAL stroka, pos1 := 1

   stroka := strexp
   strexp := ""
   DO WHILE ( sword := NextItem( stroka, @pos1, ' ' ) ) != Nil
      IF ( i := ASCAN( { "AND", "OR", "NOT", "IN", "BETWEEN" }, sword ) ) = 0
         strexp += sword
      ELSE
         strexp += "|" + sword + "|"
      ENDIF
   ENDDO
   DO WHILE .T.
      IF ( poz := IsExp( strexp, "-+*/()<>=,|" ) ) = 0
         FindFiel( @strexp, @sw2, @i, @j )
         strrez += Iif( Empty( strexp ), "", strexp + "->" ) + sw2
         strvar += GetZnach( i, j )
         EXIT
      ELSE
         IF SubStr( strexp, poz, 1 ) = "(" .OR. !IsAlpha( strexp ) .OR. ;
               ASCAN( { "AND", "OR", "NOT", "IN", "BETWEEN" }, Left( strexp, poz - 1 ) ) <> 0
            IF SubStr( strexp, poz, 1 ) = "|"
               strrez += SubStr( strexp, 1, poz - 1 ) + "."
               strvar += SubStr( strexp, 1, poz - 1 ) + "."
            ELSE
               strrez += SubStr( strexp, 1, poz )
               strvar += SubStr( strexp, 1, poz )
            ENDIF
         ELSE
            sword := SubStr( strexp, 1, poz - 1 )
            FindFiel( @sword, @sw2, @i, @j )
            strrez += Iif( Empty( sword ), "", sword + "->" ) + sw2 + SubStr( strexp, poz, 1 )
            strvar += GetZnach( i, j ) + SubStr( strexp, poz, 1 )
         ENDIF
         strexp := SubStr( strexp, poz + 1 )
         IF Empty( strexp )
            EXIT
         ENDIF
      ENDIF
   ENDDO
   IF str2 <> Nil
      str2 := strvar
   ENDIF

   RETURN strrez

FUNCTION GetZnach( i, j )

   LOCAL strrez

   IF msquery[ 2, i, 3, j, 2 ] = "C"
      strrez := '"' + Replicate( 'X', msquery[ 2, i, 3, j, 3 ] ) + '"'
   ELSEIF msquery[ 2, i, 3, j, 2 ] = "D"
      strrez := 'DATE()'
   ELSE
      max_len := Max( max_len, msquery[ 2, i, 3, j, 3 ] )
      max_dec := Max( max_dec, msquery[ 2, i, 3, j, 4 ] )
      strrez  := Iif( msquery[ 2, i, 3, j, 4 ] = 0, ;
         Replicate( "9", msquery[ 2, i, 3, j, 3 ] ), ;
         Replicate( "9", msquery[ 2, i, 3, j, 3 ] - msquery[ 2, i, 3, j, 4 ] - 1 ) + "." + Replicate( "9", msquery[ 2, i, 3, j, 4 ] ) )
   ENDIF

   RETURN strrez

FUNCTION IsAgr( strexp )

   LOCAL i

   i := IsExp( strexp )
   IF SubStr( strexp, i, 1 ) = "("
      IF ( i := ASCAN( { "COUNT", "SUM", "AVG", "MIN", "MAX" }, SubStr( strexp, 1, i - 1 ) ) ) <> 0
         RETURN i
      ENDIF
   ENDIF

   RETURN 0

STATIC FUNCTION IsExp( sword, shablon )

   LOCAL i, sLen := Len( sword )

   IF shablon == Nil
      shablon := "-+*/()<>="
   ENDIF
   FOR i := 1 TO sLen
      IF SubStr( sword, i, 1 ) $ shablon
         RETURN i
      ENDIF
   NEXT

   RETURN 0

FUNCTION FindFiel( sword, sw2, i, j )

   i   := At( ".", sword )
   sw2 := Iif( i = 0, sword, SubStr( sword, i + 1 ) )
   IF i <> 0
      sword := SubStr( sword, 1, i - 1 )
      i     := ASCAN( msquery[ 2 ], { | aVal | aVal[ 2 ] == sword } )
      IF i = 0
         MsgSay( sword + aMsg[21] )
         RETURN .F.
      ENDIF
   ELSE
      sword := ""
      i     := 1
   ENDIF
   j := ASCAN( msquery[ 2, i, 3 ], { | aVal | aVal[ 1 ] == sw2 } )
   IF j = 0
      MsgSay( sw2 + aMsg[22] )
      RETURN .F.
   ENDIF

   RETURN .T.

FUNCTION IndExp( finame, prals, inum )

   LOCAL strind := "", sw2, i, j, vtype, vlen, vdec

   prals := Iif( prals = Nil, .T. , prals )
   IF !FindFiel( @finame, @sw2, @i, @j )
      RETURN strind
   ENDIF
   IF !prals .OR. ( inum <> Nil .AND. inum = i )
      finame := ""
   ENDIF
   IF !Empty( finame )
      finame += "->"
   ENDIF
   vtype := msquery[ 2, i, 3, j, 2 ]
   DO CASE
   CASE vtype = "C"
      strind := finame + sw2
   CASE vtype = "N"
      vlen   := msquery[ 2, i, 3, j, 3 ]
      vdec   := msquery[ 2, i, 3, j, 4 ]
      strind := "STR(" + finame + sw2 + ',' + LTrim( Str( vlen, 2 ) ) + Iif( vdec = 0, "", "," + Str( vdec, 1 ) ) + ")"
   CASE vtype = "D"
      strind := "DTOS(" + finame + sw2 + ")"
   ENDCASE

   RETURN strind

FUNCTION MainInd( stroka )

   LOCAL sword, ind_exp := "", pos1 := 1
   STATIC oblg := 0

   DO WHILE ( sword := NextItem( stroka, @pos1, ',' ) ) != Nil
      ind_exp += Iif( Empty( ind_exp ), "", "+" ) + INDEXP( Upper( LTrim( RTrim( sword ) ) ), , 1 )
   ENDDO
   IF oblg <> 0
      SELECT( oblg )
      CLOSE INDEXES
      oblg := 0
   ENDIF
   SELECT( f_impr )
   SetInd( ind_exp, "GROUPIND" )
   oblg := Select()

   RETURN ind_exp

FUNCTION SetInd( ind_exp, indname )

   LOCAL i := 1, nExpLen := Len( ind_exp ), cExp

   DO WHILE !Empty( cExp := Upper( AllTrim( OrdKey( i ) ) ) )
      IF ind_exp = Left( cExp, nExpLen )
         SET ORDER TO i
         RETURN Nil
      ENDIF
      i ++
   ENDDO

   MsgInf( aMsg[17] + Alias() )
   INDEX ON &ind_exp TO &indname
   SET INDEX TO &indname

   RETURN Nil

FUNCTION COUNT( p1, p2, p3 )

   RETURN p3 + 1

FUNCTION SUM( p1, p2, p3 )

   RETURN p1 + p3

FUNCTION AVG( p1, p2 )

   LOCAL rez

   RETURN rez

FUNCTION MIN_F( p1, p2, p3 )

   RETURN Iif( p3 == 0, p1, Min( p1, p3 ) )

FUNCTION MAX_F( p1, p2, p3 )

   RETURN Max( p1, p3 )

STATIC FUNCTION NextItem( stroka, nPos, cSep )

   LOCAL i, oldPos, sLen := Len( stroka )

   IF cSep == Nil
      cSep := ","
   ENDIF
   IF nPos <= sLen
      oldPos := nPos
      IF cSep == " "
         i := nPos
         DO WHILE i <= sLen .AND. SubStr( stroka, i, 1 ) > " "
            i ++
         ENDDO
         IF i > sLen
            i := 0
         ELSE
            i -= ( nPos - 1 )
         ENDIF
      ELSE
         i := Find_z( SubStr( stroka, nPos ), cSep )
      ENDIF
      IF i == 0
         nPos := sLen + 1
         RETURN LTrim( RTrim( SubStr( stroka, oldPos ) ) )
      ELSE
         nPos += i
         RETURN LTrim( RTrim( SubStr( stroka, oldPos, i - 1 ) ) )
      ENDIF
   ENDIF

   RETURN Nil
