rem set path=c:\softools\mingw\bin
@SET HRB_DIR=c:\harbour
%HRB_DIR%\bin\harbour dbc /n /i%HRB_DIR%\include /dGTWVT >harbour.out
%HRB_DIR%\bin\harbour move /n /i%HRB_DIR%\include >>harbour.out
%HRB_DIR%\bin\harbour lang /n  /i%HRB_DIR%\include >>harbour.out
%HRB_DIR%\bin\harbour modistru /n /i%HRB_DIR%\include >>harbour.out
%HRB_DIR%\bin\harbour commands /n /i%HRB_DIR%\include >>harbour.out
%HRB_DIR%\bin\harbour view /n  /i%HRB_DIR%\include >>harbour.out
%HRB_DIR%\bin\harbour query /n /i%HRB_DIR%\include >>harbour.out
%HRB_DIR%\bin\harbour pechdbc /n /i%HRB_DIR%\include >>harbour.out
%HRB_DIR%\bin\harbour prcmenu /n /i%HRB_DIR%\include >>harbour.out

%HRB_DIR%\bin\harbour errorsys /n /i%HRB_DIR%\include >>harbour.out
%HRB_DIR%\bin\harbour procs1 /n /i%HRB_DIR%\include >>harbour.out
%HRB_DIR%\bin\harbour procs3 /n /i%HRB_DIR%\include >>harbour.out
%HRB_DIR%\bin\harbour procs5 /n /i%HRB_DIR%\include >>harbour.out
%HRB_DIR%\bin\harbour procs7 /n /i%HRB_DIR%\include >>harbour.out
%HRB_DIR%\bin\harbour procs8 /n /i%HRB_DIR%\include >>harbour.out
%HRB_DIR%\bin\harbour procared /n /i%HRB_DIR%\include >>harbour.out
%HRB_DIR%\bin\harbour procscri /n /i%HRB_DIR%\include /d__NO_HWGUI__ >>harbour.out

rem The following line is for Borland C and gtwin
rem bcc32 -edbch.exe -O2 -I%HRB_DIR%\include -L%HRB_DIR%\lib hbrtl.lib gtwin.lib hbvm.lib hbpp.lib hbcommon.lib hbmacro.lib hbrdd.lib rddntx.lib rddcdx.lib rddfpt.lib hbsix.lib hblang.lib hbcpage.lib hbct.lib dbc.c lang.c move.c modistru.c commands.c view.c query.c pechdbc.c prcmenu.c errorsys.c procs1.c procs3.c procs5.c procs7.c procs8.c procared.c procscri.c procs_c.c >>harbour.out

rem The following line is for Borland C and gtwvt
bcc32 -edbch.exe -O2 -tW -I%HRB_DIR%\include -L%HRB_DIR%\lib hbrtl.lib gtwvt.lib hbvm.lib hbpp.lib hbcommon.lib hbmacro.lib hbrdd.lib rddntx.lib rddcdx.lib rddfpt.lib hbsix.lib hblang.lib hbcpage.lib hbpcre.lib dbc.c lang.c move.c modistru.c commands.c view.c query.c pechdbc.c prcmenu.c errorsys.c procs1.c procs3.c procs5.c procs7.c procs8.c procared.c procscri.c procs_c.c >>harbour.out

rem The following two lines are for Mingw and gtwvt
rem gcc -Wall -mno-cygwin -c -I%HRB_DIR%/include dbc.c lang.c move.c modistru.c commands.c view.c query.c pechdbc.c prcmenu.c errorsys.c procs1.c procs3.c procs5.c procs7.c procs8.c procared.c procini.c procscri.c procs_c.c
rem gcc -Wall -mwindows -odbch.exe dbc.o lang.o move.o modistru.o commands.o view.o query.o pechdbc.o prcmenu.o errorsys.o procs1.o procs3.o procs5.o procs7.o procs8.o procared.o procini.o procscri.o procs_c.o -Lc:\harbour/lib/win/mingw -Wl,--start-group -lhbvm -lhbrtl -lgtwvt -lhblang -lhbrdd -lhbmacro -lhbpp -lrddntx -lrddcdx -lrddfpt -lhbsix -lhbcommon -lhbcpage -lhbct -luser32 -lgdi32 -lwinspool -lcomctl32 -luuid -lkernel32 -lws2_32 -Wl,--end-group

@del *.obj
@del *.o
@del dbc.c
@del move.c
@del lang.c
@del modistru.c
@del commands.c
@del view.c
@del query.c
@del pechdbc.c
@del prcmenu.c
@del errorsys.c
@del procs1.c
@del procs3.c
@del procs5.c
@del procs7.c
@del procs8.c
@del procared.c
@del procscri.c
