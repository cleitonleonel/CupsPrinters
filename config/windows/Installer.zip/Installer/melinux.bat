start c:\putty.exe -load melinux -ssh melinux@srvlinux -pw melinux 
