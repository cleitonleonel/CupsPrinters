/*
 * Common procedures
 *
 *
 * Author: Alexander S.Kresin <alex@kresin.ru>
 *         www - http://www.kresin.ru/
 * Released to Public Domain
*/

STATIC MSANIM[ 7 ]

PROCEDURE procs8
   RETURN

FUNCTION ZPLOCK

LOCAL screenb, oldc
   IF .NOT. Rlock()
      screenb := Savescreen( 11, 20, 11, 60 )
      oldc    := Setcolor()
      Setcolor( "+W/R" )
      @ 11, 23 SAY "�����! ������ ������������ � ����!"         
      DO WHILE .NOT. Rlock()
         IF Inkey( 1 ) = - 29
            QUIT
         ENDIF
      ENDDO
      Setcolor( oldc )
      Restscreen( 11, 20, 11, 60, screenb )
   ENDIF
RETURN .T.

PROCEDURE CALCUL
LOCAL bufs, oldc, chi, chi2, nkey, ckey, prtchk, stroper, prnewchi, i, aSetKeys, set28
STATIC strchi := "                 0", msmemory := { 0, 0, 0 }, koldec := 2

   bufs := Savescreen( 19, 0, 24, 20 )
   oldc := Setcolor( "R/W" )
   aSetKeys := SaveKeys()
   set28 := Setkey( 28, Nil )
   @ 22,  0, 24, 20 BOX "�Ŀ����� "
   FOR i := 1 TO 3
      IF msmemory[ 4 - i ] <> 0
         @ 18 + i, 1 SAY Vivchi( msmemory[ 4 - i ], koldec ) + ' '         
      ENDIF
   NEXT
   stroper  := " "
   prnewchi := .T.
   DO WHILE .T.
      prtchk := "." $ strchi
      @ 23,  1 SAY strchi + stroper         
      nkey := Inkey( 0 )
      ckey := Chr( nkey )
      DO CASE
      CASE nkey = 27
         EXIT
      CASE ckey $ "0123456789"
         IF prnewchi
            strchi   := Space( 17 ) + ckey
            prnewchi := .F.
         ELSE
            strchi := Substr( strchi, 2 ) + ckey
         ENDIF
      CASE ckey = "." .OR. ckey = ","
         IF .NOT. prtchk
            IF prnewchi
               strchi   := Space( 17 ) + "."
               prnewchi := .F.
            ELSE
               strchi := Substr( strchi, 2 ) + "."
            ENDIF
         ENDIF
      CASE ckey $ "*+-/" .OR. nkey = 13
         chi := Val( Ltrim( strchi ) )
         IF stroper <> " "
            DO CASE
            CASE stroper = "+"
               chi := chi + chi2
            CASE stroper = "-"
               chi := chi2 - chi
            CASE stroper = "*"
               chi := chi2 * chi
            CASE stroper = "/"
               chi := chi2 / chi
            ENDCASE
            strchi := Vivchi( chi, koldec )
         ENDIF
         prnewchi := .T.
         chi2     := chi
         IF nkey = 13
            stroper := " "
         ELSE
            stroper := ckey
         ENDIF
      CASE nkey = 32
         strchi := Space( 17 ) + "0"
      CASE nkey = 8
         strchi := " " + Left( strchi, 17 )
      CASE nkey <= - 20 .AND. nkey >= - 22
         msmemory[ Abs( nkey ) - 19 ] = Val( Ltrim( strchi ) )
         FOR i := 1 TO 3
            IF msmemory[ 4 - i ] <> 0
               @ 18 + i, 1 SAY Vivchi( msmemory[ 4 - i ], koldec ) + ' '         
            ENDIF
         NEXT
      CASE ( nkey <= - 1 .AND. nkey >= - 2 ) .OR. nkey = 28
         IF ( i := msmemory[ Iif( nkey = 28, 1, Abs( nkey ) + 1 ) ] ) <> 0
            strchi := Vivchi( i, koldec )
         ENDIF
      CASE nkey = - 8
         @ 23,  1 CLEAR TO 23, 19
         @ 23,  1 SAY "���.������: " + Str( koldec, 1 )         
         DO WHILE .T.
            Devpos( 23, 13 )
            i := Inkey( 0 )
            IF i > 47 .AND. i < 58
               koldec := i - 48
               EXIT
            ELSEIF i = 27
               EXIT
            ENDIF
         ENDDO
         @ 23,  1 SAY strchi + stroper         
      CASE nkey = - 9
         KEYBOARD Ltrim( strchi )
         EXIT
      CASE nkey = - 5
         Calcul_Exp()
      ENDCASE
   ENDDO
   Setkey( 28, set28 )
   LoadKeys( aSetKeys )
   Setcolor( oldc )
   Restscreen( 19, 0, 24, 20, bufs )
RETURN

STATIC FUNCTION Vivchi( chi, koldec )

LOCAL i, kolzn, strc := Str( chi, 18, koldec )

   kolzn := koldec
   FOR i := 1 TO koldec
      IF Substr( strc, 19 - i, 1 ) = "0"
         kolzn := koldec - i
      ELSE
         EXIT
      ENDIF
   NEXT
   IF kolzn > 0
      strc := Str( chi, 18, kolzn )
   ELSE
      strc := Str( chi, 18 )
   ENDIF
RETURN strc

STATIC FUNCTION CALCUL_EXP
LOCAL lRes, bOldError, xRez, strbuf := Space(240), oldc, bufs
LOCAL Getlist := {}

   bufs := Savescreen( 22, 0, 24, 79 )
   oldc := Setcolor( "W/B,N/BG" )
   @ 22,0,24,79 BOX "�Ŀ����� "

   DO WHILE .T.
      @ 23,1 GET strbuf PICTURE "@S78"
      READ
      IF Lastkey() == 27
         EXIT
      ELSE
         lRes := .T.
         bOldError := ErrorBlock( { |e|break( e ) } )
         BEGIN SEQUENCE
            xRez := &( Trim( strbuf ) )
         RECOVER
            Alert( "Error!" )
            lRes := .F.
         END SEQUENCE
         Errorblock( bOldError )
         IF lRes
            Alert( Iif( xRez==Nil, "Nil", Transform( xRez, "@B" ) ) )
         ENDIF
      ENDIF
   ENDDO

   Setcolor( oldc )
   Restscreen( 22, 0, 24, 79, bufs )

RETURN Nil

FUNCTION ANIMA( priznak, koll, strviv, y1, x1, x2 )

   DO CASE
   CASE priznak = 0 .OR. priznak = 3
      IF priznak = 0
         MSANIM[ 7 ] = strviv
         IF Len( strviv ) > x2 - x1 - 1
            strviv := Substr( strviv, 1, x2 - x1 - 4 ) + "..."
         ENDIF
         SET CURSOR OFF
         MSANIM[ 1 ] = 0
         MSANIM[ 2 ] = 0
         MSANIM[ 3 ] = Int( koll / ( x2 - x1 - 4 ) )
         MSANIM[ 4 ] = y1
         MSANIM[ 5 ] = x1
         MSANIM[ 6 ] = x2
      ELSE
         strviv := Iif( Len( MSANIM[ 7 ] ) > MSANIM[ 6 ] - MSANIM[ 5 ] - 1, ;
                        Substr( MSANIM[ 7 ], 1, MSANIM[ 6 ] - MSANIM[ 5 ] - 4 ) + "...", MSANIM[ 7 ] )
         y1 := MSANIM[ 4 ]
         x1 := MSANIM[ 5 ]
         x2 := MSANIM[ 6 ]
      ENDIF
      Set COLOR TO +W/W
      @ y1, x1, y1 + 4, x2 BOX "�������� "
      @ y1 + 2, x1 + 2, y1 + 3, x2 - 2 BOX "�Ŀ����� "
      Set COLOR TO N/W
      @ y1 + 2, x1 + 2                                SAY "�"            
      @ y1 + 2, x1 + 3 TO y1 + 2, x2 - 3
      @ y1 + 3, x1 + 2                                SAY "�"            
      @ y1 + 1, Int( ( 80 - Len( strviv ) ) / 2 ) + 1 SAY strviv         
      IF priznak = 3
         Set COLOR TO +W/W
         @ MSANIM[  4 ] + 2, MSANIM[ 5 ] + 2 SAY "�"         
         @ MSANIM[  4 ] + 3, MSANIM[ 5 ] + 2 SAY "�"         
         @ MSANIM[  4 ] + 2, MSANIM[ 5 ] + 3 TO MSANIM[ 4 ] + 2, MSANIM[ 5 ] + MSANIM[ 2 ] + 1
         Set COLOR TO N/W
         @ MSANIM[  4 ] + 2, MSANIM[ 5 ] + 2 + MSANIM[ 2 ] SAY "�"         
         @ MSANIM[  4 ] + 3, MSANIM[ 5 ] + 2 + MSANIM[ 2 ] SAY "�"         
         @ MSANIM[  4 ] + 3, MSANIM[ 5 ] + 3 TO MSANIM[ 4 ] + 3, MSANIM[ 5 ] + MSANIM[ 2 ] + 1
      ENDIF
   CASE priznak = 1
      MSANIM[ 1 ] = MSANIM[ 1 ] + 1
      IF MSANIM[ 1 ] = MSANIM[ 3 ] .AND. MSANIM[ 2 ] < MSANIM[ 6 ] - MSANIM[ 5 ] - 4
         MSANIM[ 1 ] = 0
         MSANIM[ 2 ] = MSANIM[ 2 ] + 1
         Set COLOR TO +W/W
         @ MSANIM[  4 ] + 2, MSANIM[ 5 ] + 2 SAY "�"         
         @ MSANIM[  4 ] + 3, MSANIM[ 5 ] + 2 SAY "�"         
         @ MSANIM[  4 ] + 2, MSANIM[ 5 ] + 3 TO MSANIM[ 4 ] + 2, MSANIM[ 5 ] + MSANIM[ 2 ] + 1
         Set COLOR TO N/W
         @ MSANIM[  4 ] + 2, MSANIM[ 5 ] + 2 + MSANIM[ 2 ] SAY "�"         
         @ MSANIM[  4 ] + 3, MSANIM[ 5 ] + 2 + MSANIM[ 2 ] SAY "�"         
         @ MSANIM[  4 ] + 3, MSANIM[ 5 ] + 3 TO MSANIM[ 4 ] + 3, MSANIM[ 5 ] + MSANIM[ 2 ] + 1
      ENDIF
   CASE priznak = 2
      Set COLOR TO N/W
      @ MSANIM[  4 ] + 1, MSANIM[ 5 ] + 1 CLEAR TO MSANIM[ 4 ] + 1, MSANIM[ 6 ] - 1
      @ MSANIM[  4 ] + 1, Int( ( 80 - Len( strviv ) ) / 2 ) + 1 SAY strviv         
      Inkey( 2 )
   ENDCASE
   SET CURSOR ON
RETURN Nil

FUNCTION SETANIM( n, value )

   IF value != Nil
      MSANIM[ n ] := value
   ENDIF
RETURN MSANIM[ n ]

FUNCTION VIVCTRLS( mctrl )

LOCAL i
   FOR i := 1 TO Len( mctrl )
      @ Val( Left( mctrl[ i ], 2 ) ), Val( Substr( mctrl[ i ], 3, 2 ) ) SAY Substr( mctrl[ i ], 5 )         
   NEXT
RETURN .T.

FUNCTION SAVEKEYS
LOCAL i, aSetKeys[ 9 ]

   FOR i := 1 TO 9
      aSetKeys[ i ] := Setkey( - i, Nil )
   NEXT

RETURN aSetKeys

FUNCTION LOADKEYS( aSetKeys )
LOCAL i

   FOR i := 1 TO 9
      Setkey( - i, aSetKeys[ i ] )
   NEXT

RETURN Nil
