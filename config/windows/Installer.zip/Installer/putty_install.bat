@echo off
setlocal

set url=https://the.earth.li/~sgtatham/putty/latest/w64/putty.exe
set outputfile=C:\putty.exe

echo Baixando o PuTTY...

powershell -Command "Invoke-WebRequest -Uri '%url%' -OutFile '%outputfile%'"

echo Download concluído!
pause
