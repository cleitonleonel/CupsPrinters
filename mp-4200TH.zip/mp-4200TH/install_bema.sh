#!/bin/bash

echo "Efetuando download dos drivers bematech..."
curl http://bematechpartners.com.br/wp01/upload-files/downloads/linux/impressoras_termicas/Utilitarios/Drivers/Ubuntu/UbuntuDriverCUPS.zip -L -s -O

echo "Descompactando arquivos..."
unzip UbuntuDriverCUPS.zip

cd  UbuntuDriverCUPS || exit

echo "Instalando libusb..."
apt-get install -y libusb-0.1-4

echo "Instalando drivers bematech..."
dpkg -i bematech-driver_2.0.0.4-0_amd64.deb

echo "Drivers instalados com sucesso!!!"