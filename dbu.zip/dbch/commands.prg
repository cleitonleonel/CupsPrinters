/*
 * DBC - Database Control Utility
 * Commands implementation
 *
 * Author: Alexander S.Kresin <alex@kresin.ru>
 *         www - http://www.kresin.ru/
 * Released to Public Domain
*/

#command DELETE             ;
      [FOR <for>]           ;
      [WHILE <while>]       ;
      [NEXT <next>]         ;
      [RECORD <rec>]        ;
      [<rest:REST>]         ;
      [ALL]                 ;
      ;
      => dbEval(                                       ;
      { || iif( .NOT. Set( _SET_EXCLUSIVE ), RLock(), "" ), dbDelete(), ;
      iif( .NOT. Set( _SET_EXCLUSIVE ), runlock(), "" ) },   ;
      < { for } > , < { while } > , < next > , < rec > , < .rest. >    ;
      )
#command REPLACE [ <f1> WITH <x1> [, <fn> WITH <xn>] ]    ;
      [FOR <for>]                                         ;
      [WHILE <while>]                                     ;
      [NEXT <next>]                                       ;
      [RECORD <rec>]                                      ;
      [<rest:REST>]                                       ;
      [ALL]                                               ;
      => dbEval(                                          ;
      { ||iif( .NOT. Set( _SET_EXCLUSIVE ), RLock(), "" ),;
      _FIELD -> < f1 > := < x1 > [, _FIELD-><fn> := <xn>],;
      iif( .NOT. Set( _SET_EXCLUSIVE ), runlock(), "" ) },;
      < { for } > , < { while } > , < next > , < rec > , < .rest. > ;
      )

#define STR_BUFLEN  4096

#ifdef RDD_ADS
#include "ads.ch"
#endif
#include "fileio.ch"
#include "deflist.ch"
#include "dbc.ch"

MEMVAR aFiles
MEMVAR strfor, finame, expstr
MEMVAR prall, prnext, prrest, nrest, msknop
MEMVAR prdbf, prsdf, prdelim, cdelim, cdelim2, prcsv, cquo, cDateF, msknop1

FUNCTION C_REPL

   LOCAL bufsc, oldc, nrec, blsum, blfor, i
   PRIVATE strfor := Space( 120 ), finame := Space( 8 ), expstr := Space( 80 ), afiel[ Fcount() ], nrez
   PRIVATE prall, prnext, prrest, nrest, msknop := { "X", " ", " " }

   bufsc := SaveScreen( 6, 20, 14, 70 )
   oldc  := Setcolor()
   SET COLOR TO + W/GR, N +/ W, , , + W/GR
   @  6, 20, 14, 70 BOX "�Ŀ����� "
   AFields( afiel )
   DO WHILE .T.
      @  7, 22 SAY aMsg[23] GET finame WHEN VLDFIELD( @finame )
      @  8, 22 SAY aMsg[24] GET expstr PICTURE "@S42"
      VvScope( 9, 22 )
      @ 12, 22 SAY "FOR"
      @ 13, 22 GET strfor PICTURE "@S46"
      READ
      IF LastKey() <> 27
         IF .NOT. Empty( strfor ) .AND. Type( strfor ) <> "L"
            MsgSay( aMsg[4] )
         ELSE
            IF Empty( strfor )
               strfor := ".T." + Space( 117 )
            ENDIF
            MsgInf( aMsg[7] )
            DO CASE
            CASE prall = "X"
               REPLACE ALL &finame WITH &expstr FOR &strfor
            CASE prnext = "X"
               REPLACE NEXT nrest &finame WITH &expstr FOR &strfor
            CASE prrest = "X"
               REPLACE REST &finame WITH &expstr FOR &strfor
            ENDCASE
            MsgInf( aMsg[8] )
         ENDIF
      ELSE
         EXIT
      ENDIF
   ENDDO
   RestScreen( 6, 20, 14, 70, bufsc )
   Setcolor( oldc )

   RETURN Nil

FUNCTION C_DELE( prdel )

   LOCAL bufsc, oldc, nrec, fname := Space( 45 )
   PRIVATE strfor := Space( 120 )
   PRIVATE prall, prnext, prrest, nrest, msknop := { "X", " ", " " }

   bufsc := SaveScreen( 7, 20, 14, 70 )
   oldc  := Setcolor()
   SET COLOR TO + W/GR, N +/ W, , , + W/GR
   @  7, 20, 14, 70 BOX "�Ŀ����� "
   @  8, 25 SAY iif( prdel, aMsg[25], aMsg[26] ) + aMsg[27]
   VvScope( 9, 22 )
   @ 12, 22 SAY "FOR"
   @ 13, 22 GET strfor PICTURE "@S46"
   READ
   IF LastKey() <> 27
      IF .NOT. Empty( strfor ) .AND. Type( strfor ) <> "L"
         MsgSay( aMsg[4] )
      ELSE
         IF Empty( strfor )
            strfor := ".T."
         ENDIF
         MsgInf( aMsg[7] )
         DO CASE
         CASE prall = "X"
            IF prdel
               DELETE ALL FOR &strfor
            ELSE
               RECALL ALL FOR &strfor
            ENDIF
         CASE prnext = "X"
            IF prdel
               DELETE NEXT nrest FOR &strfor
            ELSE
               RECALL NEXT nrest FOR &strfor
            ENDIF
         CASE prrest = "X"
            IF prdel
               DELETE REST FOR &strfor
            ELSE
               RECALL REST FOR &strfor
            ENDIF
         ENDCASE
         MsgInf( aMsg[8] )
      ENDIF
   ENDIF
   RestScreen( 7, 20, 14, 70, bufsc )
   Setcolor( oldc )

   RETURN Nil

FUNCTION C_COUN

   LOCAL bufsc, oldc, nrec, nrez
   PRIVATE strfor := Space( 120 )
   PRIVATE prall, prnext, prrest, nrest, msknop := { "X", " ", " " }

   bufsc := SaveScreen( 6, 20, 14, 70 )
   oldc  := Setcolor()
   SET COLOR TO + W/GR, N +/ W, , , + W/GR
   @  6, 20, 14, 70 BOX "�Ŀ����� "
   DO WHILE .T.
      @  8, 22 SAY aMsg[28]
      VvScope( 9, 22 )
      @ 12, 22 SAY "FOR"
      @ 13, 22 GET strfor PICTURE "@S46"
      READ
      IF LastKey() <> 27
         IF .NOT. Empty( strfor ) .AND. Type( strfor ) <> "L"
            MsgSay( aMsg[4] )
         ELSE
            IF Empty( strfor )
               strfor := ".T." + Space( 117 )
            ENDIF
            MsgInf( aMsg[7] )
            DO CASE
            CASE prall = "X"
               COUNT TO nrez ALL FOR &strfor
            CASE prnext = "X"
               COUNT TO nrez NEXT nrest FOR &strfor
            CASE prrest = "X"
               COUNT TO nrez REST FOR &strfor
            ENDCASE
            MsgInf( aMsg[8] )
            MsgSay( Str( nrez, 10 ) + aMsg[27] )
         ENDIF
      ELSE
         EXIT
      ENDIF
   ENDDO
   RestScreen( 6, 20, 14, 70, bufsc )
   Setcolor( oldc )

   RETURN Nil

FUNCTION C_SUM

   LOCAL bufsc, oldc, nrec, blsum, blfor
   PRIVATE strfor := Space( 120 ), expstr := Space( 80 ), nrez
   PRIVATE prall, prnext, prrest, nrest, msknop := { "X", " ", " " }

   bufsc := SaveScreen( 6, 20, 14, 70 )
   oldc  := Setcolor()
   SET COLOR TO + W/GR, N +/ W, , , + W/GR
   @  6, 20, 14, 70 BOX "�Ŀ����� "
   DO WHILE .T.
      @  7, 22 SAY aMsg[29]
      @  8, 22 SAY aMsg[30] GET expstr PICTURE "@S42"
      VvScope( 9, 22 )
      @ 12, 22 SAY "FOR"
      @ 13, 22 GET strfor PICTURE "@S46"
      READ
      IF LastKey() <> 27
         IF ( .NOT. Empty( strfor ) .AND. Type( strfor ) <> "L" ) .OR. Type( expstr ) <> "N"
            MsgSay( aMsg[4] )
         ELSE
            IF Empty( strfor )
               strfor := ".T." + Space( 117 )
            ENDIF
            nrez  := 0
            blsum := &( "{||nrez:=nrez+" + expstr + "}" )
            blfor := &( "{||" + strfor + "}" )
            MsgInf( aMsg[7] )
            DO CASE
            CASE prall = "X"
               dbEval( blsum, blfor )
            CASE prnext = "X"
               dbEval( blsum, blfor, , nrest )
            CASE prrest = "X"
               dbEval( blsum, blfor, , , , .T. )
            ENDCASE
            MsgInf( aMsg[8] )
            MsgSay( aMsg[6] + Str( nrez, 18, 4 ) )
         ENDIF
      ELSE
         EXIT
      ENDIF
   ENDDO
   RestScreen( 6, 20, 14, 70, bufsc )
   Setcolor( oldc )

   RETURN Nil

FUNCTION C_APPE

   LOCAL bufsc, oldc, nrec, fname := Space( 45 ), fielname := Space( 200 ), af, blfor, sword
   LOCAL i, j, aFie, xVal, arr, s, nOverf := 0, oldDf
   LOCAL han, stroka, strbuf := Space(STR_BUFLEN), poz := STR_BUFLEN+1
   PRIVATE strfor := Space( 120 ), finame := Space( 8 ), expstr := Space( 80 )
   PRIVATE prdbf, prsdf, prdelim, cdelim := " ", cdelim2 := ",", prcsv, cquo := '"', cDateF := dformat, msknop1 := { "X", " ", " ", " " }

   bufsc := SaveScreen( 6, 20, 16, 70 )
   oldc  := Setcolor()
   SET COLOR TO + W/GR, N +/ W, , , + W/GR
   @  6, 20, 16, 70 BOX "�Ŀ����� "
   @  7, 22 SAY aMsg[31] GET fname PICTURE Replicate( 'X', 35 )
   @  8, 22 SAY aMsg[32] GET fielname PICTURE "@S30"
   VvType( 9, 22 )
   @ 15, 22 SAY "FOR"
   @ 15, 26 GET strfor PICTURE "@S42"
   READ
   IF LastKey() <> 27
      IF .NOT. Empty( strfor ) .AND. Type( strfor ) <> "L"
         MsgSay( aMsg[5] )
      ELSE
         IF Empty( strfor )
            strfor := ".T." + Space( 117 )
         ENDIF
         MsgInf( aMsg[7] )
         IF !( Left( fname, 1 ) $ '\/' )
            fname := mypath + iif( !Empty( mypath ) .AND. !( Right( mypath, 1 ) $ '\/' ), '\', "" ) + fname
         ENDIF
         blfor := &( "{||" + Trim( strfor ) + "}" )

         IF !Empty( fielname )
            af := hb_aTokens( Trim( fielname ), "," )
         ENDIF

         DO CASE
         CASE prdbf = "X"
            __dbApp( Trim( fname ), af, blfor, , , , .F. )
         CASE prsdf = "X"
            __dbSdf( .F. , Trim( fname ), af, blfor, , , , .F. )
         CASE prdelim = "X"
            __dbDelim( .F. , Trim( fname ), iif( cdelim = " ", "blank", cdelim ), af, blfor, , , , .F. )
         CASE prcsv = "X"
            aFie := dbStruct()
            IF Empty( af )
               af := Array( Len( aFie ) )
               FOR i := 1 TO Len( af )
                  af[i] := i
               NEXT
            ELSE
               FOR i := 1 TO Len( af )
                  af[i] := Ascan( aFie, {|a|Upper(a[1])==Upper(af[i])} )
               NEXT
            ENDIF
            IF ( han := FOpen( fname, FO_READ + FO_SHARED ) ) != -1
               j := 0
               oldDf := Set( _SET_DATEFORMAT, Trim(cDateF) )
               DO WHILE .T.
                  s := RdStr( han, @strbuf, @poz, STR_BUFLEN )
                  IF Empty( s )
                     EXIT
                  ELSE
                     IF j % 2 == 1
                        stroka += s
                     ELSE
                        stroka := s
                     ENDIF
                     i := 1; j := 0
                     DO WHILE ( i := hb_At( cQuo,stroka,i ) ) != 0
                        i ++; j ++
                     ENDDO
                     IF j % 2 == 0
                        arr := hb_aTokens( stroka, cDelim2, .T. )
                        APPEND BLANK
                        FOR i := 1 TO Len(arr)
                           IF i <= Len( af )
                              xVal := arr[i]
                              IF Left( xVal,1 ) == cQuo
                                 xVal := Substr( xVal, 2, Len(xVal)-2 )
                              ENDIF
                              IF cQuo+cQuo $ arr[i]
                                 xVal := Strtran( xVal, cQuo+cQuo, cQuo )
                              ENDIF
                              IF aFie[af[i],2] == "N"
                                 IF Len( xVal ) > aFie[af[i],3]
                                    IF nOverf == 0
                                       IF MsgYesNo( "Numeric field overflow! Continue?" )
                                          nOverf := 1
                                       ELSE
                                          nOverf := 2
                                          EXIT
                                       ENDIF
                                    ENDIF
                                    IF nOverf == 0
                                       xVal := "0"
                                    ENDIF
                                 ENDIF
                                 FieldPut( af[i], Val(xVal) )
                              ELSEIF aFie[af[i],2] == "D"
                                 FieldPut( af[i], Ctod(xVal) )
                              ELSEIF aFie[af[i],2] == "L"
                                 FieldPut( af[i], ( xVal="T" ) )
                              ELSEIF aFie[af[i],2] == "C"
                                 FieldPut( af[i], Left( xVal, aFie[af[i],3] ) )
                              ELSEIF aFie[af[i],2] == "M"
                                 FieldPut( af[i], xVal )
                              ENDIF
                           ENDIF
                        NEXT
                        IF nOverf == 2
                           EXIT
                        ENDIF
                     ENDIF
                  ENDIF
               ENDDO
               Set( _SET_DATEFORMAT, oldDf )
               FClose( han )
            ENDIF
         ENDCASE
         MsgInf( aMsg[8] )
         GO TOP
         LI_NSTR := 1
      ENDIF
   ENDIF
   RestScreen( 6, 20, 16, 70, bufsc )
   Setcolor( oldc )

   RETURN Nil

FUNCTION C_COPY

   LOCAL bufsc, oldc, nrec, fname := Space( 45 ), fielname := Space( 200 ), af, blfor, sword
   LOCAL i, aFie, han, s, xVal, l, oldDf
   PRIVATE strfor := Space( 120 ), finame := Space( 8 ), expstr := Space( 80 )
   PRIVATE prall, prnext, prrest, nrest, msknop := { "X", " ", " " }
   PRIVATE prdbf, prsdf, prdelim, cdelim := " ", cdelim2 := ",", prcsv, cquo := '"', cDateF := dformat, msknop1 := { "X", " ", " ", " " }

   bufsc := SaveScreen( 6, 20, 16, 70 )
   oldc  := Setcolor()
   SET COLOR TO + W/GR, N +/ W, , , + W/GR
   @  6, 20, 16, 70 BOX "�Ŀ����� "
   @  7, 22 SAY aMsg[33] GET fname PICTURE Replicate( 'X', 35 )
   @  8, 22 SAY aMsg[32] GET fielname PICTURE "@S30"
   VvType( 9, 22 )
   VvScope( 9, 45 )
   @ 15, 22 SAY "FOR"
   @ 15, 26 GET strfor PICTURE "@S42"
   READ
   IF LastKey() <> 27
      IF .NOT. Empty( strfor ) .AND. Type( strfor ) <> "L"
         MsgSay( aMsg[4] )
      ELSE
         IF Empty( strfor )
            strfor := ".T." + Space( 117 )
         ENDIF
         MsgInf( aMsg[7] )
         IF !( Left( fname, 1 ) $ '\/' )
            fname := mypath + iif( !Empty( mypath ) .AND. !( Right( mypath, 1 ) $ '\/' ), '\', "" ) + fname
         ENDIF
         blfor := &( "{||" + Trim( strfor ) + "}" )
         af  := Nil
         IF !Empty( fielname )
            af := hb_aTokens( Trim( fielname ), "," )
         ENDIF
         DO CASE
         CASE prdbf = "X" .AND. prall = "X"
            __dbCopy( Trim( fname ), af, blfor, , , , .F. )
         CASE prdbf = "X" .AND. prnext = "X"
            __dbCopy( Trim( fname ), af, blfor, , nrest, , .F. )
         CASE prdbf = "X" .AND. prrest = "X"
            __dbCopy( Trim( fname ), af, blfor, , , , .T. )
         CASE prsdf = "X" .AND. prall = "X"
            __dbSdf( .T. , Trim( fname ), af, blfor, , , , .F. )
         CASE prsdf = "X" .AND. prnext = "X"
            __dbSdf( .T. , Trim( fname ), af, blfor, , nrest, , .F. )
         CASE prsdf = "X" .AND. prrest = "X"
            __dbSdf( .T. , Trim( fname ), af, blfor, , , , .T. )
         CASE prdelim = "X" .AND. prall = "X"
            __dbDelim( .T. , Trim( fname ), iif( cdelim = " ", "blank", cdelim ), af, blfor, , , , .F. )
         CASE prdelim = "X" .AND. prnext = "X"
            __dbDelim( .T. , Trim( fname ), iif( cdelim = " ", "blank", cdelim ), af, blfor, , nrest, , .F. )
         CASE prdelim = "X" .AND. prrest = "X"
            __dbDelim( .T. , Trim( fname ), iif( cdelim = " ", "blank", cdelim ), af, blfor, , , , .T. )
         CASE prcsv = "X"
            han := FCreate( fname )
            aFie := dbStruct()
            IF Empty( af )
               af := Array( Len( aFie ) )
               FOR i := 1 TO Len( af )
                  af[i] := i
               NEXT
            ELSE
               FOR i := 1 TO Len( af )
                  af[i] := Ascan( aFie, {|a|Upper(a[1])==Upper(af[i])} )
               NEXT
            ENDIF
            IF prall = "X"
               GO TOP
            ENDIF
            oldDf := Set( _SET_DATEFORMAT, Trim(cDateF) )
            DO WHILE !Eof()
               IF Empty( blFor ) .OR. Eval( blFor )
                  s := ""
                  FOR i := 1 TO Len( af )
                     xVal := FieldGet( af[i] )
                     xVal := Iif( aFie[i,2]=="N", Ltrim(Str(xval)), ;
                        Iif( aFie[i,2]=="D", Dtoc(xVal),;
                        Iif( aFie[i,2]=="L", Iif(xVal,"T","F"), Trim(xVal) ) ) )
                     IF ( i==Len(af).AND.Empty(xVal) ) .OR. ( l := (cQuo $ xVal) ) ;
                           .OR. cDelim2 $ xVal .OR. Chr(13)+Chr(10) $ xVal
                        IF l
                           xVal := Strtran( xVal, cQuo, cQuo+cQuo )
                        ENDIF
                        s += Iif( i>1,cDelim2,'' ) + cQuo + xVal + cQuo
                     ELSE
                        s += Iif( i>1,cDelim2,'' ) + xVal
                     ENDIF
                  NEXT
                  FWrite( han, s + Chr(13) + Chr(10) )
                  IF prnext = "X" .AND. --nRest == 0
                     EXIT
                  ENDIF
               ENDIF
               SKIP
            ENDDO
            Set( _SET_DATEFORMAT, oldDf )
            FClose( han )
         ENDCASE
         MsgInf( aMsg[8] )
         GO TOP
         LI_NSTR := 1
      ENDIF
   ENDIF
   RestScreen( 6, 20, 16, 70, bufsc )
   Setcolor( oldc )

   RETURN Nil

FUNCTION C_REIN

   IF ! aFiles[ improc,AF_EXCLU ]
      IF !FileLock()
         KEYBOARD Chr( 27 )
         RETURN Nil
      ENDIF
   ENDIF
   MsgInf( aMsg[7] )
   REINDEX
   MsgInf( aMsg[8] )

   RETURN Nil

FUNCTION C_PACK

   IF MsgYesNo( aMsg[34] )
      IF !aFiles[ improc,AF_EXCLU ]
         IF .NOT. FileLock()
            KEYBOARD Chr( 27 )
            RETURN Nil
         ENDIF
      ENDIF
      MsgInf( aMsg[7] )
      PACK
      MsgInf( aMsg[35] )
   ENDIF

   RETURN Nil

FUNCTION C_ZAP

   IF MsgYesNo( aMsg[36] )
      IF !aFiles[ improc,AF_EXCLU ]
         IF .NOT. FileLock()
            KEYBOARD Chr( 27 )
            RETURN Nil
         ENDIF
      ENDIF
      ZAP
   ENDIF

   RETURN Nil

FUNCTION C_SETR

   LOCAL bufsc, oldc, i, j, expstr := Space( 80 ), bexp, fname := Space( 10 )

   bufsc := SaveScreen( 6, 20, 13, 70 )
   oldc  := Setcolor()
   SET COLOR TO + W/GR, N +/ W, , , + W/GR
   @  6, 20, 13, 70 BOX "�Ŀ����� "
   FOR i := 1 TO 3
      @  6 + i, 22 SAY "TO "
      @  6 + i, 25 SAY PadR( dbRelation( i ), 30 ) COLOR "+W/RB"
      @  6 + i, 55 SAY " INTO "
      @  6 + i, 61 SAY iif( ( j := dbRSelect( i ) ) = 0, Space( 9 ), PadR( Alias( j ), 9 ) ) COLOR "+W/RB"
   NEXT
   @ 10, 22 TO 10, 68
   @ 11, 22 SAY "TO  " GET expstr PICTURE "@S40"
   @ 12, 22 SAY "INTO" GET fname  WHEN Vldareas( @fname, .F. )
   READ
   IF LastKey() <> 27
      expstr := Trim( expstr )
      IF Empty( expstr )
#ifdef __HARBOUR__
         DBCLEARRELATION()
#else
         DBCLEARREL()
#endif
      ELSE
         bexp := &( "{||" + expstr + "}" )
         DBSETRELATION( fname, bexp, expstr )
      ENDIF
   ENDIF
   RestScreen( 6, 20, 13, 70, bufsc )
   Setcolor( oldc )

   RETURN Nil

FUNCTION Vldareas( varget, lCurr )

   LOCAL i, j := 1, bufsc, msalias[ m->lenmsf ], rez

   bufsc := SaveScreen( 7, 32, 14, 48 )
   @  7, 32, 14, 48 BOX "�Ŀ����� "
   FOR i := 1 TO m->lenmsf
      IF aFiles[ i,AF_NAME ] != Nil .AND. ( i != improc .OR. lCurr )
         msalias[ j ] = Alias( i )
         j ++
      ENDIF
   NEXT
   rez := iif( j == 1, 0, MainMenu( 8, 33, 13, 47, msalias ) )
   IF rez == 0
      IF !lCurr
         KEYBOARD Chr( 27 )
      ENDIF
   ELSE
      varget := Iif( lCurr, Select( msalias[ rez ] ), msalias[ rez ] )
   ENDIF
   RestScreen( 7, 32, 14, 48, bufsc )

   RETURN .F.

FUNCTION VvScope( y, x )

   prall  := "X"
   prnext := prrest := " "
   nrest  := 1
   @ y, x          SAY "[ ] All"
   @ y + 1, x      SAY "[ ] Next"
   @ y + 2, x      SAY "[ ] Rest"
   @ y, x + 1      GET prall      PICTURE "X"      VALID VldScope( prall, 1, y, x )
   @ y + 1, x + 1  GET prnext     PICTURE "X"      VALID VldScope( prnext, 2, y, x )
   @ y + 1, x + 10 GET nrest      PICTURE "999999" WHEN prnext == "X"
   @ y + 2, x + 1  GET prrest     PICTURE "X"      VALID VldScope( prrest, 3, y, x )

   RETURN Nil

FUNCTION VldScope( knopka, iknop, y, x )

   IF .NOT. ( knopka $ " X" )
      RETURN .F.
   ENDIF
   IF LastKey() = 32
      AFill( msknop, " " )
      msknop[ iknop ] = "X"
      prall  := msknop[ 1 ]
      prnext := msknop[ 2 ]
      prrest := msknop[ 3 ]
      @ y, x + 1     SAY prall
      @ y + 1, x + 1 SAY prnext
      @ y + 2, x + 1 SAY prrest
   ENDIF

   RETURN .T.

FUNCTION VvType( y, x )

   prdbf := "X"
   prsdf := prdelim := prcsv := " "
   @ y, x      SAY "[ ] DBF"
   @ y+1, x    SAY "[ ] SDF"
   @ y+2, x    SAY "[ ] Delimited"
   @ y+3, x    SAY "[ ] CSV"
   @ y, 23     GET prdbf   PICTURE "X" VALID VldType( prdbf, 1, y, x )
   @ y+1, x+1  GET prsdf   PICTURE "X" VALID VldType( prsdf, 2, y, x )
   @ y+2, x+1  GET prdelim PICTURE "X" VALID VldType( prdelim, 3, y, x )
   @ y+2, x+14 SAY "With"  GET cdelim  PICTURE "X" WHEN prdelim == "X"
   @ y+3, x+1  GET prcsv PICTURE "X" VALID VldType( prcsv, 4, y, x )
   @ y+3, x+9 SAY "delimiter" GET cDelim2 PICTURE "X" WHEN prcsv == "X"
   @ y+4, x+9 SAY "quote" GET cquo  PICTURE "X" WHEN prcsv == "X"
   @ y+5, x+1 SAY "date format" GET cDateF PICTURE "XXXXXXXXXX" WHEN prcsv == "X"

   RETURN Nil

FUNCTION VldType( knopka, iknop, y, x )

   IF .NOT. ( knopka $ " X" )
      RETURN .F.
   ENDIF
   IF LastKey() = 32
      AFill( msknop1, " " )
      msknop1[ iknop ] = "X"
      prdbf   := msknop1[ 1 ]
      prsdf   := msknop1[ 2 ]
      prdelim := msknop1[ 3 ]
      prcsv   := msknop1[ 4 ]
      @ y, x + 1     SAY prdbf
      @ y+1, x+1 SAY prsdf
      @ y+2, x+1 SAY prdelim
      @ y+3, x+1 SAY prcsv
   ENDIF

   RETURN .T.

FUNCTION Vldfield( varget )

   LOCAL i, bufsc

   bufsc := SaveScreen( 8, 32, 17, 48 )
   @  8, 32, 17, 48 BOX "�Ŀ����� "
   i := MainMenu( 9, 33, 16, 47, afiel )
   IF i = 0
      KEYBOARD Chr( 27 )
   ELSE
      varget := afiel[ i ]
   ENDIF
   RestScreen( 8, 32, 17, 48, bufsc )

   RETURN .F.

FUNCTION RUnLock

   UNLOCK

   RETURN Nil

FUNCTION MemoFuncs

   LOCAL choic   := 1, bufscr
   LOCAL submenu := { " PACK", " CONVERT TO DBT" }
   LOCAL aDostup := { .T. , .T. }
   LOCAL kolf    := FCount(), m1, m2
   LOCAL fpath   := FilePath( aFiles[ improc,AF_NAME ] )
   LOCAL fname   := fpath + "____dbc.dbf", memoname

   m1 := Array( kolf )
   m2 := Array( kolf )
   AFields( m1, m2 )
   IF !aFiles[ improc,AF_EXCLU ] .OR. ASCAN( m2, "M" ) == 0
      aDostup[ 1 ] := aDostup[ 2 ] := .F.
   ENDIF
   IF aFiles[ improc,AF_DRIVER ] == 2
      submenu[ 2 ] = Stuff( submenu[ 2 ], 13, 3, "FPT" )
   ENDIF
   DO WHILE .T.
      SET COLOR TO + GR/B, N/BG, , , N/B
      @ 16, 50, 19, 67 BOX "�Ŀ����� "
      choic := MainMenu( 17, 51, 18, 66, submenu, aDostup, , 1, 1 )
      IF choic = 0 .OR. lenmsf = 0 .OR. choic = 501
         RETURN choic
      ENDIF
      DO CASE
      CASE choic = 1
         IF File( fname ) .AND. FErase( fname ) == - 1
            Alert( "Can't create temporary file" )
         ELSE
            __dbCopy( fname, , { || !Deleted() }, , , , .F. )
            dbCloseArea()
            IF FErase( aFiles[ improc,AF_NAME ] ) == - 1
               Alert( "Can't erase file " + aFiles[ improc,AF_NAME ] + " : " + Str( FError(), 2 ) )
            ELSEIF FRename( fname, aFiles[ improc,AF_NAME ] ) == - 1
               Alert( "Can't rename file to " + aFiles[ improc,AF_NAME ] + " : " + Str( FError(), 2 ) )
            ELSE
               memoname := CutExten( aFiles[ improc,AF_NAME ] ) + ;
                  Iif( aFiles[ improc,AF_DRIVER ] == 1, ".FPT", ".DBT" )
               IF FErase( memoname ) == - 1
                  Alert( "Can't erase file " + memoname + " : " + Str( FError(), 2 ) )
               ELSEIF FRename( fpath + "____dbc." + Iif( aFiles[ improc,AF_DRIVER ] == 1, "FPT", "DBT" ), memoname ) == - 1
                  Alert( "Can't rename file to " + memoname + " : " + Str( FError(), 2 ) )
               ENDIF
            ENDIF
            dbUseArea( , aDrivers[ aFiles[ improc,AF_DRIVER ] ], aFiles[ improc,AF_NAME ], , !aFiles[ improc,AF_EXCLU ], aFiles[ improc,AF_RDONLY ] )
         ENDIF
      CASE choic = 2
      ENDCASE
      KEYBOARD Chr( 27 )
      EXIT
   ENDDO

   RETURN Nil
