/*
 * $Id: procscri.prg,v 1.13 2007/05/08 10:40:09 alkresin Exp $
 *
 * Common procedures
 * Scripts
 *
 * Author: Alexander S.Kresin <alex@kresin.ru>
 *         www - http://www.kresin.ru
*/

#include "fileio.ch"
// #define __WINDOWS__
#ifndef __NO_HWGUI__
   #ifndef __NO_GUIDEBUG__
      #define __GUIDEBUGGER__
   #endif
#endif

#ifdef __LINUX__
   #define DEF_SEP      '/'
   #define DEF_CH_SEP   '/'
#else
   #define DEF_SEP      '/'
   #define DEF_CH_SEP   '/'
#endif

MEMVAR iscr

STATIC nLastError, numlin
STATIC lDebugInfo := .F.

#ifndef __WINDOWS__
STATIC y__size := 0, x__size := 0
#endif
#define STR_BUFLEN  1024

#ifndef __XHARBOUR__
REQUEST __PP_STDRULES
REQUEST OS
//REQUEST HB_COMPILER
REQUEST HB_VERSION
#endif

Function Procscri()
   RETURN Nil

FUNCTION OpenScript( fname, scrkod )

LOCAL han, stroka, scom, aScr, rejim := 0, i
LOCAL strbuf    := Space( STR_BUFLEN ), poz := STR_BUFLEN + 1
LOCAL aFormCode, aFormName

   scrkod := Iif( scrkod == Nil, "000", Upper( scrkod ) )
   IF DEF_CH_SEP $ fname
      fname := StrTran( fname, DEF_CH_SEP, DEF_SEP )
   ENDIF
   han := Fopen( fname, FO_READ + FO_SHARED )
   IF han != - 1
      DO WHILE .T.
         stroka := RDSTR( han, @strbuf, @poz, STR_BUFLEN )
         IF Len( stroka ) = 0
            EXIT
         ELSEIF rejim == 0 .AND. Left( stroka, 1 ) == "#"
            IF Upper( Left( stroka, 7 ) ) == "#SCRIPT"
               scom := Upper( Ltrim( Substr( stroka, 9 ) ) )
               IF scom == scrkod
                  aScr := RdScript( han, @strbuf, @poz,, fname + "," + scrkod )
                  EXIT
               ENDIF
            ELSEIF Left( stroka, 6 ) == "#BLOCK"
               scom := Upper( Ltrim( Substr( stroka, 8 ) ) )
               IF scom == scrkod
                  rejim     := - 1
                  aFormCode := {}
                  aFormName := {}
               ENDIF
            ENDIF
         ELSEIF rejim == - 1 .AND. Left( stroka, 1 ) == "@"
            i := At( " ", stroka )
            Aadd( aFormCode, Substr( stroka, 2, i - 2 ) )
            Aadd( aFormName, Substr( stroka, i + 1 ) )
         ELSEIF rejim == - 1 .AND. Left( stroka, 9 ) == "#ENDBLOCK"
#ifdef __WINDOWS__
            i := hwg_WChoice( aFormName )
#else
            IF Type( "FCHOICE()" ) == "UI"
               i := Eval( &("{|a|Fchoice(a)}"), aFormName )
            ENDIF
#endif
            IF i == 0
               Fclose( han )
               RETURN Nil
            ENDIF
            rejim  := 0
            scrkod := aFormCode[ i ]
         ENDIF
      ENDDO
      Fclose( han )
   ELSE
#ifdef __WINDOWS__
      hwg_Msgstop( fname + " can't be opened " )
#else
      Alert( fname + " can't be opened " )
#endif
      RETURN Nil
   ENDIF
RETURN aScr

FUNCTION RdScript( scrSource, strbuf, poz, lppNoInit, cTitle )

LOCAL han
LOCAL rezArray := Iif( lDebugInfo, { "", {}, {} }, { "", {} } )

   IF lppNoInit == Nil
      lppNoInit := .F.
   ENDIF
   IF poz == Nil
      poz := 1
   ENDIF
   IF cTitle != Nil
      rezArray[ 1 ] := cTitle
   ENDIF
   nLastError := 0
   IF scrSource == Nil
      han := Nil
      poz := 1
   ELSEIF Valtype( scrSource ) == "C"
      strbuf := Space( STR_BUFLEN )
      poz := STR_BUFLEN + 1
      IF DEF_CH_SEP $ scrSource
         scrSource := StrTran( scrSource, DEF_CH_SEP, DEF_SEP )
      ENDIF
      han := Fopen( scrSource, FO_READ + FO_SHARED )
   ELSE
      han := scrSource
   ENDIF
   IF han == Nil .OR. han != - 1
      IF !lppNoInit
         ppScript( ,.T. )
      ENDIF
      IF Valtype( scrSource ) == "C"
         WndOut( "Compiling ..." )
         WndOut( "" )
      ENDIF
      numlin := 0
      IF !CompileScr( han, @strbuf, @poz, rezArray, scrSource )
         rezArray := Nil
      ENDIF
      IF scrSource != Nil .AND. Valtype( scrSource ) == "C"
         WndOut()
         Fclose( han )
      ENDIF
      IF !lppNoInit
         ppScript( ,.F. )
      ENDIF
   ELSE
#ifdef __WINDOWS__
      hwg_Msgstop( "Can't open " + scrSource )
#else
      WndOut( "Can't open " + scrSource )
      WAIT ""
      WndOut()
#endif
      nLastError := - 1
      RETURN Nil
   ENDIF
RETURN rezArray

FUNCTION ppScript( stroka, lNew )
STATIC s_pp

   IF lNew != Nil
      s_pp := Iif( lNew, __pp_init(), Nil )
      RETURN Nil
   ENDIF
RETURN __pp_process( s_pp, stroka )

STATIC FUNCTION COMPILESCR( han, strbuf, poz, rezArray, scrSource )

LOCAL scom, poz1, stroka, strfull := "", bOldError, i, tmpArray := {}
LOCAL cLine, lDebug := ( Len( rezArray ) >= 3 )

   DO WHILE .T.
      cLine := RDSTR( han, @strbuf, @poz, STR_BUFLEN )
      IF Len( cLine ) = 0
         EXIT
      ENDIF
      numlin ++
      IF Right( cLine, 1 ) == ';'
         strfull += Left( cLine, Len( cLine ) - 1 )
         LOOP
      ELSE
         IF !Empty( strfull )
            cLine := strfull + cLine
         ENDIF
         strfull := ""
      ENDIF
      stroka := Rtrim( Ltrim( cLine ) )
      IF Right( stroka, 1 ) == Chr( 26 )
         stroka := Left( stroka, Len( stroka ) - 1 )
      ENDIF
      IF !Empty( stroka ) .AND. Left( stroka, 2 ) != "//"

         IF Left( stroka, 1 ) == "#"
            IF Upper( Left( stroka, 7 ) ) == "#ENDSCR"
               RETURN .T.
            ELSEIF Upper( Left( stroka, 6 ) ) == "#DEBUG"
               IF !lDebug .AND. Len( rezArray[ 2 ] ) == 0
                  lDebug := .T.
                  Aadd( rezArray, {} )
                  IF Substr( stroka, 7, 3 ) == "GER"
                     Aadd( rezArray[ 2 ], stroka )
                     Aadd( tmpArray, "" )
                     Aadd( rezArray[ 3 ], Str( numlin, 4 ) + ":" + cLine )
                  ENDIF
               ENDIF
               LOOP
#ifdef __HARBOUR__
            ELSE
               ppScript( stroka )
               LOOP
#endif
            ENDIF
#ifdef __HARBOUR__
         ELSE
            stroka := ppScript( stroka )
#endif
         ENDIF

         poz1 := At( " ", stroka )
         scom := Upper( Substr( stroka, 1, Iif( poz1 <> 0, poz1 - 1, 999 ) ) )
         DO CASE
         CASE scom == "PRIVATE" .OR. scom == "PARAMETERS" .OR. scom == "LOCAL"
            IF Len( rezArray[ 2 ] ) == 0 .OR. ( i := Valtype( ATAIL( rezArray[ 2 ] ) ) ) == "C" ;
                    .OR. i == "A"
               IF Left( scom,2 ) == "LO"
                  AADD( rezArray[2], " "+ALLTRIM( SUBSTR( stroka, 7 ) ) )     
               ELSEIF Left( scom,2 ) == "PR"
                  AADD( rezArray[2], " "+ALLTRIM( SUBSTR( stroka, 9 ) ) )
               ELSE
                  Aadd( rezArray[ 2 ], "/" + Alltrim( Substr( stroka, 12 ) ) )
               ENDIF
               Aadd( tmpArray, "" )
            ELSE
               nLastError := 1
               RETURN .F.
            ENDIF
         CASE ( scom == "DO" .AND. Upper( Substr( stroka, 4, 5 ) ) == "WHILE" ) ;
                   .OR. scom == "WHILE"
            Aadd( tmpArray, stroka )
            Aadd( rezArray[ 2 ], .F. )
         CASE scom == "ENDDO"
            IF !Fou_Do( rezArray[ 2 ], tmpArray )
               nLastError := 2
               RETURN .F.
            ENDIF
         CASE scom == "EXIT"
            Aadd( tmpArray, "EXIT" )
            Aadd( rezArray[ 2 ], .F. )
         CASE scom == "LOOP"
            Aadd( tmpArray, "LOOP" )
            Aadd( rezArray[ 2 ], .F. )
         CASE scom == "IF"
            Aadd( tmpArray, stroka )
            Aadd( rezArray[ 2 ], .F. )
         CASE scom == "ELSEIF"
            IF !Fou_If( rezArray, tmpArray, .T. )
               nLastError := 3
               RETURN .F.
            ENDIF
            Aadd( tmpArray, Substr( stroka, 5 ) )
            Aadd( rezArray[ 2 ], .F. )
         CASE scom == "ELSE"
            IF !Fou_If( rezArray, tmpArray, .T. )
               nLastError := 1
               RETURN .F.
            ENDIF
            Aadd( tmpArray, "IF .T." )
            Aadd( rezArray[ 2 ], .F. )
         CASE scom == "ENDIF"
            IF !Fou_If( rezArray, tmpArray, .F. )
               nLastError := 1
               RETURN .F.
            ENDIF
         CASE scom == "RETURN"
            bOldError := Errorblock( { | e | MacroError( 1, e, stroka ) } )
            BEGIN SEQUENCE
               Aadd( rezArray[ 2 ], &( "{||EndScript(" + Ltrim( Substr( stroka, 7 ) ) + ")}" ) )
            RECOVER
               IF scrSource != Nil .AND. Valtype( scrSource ) == "C"
                  WndOut()
                  Fclose( han )
               ENDIF
               Errorblock( bOldError )
               RETURN .F.
            END SEQUENCE
            Errorblock( bOldError )
            Aadd( tmpArray, "" )
         CASE scom == "FUNCTION"
            stroka := Ltrim( Substr( stroka, poz1 + 1 ) )
            poz1   := At( "(", stroka )
            scom   := Upper( Left( stroka, Iif( poz1 != 0, poz1 - 1, 999 ) ) )
            Aadd( rezArray[ 2 ], Iif( lDebug, { scom, {}, {} }, { scom, {} } ) )
            Aadd( tmpArray, "" )
            IF !CompileScr( han, @strbuf, @poz, rezArray[ 2, Len( rezArray[ 2 ] ) ] )
               RETURN .F.
            ENDIF
         CASE scom == "#ENDSCRIPT" .OR. Left( scom, 7 ) == "ENDFUNC"
            RETURN .T.
         OTHERWISE
            bOldError := Errorblock( { | e | MacroError( 1, e, stroka ) } )
            BEGIN SEQUENCE
               Aadd( rezArray[ 2 ], &( "{||" + Alltrim( stroka ) + "}" ) )
            RECOVER
               IF scrSource != Nil .AND. Valtype( scrSource ) == "C"
                  WndOut()
                  Fclose( han )
               ENDIF
               Errorblock( bOldError )
               RETURN .F.
            END SEQUENCE
            Errorblock( bOldError )
            Aadd( tmpArray, "" )
         ENDCASE
         IF lDebug .AND. Len( rezArray[ 3 ] ) < Len( rezArray[ 2 ] )
            Aadd( rezArray[ 3 ], Str( numlin, 4 ) + ":" + cLine )
         ENDIF
      ENDIF
   ENDDO
RETURN .T.

STATIC FUNCTION MacroError( nm, e, stroka )

LOCAL n, cTitle

#ifdef __WINDOWS__
   IF nm == 1
      stroka := ErrorMessage( e ) + Chr( 10 ) + Chr( 13 ) + "in" + Chr( 10 ) + Chr( 13 ) + ;
                              Alltrim( stroka )
      cTitle := "Script compiling error"
   ELSEIF nm == 2
      stroka := ErrorMessage( e )
      cTitle := "Script variables error"
   ELSEIF nm == 3
      n := 2
      WHILE !Empty( Procname( n ) )
         stroka += Chr( 13 ) + Chr( 10 ) + "Called from " + Procname( n ) + "(" + Alltrim( Str( Procline( n ++ ) ) ) + ")"
      ENDDO
      stroka := ErrorMessage( e ) + Chr( 10 ) + Chr( 13 ) + stroka
      cTitle := "Script execution error"
   ENDIF
   stroka += Chr( 13 ) + Chr( 10 ) + Chr( 13 ) + Chr( 10 ) + "Continue ?"
   IF !hwg_Msgyesno( stroka, cTitle )
      hwg_EndWindow()
      QUIT
   ENDIF
#else
   IF nm == 1
      Alert( "Error in;" + Alltrim( stroka ) )
   ELSEIF nm == 2
      Alert( "Script variables error" )
   ELSEIF nm == 3
      stroka += ";" + ErrorMessage( e )
      n      := 2
      WHILE !Empty( Procname( n ) )
         stroka += ";Called from " + Procname( n ) + "(" + Alltrim( Str( Procline( n ++ ) ) ) + ")"
      ENDDO
      Alert( "Script execution error:;" + stroka )
   ENDIF
#endif
   BREAK
RETURN .T.

STATIC FUNCTION Fou_If( rezArray, tmpArray, prju )

LOCAL i, j, bOldError

   IF prju
      Aadd( tmpArray, "JUMP" )
      Aadd( rezArray[ 2 ], .F. )
      IF Len( rezArray ) >= 3
         Aadd( rezArray[ 3 ], Str( numlin, 4 ) + ":JUMP" )
      ENDIF
   ENDIF
   j := Len( rezArray[ 2 ] )
   FOR i := j TO 1 STEP - 1
      IF Upper( Left( tmpArray[ i ], 2 ) ) == "IF"
         bOldError := Errorblock( { | e | MacroError( 1, e, tmpArray[ i ] ) } )
         BEGIN SEQUENCE
            rezArray[ 2, i ] := &( "{||IIF(" + Alltrim( Substr( tmpArray[ i ], 4 ) ) + ;
                                   ",.T.,iscr:=" + Ltrim( Str( j, 5 ) ) + ")}" )
         RECOVER
            Errorblock( bOldError )
            RETURN .F.
         END SEQUENCE
         Errorblock( bOldError )
         tmpArray[ i ] := ""
         i --
         IF i > 0 .AND. tmpArray[ i ] == "JUMP"
            rezArray[ 2, i ] := &( "{||iscr:=" + Ltrim( Str( Iif( prju, j - 1, j ), 5 ) ) + "}" )
            tmpArray[ i ]    := ""
         ENDIF
         RETURN .T.
      ENDIF
   NEXT
RETURN .F.

STATIC FUNCTION Fou_Do( rezArray, tmpArray )

LOCAL i, j, iloop := 0, iPos, bOldError

   j := Len( rezArray )
   FOR i := j TO 1 STEP - 1
      IF !Empty( tmpArray[ i ] ) .AND. Left( tmpArray[ i ], 4 ) == "EXIT"
         rezArray[ i ] = &( "{||iscr:=" + Ltrim( Str( j + 1, 5 ) ) + "}" )
         tmpArray[ i ] = ""
      ENDIF
      IF !Empty( tmpArray[ i ] ) .AND. Left( tmpArray[ i ], 4 ) == "LOOP"
         iloop := i
      ENDIF
      IF !Empty( tmpArray[ i ] ) .AND. ;
                 ( Upper( Left( tmpArray[ i ], 8 ) ) = "DO WHILE" .OR. ;
                 Upper( Left( tmpArray[ i ], 5 ) ) = "WHILE" )
         bOldError := Errorblock( { | e | MacroError( 1, e, tmpArray[ i ] ) } )
         BEGIN SEQUENCE
            rezArray[ i ] = &( "{||IIF(" + Alltrim( Substr( tmpArray[ i ], ;
                    Iif( Upper( Left( tmpArray[ i ], 1 ) ) == "D", 10, 7 ) ) ) + ;
                    ",.T.,iscr:=" + Ltrim( Str( j + 1, 5 ) ) + ")}" )
         RECOVER
            Errorblock( bOldError )
            RETURN .F.
         END SEQUENCE
         Errorblock( bOldError )
         tmpArray[ i ] = ""
         Aadd( rezArray, &( "{||iscr:=" + Ltrim( Str( i - 1, 5 ) ) + "}" ) )
         Aadd( tmpArray, "" )
         IF iloop > 0
            rezArray[ iloop ] = &( "{||iscr:=" + Ltrim( Str( i - 1, 5 ) ) + "}" )
            tmpArray[ iloop ] = ""
         ENDIF
         RETURN .T.
      ENDIF
   NEXT
RETURN .F.

FUNCTION DoScript( aScript, aParams )

LOCAL arlen, stroka, varName, varValue, lDebug, lParam, j, lSetDebugger := .F.
MEMVAR iscr, bOldError, aScriptt, doscr_RetValue
PRIVATE iscr := 1, bOldError, doscr_RetValue := Nil

   IF Type( "aScriptt" ) != "A"
      PRIVATE aScriptt := aScript
   ENDIF
   IF aScript == Nil .OR. ( arlen := Len( aScript[ 2 ] ) ) == 0
      RETURN .T.
   ENDIF
   lDebug := ( Len( aScript ) >= 3 )
   DO WHILE Valtype( aScript[ 2, iscr ] ) != "B"
      IF Valtype( aScript[ 2, iscr ] ) == "C"
         IF Left( aScript[ 2, iscr ], 1 ) == "#"
#ifdef __GUIDEBUGGER__
            IF !SetDebugger()
               lSetDebugger := .T.
               SetDebugger(.T.)
            ENDIF
#endif
         ELSE
            stroka    := Substr( aScript[ 2, iscr ], 2 )
            lParam    := ( Left( aScript[ 2, iscr ], 1 ) == "/" )
            bOldError := Errorblock( { | e | MacroError( 2, e ) } )
            BEGIN SEQUENCE
               j := 1
               DO WHILE !Empty( varName := getNextVar( @stroka, @varValue ) )
                  PRIVATE &varName
                  IF varvalue != Nil
                     &varName := &varValue
                  ENDIF
                  IF lParam .AND. aParams != Nil .AND. Len( aParams ) >= j
                     &varname := aParams[ j ]
                  ENDIF
                  j ++
               ENDDO
            RECOVER
               WndOut()
               Errorblock( bOldError )
               RETURN .F.
            END SEQUENCE
            Errorblock( bOldError )
         ENDIF
      ENDIF
      iscr ++
   ENDDO
   IF lDebug
      bOldError := Errorblock( { | e | MacroError( 3, e, aScript[ 3, iscr ] ) } )
   ELSE
      bOldError := Errorblock( { | e | MacroError( 3, e, Ltrim( Str( iscr ) ) ) } )
   ENDIF
   BEGIN SEQUENCE
#ifdef __GUIDEBUGGER__
      IF lDebug .AND. SetDebugger()
         DO WHILE iscr > 0 .AND. iscr <= arlen
            IF SetDebugger()
               SetDebugRun(.F.)
               hwg_scrDebug( aScript, iscr )
               DO WHILE !SetDebugRun()
                  hwg_ProcessMessage()
               ENDDO
            ENDIF
            Eval( aScript[ 2, iscr ] )
            iscr ++
         ENDDO
         hwg_scrDebug( aScript, 0 )
         IF lSetDebugger
            SetDebugger(.F.)
         ENDIF
      ELSE
         DO WHILE iscr > 0 .AND. iscr <= arlen
            Eval( aScript[ 2, iscr ] )
            iscr ++
         ENDDO
      ENDIF
#else
      DO WHILE iscr > 0 .AND. iscr <= arlen
         Eval( aScript[ 2, iscr ] )
         iscr ++
      ENDDO
#endif
   RECOVER
      WndOut()
      Errorblock( bOldError )
#ifdef __GUIDEBUGGER__
      IF lDebug .AND. SetDebugger()
         hwg_scrDebug( aScript, 0 )
      ENDIF
#endif
      RETURN .F.
   END SEQUENCE
   Errorblock( bOldError )
   WndOut()

RETURN m->doscr_RetValue

FUNCTION CallFunc( cProc, aParams, aScript )

LOCAL i := 1, RetValue := Nil

   IF aScript == Nil
      aScript := m->aScriptt
   ENDIF
   cProc := Upper( cProc )
   DO WHILE i <= Len( aScript[ 2 ] ) .AND. Valtype( aScript[ 2, i ] ) == "A"
      IF aScript[ 2, i, 1 ] == cProc
         RetValue := DoScript( aScript[ 2, i ], aParams )
         EXIT
      ENDIF
      i ++
   ENDDO

RETURN RetValue

FUNCTION EndScript( xRetValue )

   m->doscr_RetValue := xRetValue
   iscr := - 99
RETURN Nil

FUNCTION CompileErr( nLine )

   nLine := numlin
RETURN nLastError

FUNCTION Codeblock( string )

   IF Left( string, 2 ) == "{|"
      RETURN &( string )
   ENDIF
RETURN &( "{||" + string + "}" )

FUNCTION SetDebugInfo( lDebug )

   lDebugInfo := Iif( lDebug == Nil, .T., lDebug )
RETURN .T.

Function RunScript( fname, scrname, args )
Local scr := OpenScript( fname, scrname )
Return Iif( scr==Nil, Nil, DoScript( scr, args ) )

#ifdef __WINDOWS__

STATIC FUNCTION WndOut()

   RETURN Nil

#else

FUNCTION WndOut( sout, noscroll, prnew )

LOCAL y1, x1, y2, x2, oldc, ly__size := ( y__size != 0 )
STATIC w__buf
   IF sout == Nil .AND. !ly__size
      RETURN Nil
   ENDIF
   IF y__size == 0
      y__size := 5
      x__size := 30
      prnew   := .T.
   ELSEIF prnew == Nil
      prnew := .F.
   ENDIF
   y1 := 13 - Int( y__size / 2 )
   x1 := 41 - Int( x__size / 2 )
   y2 := y1 + y__size
   x2 := x1 + x__size
   IF sout == Nil
      Restscreen( y1, x1, y2, x2, w__buf )
      y__size := 0
   ELSE
      oldc := Setcolor( "N/W" )
      IF prnew
         w__buf := Savescreen( y1, x1, y2, x2 )
         @ y1, x1, y2, x2 BOX "�Ŀ����� "
      ELSEIF noscroll = Nil
         Scroll( y1 + 1, x1 + 1, y2 - 1, x2 - 1, 1 )
      ENDIF
      @ y2 - 1, x1 + 2 SAY sout         
      Setcolor( oldc )
   ENDIF
RETURN Nil

FUNCTION WndGet( sout, varget, spict )

LOCAL y1, x1, y2, x2, oldc
LOCAL GetList := {}
   WndOut( sout )
   y1   := 13 - Int( y__size / 2 )
   x1   := 41 - Int( x__size / 2 )
   y2   := y1 + y__size
   x2   := x1 + x__size
   oldc := Setcolor( "N/W" )
   IF Len( sout ) + Iif( spict = "@D", 8, Len( spict ) ) > x__size - 3
      Scroll( y1 + 1, x1 + 1, y2 - 1, x2 - 1, 1 )
   ELSE
      x1 += Len( sout ) + 1
   ENDIF
   @ y2 - 1, x1 + 2 GET varget PICTURE spict        
   READ
   Setcolor( oldc )
RETURN Iif( Lastkey() = 27, Nil, varget )

FUNCTION WndOpen( ysize, xsize )

   y__size := ysize
   x__size := xsize
   WndOut( "",, .T. )
RETURN Nil
#endif
