/*
 * Common procedures
 * Browse
 *
 * Author: Alexander S.Kresin <alex@kresin.ru>
 *         www - http://www.kresin.ru/
 * Released to Public Domain
*/

#include "fileio.ch"
#include "inkey.ch"
#include "deflist.ch"

#ifdef __HARBOUR__
#define   COMPAT_53
#endif

MEMVAR str_bar, varbuf

Function procs1
RETURN Nil

#ifdef VER_MOUSE
FUNCTION DBFLIST( mslist, x1, y1, x2, y2, title, maskey, ctrl_ar )
#else
FUNCTION DBFLIST( mslist, x1, y1, x2, y2, title, maskey )
#endif

LOCAL rezproc, xkey, rez, fipos, wndbuf, predit, oldcolors
LOCAL cSeek := "", lModeSeek := .F.
LOCAL ym, xm, i
LOCAL fbar1, fbar2, vartmp, cPicture, lEdErr, razmer
LOCAL GetList := {}
LOCAL arrF12 := { "����� �����", "���������", "���������", "�����������" }
PRIVATE varbuf

   IF mslist == Nil
      mslist := InitList()
   ENDIF
   IF Type( "str_bar" ) != "C"
      PRIVATE str_bar := "��"
   ENDIF
   LI_Y1 := y1
   LI_X1 := x1
   LI_Y2 := y2
   LI_X2 := x2
   IF LI_MSF == Nil
      LI_COLCOUNT := Fcount()
   ELSE
      LI_COLCOUNT := Len( LI_MSF )
      IF LI_MSTYP == Nil
         LI_MSTYP := Array( LI_COLCOUNT )
         IF LI_MSLEN == Nil
            LI_MSLEN := Array( LI_COLCOUNT )
         ENDIF
         LI_MSDEC := Array( LI_COLCOUNT )
         FOR i := 1 TO LI_COLCOUNT
            IF Valtype( LI_MSF[ i ] ) == "B"
               vartmp        := Eval( LI_MSF[ i ], mslist, i )
               LI_MSTYP[ i ] := Valtype( vartmp )
               IF LI_MSTYP[ i ] == "C"
                  LI_MSLEN[ i ] := Len( vartmp )
               ELSEIF LI_MSTYP[ i ] $ "NIBYZ842+^"
                  vartmp := Str( vartmp )
                  LI_MSLEN[ i ] := Len( vartmp )
                  LI_MSDEC[ i ] := Iif( '.' $ vartmp, LI_MSLEN[ i ] - At( '.', vartmp ), 0 )
               ELSEIF LI_MSTYP[ i ] == "D"
                  LI_MSLEN[ i ] := 8
               ELSEIF LI_MSTYP[ i ] == "L"
                  LI_MSLEN[ i ] := 1
               ELSEIF LI_MSTYP[ i ] $ "T=@"
                  vartmp := hb_ttoc( vartmp )
                  LI_MSLEN[ i ] := Len( vartmp )
               ENDIF
            ELSE
               LI_MSTYP[ i ] := FieldType( Fieldpos( LI_MSF[ i ] ) )
            ENDIF
         NEXT
      ENDIF
   ENDIF
   IF Valtype( LI_MSED ) = "N"
      predit := LI_MSED
   ELSEIF Valtype( LI_MSED ) = "A"
      predit := 2
   ENDIF
   // SET CURSOR ( predit > 1 )
   SET CURSOR OFF
   SET EXACT OFF
   IF LI_LSOHR
      wndbuf := Savescreen( LI_Y1, LI_X1, LI_Y2, LI_X2 )
   ENDIF
   oldcolors := Setcolor()
   Setcolor( LI_CLR )
   @ LI_Y1, LI_X1, LI_Y2, LI_X2 BOX "�Ŀ����� "
   IF title <> Nil
      @ LI_Y1, ( LI_X2 - LI_X1 - 1 - Len( title ) ) / 2 + LI_X1 SAY " " + title + " "         
   ENDIF
   IF title <> Nil .AND. LI_NAMES <> Nil
      LI_Y1 ++
   ENDIF
   razmer := LI_Y2 - LI_Y1 - 1
   IF .NOT. LI_PRFLT
      LI_KOLZ := Eval( LI_RCOU, mslist )
   ENDIF
   LI_COLPOS := 1
   LI_NLEFT  := LI_FREEZE + 1
   STORE .T. TO rez
   LI_NCOLUMNS := FLDCOUNT( mslist, LI_X1 + 2, LI_X2 - 2, LI_NLEFT )
   VIVNAMES( mslist )
   IF Eval( LI_BEOF, mslist )
      Eval( LI_BGTOP, mslist )
      LI_NSTR := 1
   ELSE
      Eval( LI_BSKIP, mslist, - ( LI_NSTR - 1 ) )
      IF Eval( LI_BBOF, mslist )
         Eval( LI_BGTOP, mslist )
         LI_NSTR := 1
      ENDIF
   ENDIF
   WNDVIVOD( mslist )
   Eval( LI_BSKIP, mslist, ( LI_NSTR - 1 ) )
   IF LI_KOLZ = 0 .AND. LI_LADD
      LI_NSTR := 0
      KEYBOARD Chr( K_DOWN )
   ENDIF
   DO WHILE rez
      Setcolor( LI_CLR )
      Eval( LI_B1, mslist )
      Setcolor( LI_CLRV )               // �뤥���� ��ப�
      VIVSTR( mslist, LI_NSTR + LI_Y1, Iif( predit > 1, LI_COLPOS, 0 ) )
      Setcolor( LI_CLR )                // ����� �뤥�����
      //
      IF LI_PRFLT
         @ LI_Y1 + 2, LI_X2, LI_Y2 - 2, LI_X2 BOX Left( str_bar, 1 )
         @ LI_Y1 + 1, LI_X2  SAY Substr( str_bar, 2, 1 )
         @ LI_Y2 - 1, LI_X2  SAY Substr( str_bar, 2, 1 )         
         @ LI_Y1 + 2 + Int( LI_TEKZP * ( LI_Y2 - LI_Y1 - 4 ) / LI_KOLZ ), LI_X2 SAY Right( str_bar, 1 )
      ENDIF
      //
      IF LI_LVIEW
         xkey := 27
      ELSE
#ifdef VER_MOUSE
         xkey := IN_KM( .F. )
         IF xkey = 502
            DO WHILE M_STAT() <> 0
            ENDDO
            xkey := 27
         ELSEIF xkey = 501
            ym := M_YTEXT()
            xm := M_XTEXT()
            IF ( ym <= LI_Y1 .OR. ym >= LI_Y2 .OR. xm <= LI_X1 .OR. xm >= LI_X2 )
               IF xm <= LI_X2 .AND. xm >= LI_X1 .AND. ( ym = LI_Y1 .OR. ym = LI_Y2 )
                  M_SHOW()
                  i := Seconds()
                  DO WHILE Seconds() - i < 0.05
                  ENDDO
                  KEYBOARD Chr( Iif( ym = LI_Y1, 5, 24 ) )
                  M_HIDE()
                  LOOP
               ELSEIF ctrl_ar <> Nil
                  FOR i := 1 TO Len( ctrl_ar )
                     IF Valtype( ctrl_ar[ i ] ) = "C"
                        Setcolor( ctrl_ar[ i ] )
                     ELSE
                        rezproc := F_CTRL( ctrl_ar[ i ],,,,,, 1, ym, xm )
                        IF rezproc > 0
                           EXIT
                        ENDIF
                     ENDIF
                  NEXT
                  Setcolor( LI_CLR )
                  IF rezproc > 0
                     rezproc += 500
                     EXIT
                  ENDIF
               ENDIF
            ENDIF
         ENDIF
#else
         xkey := Inkey( 0 )
#endif
      ENDIF
      VIVSTR( mslist, LI_NSTR + LI_Y1, 0 )                  // ��ப�
      lModeSeek := .F.
      IF xkey < 500
         DO CASE
         CASE xkey = 24                 // ����� ����
            IF ( LI_KOLZ > 0 .OR. LI_LADD ) .AND. ( LI_KOLZ = 0 .OR. !Eval( LI_BEOF, mslist ) )
               Eval( LI_BSKIP, mslist, 1 )
               IF Eval( LI_BEOF, mslist ) .AND. ( !LI_LADD .OR. LI_PRFLT )
                  Eval( LI_BSKIP, mslist, - 1 )
               ELSE
                  IF Eval( LI_BEOF, mslist )
                     vartmp      := LI_NLEFT
                     LI_NLEFT    := LI_COLPOS := LI_FREEZE + 1
                     LI_NCOLUMNS := FLDCOUNT( mslist, LI_X1 + 2, LI_X2 - 2, LI_NLEFT )
                     IF vartmp > LI_FREEZE + 1
                        Eval( LI_BSKIP, mslist, - 1 )
                        Eval( LI_BSKIP, mslist, - ( LI_NSTR - 1 ) )
                        WNDVIVOD( mslist )
                        Eval( LI_BSKIP, mslist, LI_NSTR - 1 )
                        Eval( LI_BSKIP, mslist )
                     ENDIF
                  ENDIF
                  LI_NSTR ++
                  IF LI_NSTR > razmer
                     LI_NSTR := razmer
                     Scroll( LI_Y1 + 1, LI_X1 + 1, LI_Y2 - 1, LI_X2 - 1, 1 )
                     VIVSTR( mslist, LI_Y2 - 1, 0 )
                     DrawVSep( mslist )
                  ENDIF
                  IF Eval( LI_BEOF, mslist )
                     KEYBOARD Chr( 13 )
                  ENDIF
               ENDIF
            ENDIF
         CASE xkey = 5 .AND. LI_KOLZ > 0                    // ����� �����
            Eval( LI_BSKIP, mslist, - 1 )
            IF Eval( LI_BBOF, mslist )
               Eval( LI_BGTOP, mslist )
            ELSE
               LI_NSTR --
               IF LI_NSTR = 0
                  LI_NSTR := 1
                  Scroll( LI_Y1 + 1, LI_X1 + 1, LI_Y2 - 1, LI_X2 - 1, - 1 )
                  VIVSTR( mslist, LI_Y1 + 1, 0 )
                  DrawVSep( mslist )
               ENDIF
            ENDIF
         CASE xkey = 4 .AND. LI_KOLZ <> 0                   // ����� ��ࠢ�
            IF predit > 1
               IF LI_COLPOS < LI_NCOLUMNS
                  LI_COLPOS ++
                  LOOP
               ENDIF
            ENDIF
            IF LI_NCOLUMNS + LI_NLEFT - LI_FREEZE - 1 < LI_COLCOUNT
               i := LI_NLEFT + LI_NCOLUMNS
               DO WHILE LI_NCOLUMNS + LI_NLEFT - LI_FREEZE - 1 < LI_COLCOUNT .AND. LI_NLEFT + LI_NCOLUMNS = i
                  LI_NLEFT ++
                  // DO MSFNEXT WITH mslist,LI_NLEFT
                  LI_NCOLUMNS := FLDCOUNT( mslist, LI_X1 + 2, LI_X2 - 2, LI_NLEFT )
               ENDDO
               LI_COLPOS := i - LI_NLEFT + 1
               Eval( LI_BSKIP, mslist, - ( LI_NSTR - 1 ) )
               WNDVIVOD( mslist )
               Eval( LI_BSKIP, mslist, LI_NSTR - 1 )
               VIVNAMES( mslist )
            ENDIF
         CASE xkey = 19                 // ����� �����
            IF predit > 1
               LI_COLPOS --
            ENDIF
            IF LI_NLEFT > LI_FREEZE + 1 .AND. ( predit <= 1 .OR. LI_COLPOS < LI_FREEZE + 1 )
               LI_NLEFT --
               LI_NCOLUMNS := FLDCOUNT( mslist, LI_X1 + 2, LI_X2 - 2, LI_NLEFT )
               IF predit <= 1 .OR. LI_COLPOS < LI_FREEZE + 1
                  LI_COLPOS := LI_FREEZE + 1                // 1
               ENDIF
               Eval( LI_BSKIP, mslist, - ( LI_NSTR - 1 ) )
               WNDVIVOD( mslist )
               Eval( LI_BSKIP, mslist, LI_NSTR - 1 )
               VIVNAMES( mslist )
            ENDIF
            IF LI_COLPOS < 1
               LI_COLPOS := 1
            ENDIF
         CASE xkey = 3                  // PgDn
            Eval( LI_BSKIP, mslist, razmer - LI_NSTR + 1 )
            LI_NSTR := 1
            IF Eval( LI_BEOF, mslist )
               Eval( LI_BSKIP, mslist, - 1 )
            ENDIF
            WNDVIVOD( mslist )
         CASE xkey = 18                 // PgUp
            IF LI_NSTR > 1
               Eval( LI_BSKIP, mslist, - ( LI_NSTR - 1 ) )
               LI_NSTR := 1
            ELSE
               Eval( LI_BSKIP, mslist, - razmer )
               IF Eval( LI_BBOF, mslist )
                  Eval( LI_BGTOP, mslist )
               ENDIF
               WNDVIVOD( mslist )
            ENDIF
         CASE xkey = 6 .AND. LI_KOLZ > 0                    // End
            Eval( LI_BGBOT, mslist )
            Eval( LI_BSKIP, mslist, - ( razmer - 1 ) )
            IF Eval( LI_BBOF, mslist )
               Eval( LI_BGTOP, mslist )
            ENDIF
            LI_NSTR := WNDVIVOD( mslist )
            Eval( LI_BSKIP, mslist, LI_NSTR - 1 )
         CASE xkey = 1 .AND. LI_KOLZ > 0                    // Home
            LI_NSTR := 1
            Eval( LI_BGTOP, mslist )
            WNDVIVOD( mslist )
         CASE xkey = K_ENTER .AND. predit < 2
            rez     := .F.
            rezproc := xkey
         CASE ( xkey = K_ENTER .OR. ( xkey > 47 .AND. xkey < 58 ) .OR. ( xkey > 64 .AND. xkey < 91 ) ;
                   .OR. ( xkey > 96 .AND. xkey < 123 ) .OR. ( xkey > 127 .AND. xkey < 176 ) .OR. ( xkey > 223 .AND. xkey < 240 ) ) .AND. predit > 1
            //   ������஢����
            i := fipos := LI_COLPOS + LI_NLEFT - 1 - LI_FREEZE
            IF LI_WHEN = Nil .OR. Len( LI_WHEN ) < fipos .OR. LI_WHEN[fipos] = Nil .OR. Eval( LI_WHEN[fipos],mslist,fipos )
               lEdErr := .F.
               IF Valtype( LI_MSED ) != "N"
                  vartmp := Iif( Len( LI_MSED ) < fipos, 1, LI_MSED[ fipos ] )
                  IF Valtype( vartmp ) = "N"
                     IF vartmp == 2
                        IF LI_MSF != Nil
                           IF Valtype( LI_MSF[ fipos ] ) == "B"
                              LOOP
                           ELSE
                              i        := Fieldpos( LI_MSF[ fipos ] )
                              varbuf   := Fieldget( i )
                              cPicture := Defpict( i, LI_X2 - LI_X1 - 3 )
                           ENDIF
                        ELSE
                           varbuf   := Fieldget( fipos )
                           cPicture := Defpict( fipos, LI_X2 - LI_X1 - 3 )
                        ENDIF
                     ELSE
                        LOOP
                     ENDIF
                  ELSEIF LI_MSF != Nil .AND. Valtype( LI_MSF[ fipos ] ) == "B"
                     varbuf   := Eval( LI_MSF[ fipos ], mslist, fipos )
                     cPicture := LI_MSED[ fipos ]
                     lEdErr   := .T.
                  ELSE
                     LOOP
                  ENDIF
               ELSE
                  varbuf := Fieldget( fipos )
               ENDIF
               SET CURSOR ON
               Setcolor( LI_CLRV + "," + LI_CLRV )
               IF xkey <> 13
                  KEYBOARD Chr( xkey ) + GetBuf()
               ENDIF
               vartmp := Readexit( .T. )
               @ LI_NSTR + LI_Y1, LI_XPOS GET varbuf PICTURE cPicture        
               IF LI_VALID <> Nil .AND. Len( LI_VALID ) >= fipos .AND. LI_VALID[ fipos ] <> Nil
                  Getlist[ 1 ] :postBlock := LI_VALID[ fipos ]
               ENDIF
               READ
               IF Lastkey() <> 27 .AND. Updated()
                  LI_UPDATED := .T.
                  IF Eval( LI_BEOF, mslist )
                     APPEND BLANK
                     LI_KOLZ := Eval( LI_RCOU, mslist )
                  ELSE
                     IF !lEdErr .AND. !Set( _SET_EXCLUSIVE )
                        Rlock()
                        IF Neterr()
                           LOOP
                        ENDIF
                     ENDIF
                  ENDIF
                  IF LI_BDESHOUT != Nil .AND. Valtype( varbuf ) == "C"
                     varbuf := Eval( LI_BDESHOUT, varbuf )
                  ENDIF
                  IF lEdErr
                     Eval( LI_MSF[ fipos ], mslist, fipos, varbuf )
                  ELSE
                     Fieldput( i, varbuf )
                  ENDIF
                  IF !lEdErr .AND. !Set( _SET_EXCLUSIVE )
                     UNLOCK
                  ENDIF
               ENDIF
               IF ( Lastkey() = 27 .OR. .NOT. Updated() ) .AND. Eval( LI_BEOF, mslist )
                  Setcolor( LI_CLR )
                  @ LI_NSTR + LI_Y1, LI_X1 + 1 CLEAR TO LI_NSTR + LI_Y1, LI_X2 - 1
                  LI_NSTR --
                  Eval( LI_BSKIP, mslist, - 1 )
               ELSE
                  IF ( vartmp := Lastkey() ) <> 13 .AND. vartmp <> 27 .AND. vartmp < 32
                     KEYBOARD Chr( vartmp )
                  ENDIF
               ENDIF
               Readexit( vartmp )
               SET CURSOR OFF
            ENDIF
         CASE xkey = 27                 // Esc
            rez     := .F.
            rezproc := 0
            
         CASE xkey = - 41 .AND. ( Empty(maskey) .OR. ASCAN(maskey,xkey) == 0 ) ;
               .AND. !Empty( Alias() )  // F12
            IF ( i := FChoice( arrF12,,,"W+/RB","B/W" ) ) == 1
               LI_MSK := ","
            ELSEIF i == 2
               vartmp := Iif( Type("outpath")=="C",m->outpath,"" ) + Alias()+"_.msk"
               IF File( vartmp )
                  LI_MSK := Memoread( vartmp )
               ELSE
                  Alert( vartmp+" �� ������" )
               ENDIF
            ELSEIF i == 3
               vartmp := Iif( Type("outpath")=="C",m->outpath,"" ) + Alias()+"_.msk"
               Memowrit( vartmp, LI_MSK )
            ELSEIF i == 4
               carr_Init( @LI_CARR,512 )
               LI_KOLZ := 0
               i := 2
               DO WHILE .T.
                  IF ( vartmp := hb_At( ',', LI_MSK, i ) ) == 0
                     EXIT
                  ENDIF
                  carr_Put( @LI_CARR, Val(Substr(LI_MSK,i,vartmp-i)), ++LI_KOLZ )
                  i := vartmp + 1
               ENDDO
               LI_NSTR := 1
               LI_PRFLT := .T.
               Eval( LI_BGTOP, mslist )
               WNDVIVOD( mslist )
            ENDIF
         CASE xkey = 22 .AND. Valtype(LI_MSK) == "C"    // Insert
            vartmp := Ltrim(Str(Recno())) + ","
            IF ( i := At( ","+vartmp, LI_MSK ) ) == 0
               LI_MSK += vartmp
            ELSE
               LI_MSK := Left( LI_MSK, i ) + Substr( LI_MSK, i+Len(vartmp)+1 )
            ENDIF
         CASE xkey = 28
            IF Type( "CALCUL()" ) == "UI"
               Eval( &("{||Calcul()}") )
            ENDIF
#ifndef __HARBOUR__
         CASE xkey = - 10
            DO EXT_PRG
#endif
         OTHERWISE
            IF maskey != Nil
               IF ASCAN( maskey, xkey ) != 0
                  rez     := .F.
                  rezproc := xkey
               ELSEIF maskey[1] == 0 .AND. !Empty( ordSetFocus() ) .AND. ;
                     ( ( xkey >= 32 .AND. xkey < 251 ) .OR. xkey == 8 )
                  IF xkey == 8
                     IF Len( cSeek ) > 1
                        cSeek := Left( cSeek, Len( cSeek ) - 1 )
                     ENDIF
                  ELSE
                     IF Len( cSeek ) < LI_X2 - LI_X1 - 3
                        cSeek += Chr( xkey )
                     ENDIF
                  ENDIF
                  IF !Empty( cSeek )
                     vartmp := Recno()
                     dbSeek( cSeek, .T. )
                     IF Eof()
                        dbGoTo( vartmp )
                        cSeek := Left( cSeek, Len( cSeek ) - 1 )
                        IF Empty( cSeek )
                           @ LI_Y2, LI_X2 - Len( cSeek ) - 4 SAY "�<>"
                        ENDIF
                     ELSE
                        LI_NSTR := 1
                        WNDVIVOD( mslist )
                        @ LI_Y2, LI_X2 - Len( cSeek ) - 4 SAY "�<" + cSeek + ">"
                     ENDIF
                     lModeSeek := .T.
                  ENDIF
               ENDIF
            ENDIF
         ENDCASE
         IF !lModeSeek .AND. !Empty( cSeek )
            @ LI_Y2, LI_X2 - Len( cSeek ) - 3 SAY Replicate( '�', Len(cSeek)+2 )
            cSeek := ""
         ENDIF
#ifdef VER_MOUSE
      ELSE
         IF ym > LI_Y1 .AND. ym < LI_Y2 .AND. xm > LI_X1 .AND. xm < LI_X2
            IF predit < 2
               IF LI_NSTR = ym - LI_Y1
                  rez     := .F.
                  rezproc := 13
               ELSE
                  Eval( LI_BSKIP, mslist, ym - LI_Y1 - LI_NSTR )
                  LI_NSTR := ym - LI_Y1
               ENDIF
            ELSE
               i := FLDCOUNT( mslist, LI_X1 + 2, xm, LI_NLEFT ) + 1
               IF i <= FLDCOUNT( mslist, LI_X1 + 2, LI_X2 - 2, LI_NLEFT )
                  IF i = 2 .AND. xm < LI_X1 + 2 + Len( FLDSTR( mslist, LI_NLEFT + LI_COLPOS - 1 ) )
                     i := 1
                  ENDIF
                  IF LI_COLPOS <> i .OR. LI_NSTR <> ym - LI_Y1
                     LI_COLPOS := i
                     Eval( LI_BSKIP, mslist, ym - LI_Y1 - LI_NSTR )
                     LI_NSTR := ym - LI_Y1
                  ELSE
                     KEYBOARD Chr( 13 )
                  ENDIF
               ENDIF
            ENDIF
         ENDIF
         M_SHOW()
         DO WHILE M_STAT() <> 0
         ENDDO
         M_HIDE()
#endif
      ENDIF
   ENDDO

   IF LI_LSOHR
      Restscreen( Iif( title <> Nil .AND. LI_NAMES <> Nil, LI_Y1 - 1, LI_Y1 ), LI_X1, LI_Y2, LI_X2, wndbuf )
   ELSE
      Setcolor( LI_CLRV2 )
      VIVSTR( mslist, LI_NSTR + LI_Y1, Iif( predit > 1, LI_COLPOS, 0 ) )
   ENDIF
   Setcolor( oldcolors )
   SET CURSOR ON
RETURN rezproc

FUNCTION FLDCOUNT( mslist, xstrt, xend, fld1 )

LOCAL klf := 0, i := Iif( LI_FREEZE > 0, 1, fld1 )
   DO WHILE .T.
      xstrt += Max( Len( FLDSTR( mslist, i ) ), Iif( LI_NAMES <> Nil .AND. Len( LI_NAMES ) >= i, Len( LI_NAMES[ i ] ), 0 ) ) - 1
      IF xstrt > xend
         EXIT
      ENDIF
      klf ++
      i     := Iif( i = LI_FREEZE, fld1, i + 1 )
      xstrt += 2
      IF i > LI_COLCOUNT
         EXIT
      ENDIF
   ENDDO
RETURN Iif( klf = 0, 1, klf )

FUNCTION VIVNAMES( mslist )

LOCAL i := 1, x, oldc, fif
   IF LI_NAMES <> Nil
      x := LI_X1 + 2
      IF LI_NMCLR <> Nil
         oldc := Setcolor( LI_NMCLR )
      ENDIF
      @ LI_Y1, x - 1 CLEAR TO LI_Y1, LI_X2 - 1
      fif := Iif( LI_FREEZE > 0, 1, LI_NLEFT )
      DO WHILE i <= LI_NCOLUMNS .AND. fif <= Len( LI_NAMES )
         IF LI_NAMES[ fif ] <> Nil
            @ LI_Y1, x SAY LI_NAMES[ fif ]         
         ENDIF
         x   += Max( Len( FLDSTR( mslist, fif ) ), Len( LI_NAMES[ fif ] ) ) + 1
         fif := Iif( fif = LI_FREEZE, LI_NLEFT, fif + 1 )
         i ++
      ENDDO
      IF LI_NMCLR <> Nil
         Setcolor( oldc )
      ENDIF
   ENDIF
RETURN Nil

FUNCTION WNDVIVOD( mslist )

LOCAL firstrec, nstr := 1, tekzp1, x := LI_X1 + 2, i, fif

   IF LI_PRFLT
      tekzp1 := LI_TEKZP
   ENDIF
   firstrec := Eval( LI_RECNO, mslist )
   Setcolor( LI_CLR )
   @ LI_Y1 + 1, LI_X1 + 1 CLEAR TO LI_Y2 - 1, LI_X2 - 1
#ifdef __HARBOUR__
   Dispbegin()
#endif
   DrawVSep( mslist )
   DO WHILE .T.
      VIVSTR( mslist, nstr + LI_Y1, 0 )
      nstr ++
      Eval( LI_BSKIP, mslist, 1 )
      IF nstr > LI_Y2 - LI_Y1 - 1 .OR. Eval( LI_BEOF, mslist )
         EXIT
      ENDIF
   ENDDO
#ifdef __HARBOUR__
   Dispend()
   IF NextKey() == 0
      KEYBOARD ""
   ENDIF
#endif
   IF LI_PRFLT
      LI_TEKZP := tekzp1
   ENDIF
   Eval( LI_BGOTO, mslist, firstrec )
RETURN nstr - 1

STATIC FUNCTION DrawVSep( mslist )

LOCAL x := LI_X1 + 2, i, fif
   fif := Iif( LI_FREEZE > 0, 1, LI_NLEFT )
   FOR i := 1 TO LI_NCOLUMNS
      x   += Max( Len( FLDSTR( mslist, fif ) ), Iif( LI_NAMES <> Nil .AND. Len( LI_NAMES ) >= fif, Len( LI_NAMES[ fif ] ), 0 ) )
      fif := Iif( fif == LI_FREEZE, LI_NLEFT, fif + 1 )
      IF fif <= LI_COLCOUNT
         @ LI_Y1 + 1, x, LI_Y2 - 1, x BOX Replicate( LI_SEPARATOR, 9 )
      ENDIF
      x ++
   NEXT
RETURN Nil

STATIC PROCEDURE VIVSTR( mslist, nstroka, vybfld )
LOCAL x, dx, i, shablon, sviv, fif, slen, oldc := SetColor()

   LI_XPOS := x := LI_X1 + 2
   IF LI_KOLZ > 0
      IF LI_BSTR != Nil
         Eval( LI_BSTR, mslist, LI_TEKZP, oldc )
      ENDIF
      fif := Iif( LI_FREEZE > 0, 1, LI_NLEFT )
      IF !Empty( LI_MSK ) .AND. At( ','+Ltrim(Str(Recno()))+',', LI_MSK ) != 0
         @ nstroka, LI_X1 + 1 SAY "+" COLOR LI_CLRMSK
      ELSEIF LI_NLEFT != LI_FREEZE + 1 .AND. vybfld = 0
         @ nstroka, LI_X1 + 1 SAY "<"
      ELSEIF Deleted()
         @ nstroka, LI_X1 + 1 SAY "*"
      ELSE
         @ nstroka, LI_X1 + 1 SAY " "
      ENDIF
      FOR i := 1 TO LI_NCOLUMNS
         IF i == LI_COLPOS
            LI_XPOS := x
         ENDIF
         sviv := FLDSTR( mslist, fif )
         sviv := Iif( Len( sviv ) < LI_X2 - 1 - x, sviv, Substr( sviv, 1, LI_X2 - 1 - x ) )
         IF LI_BCELL != Nil
            Eval( LI_BCELL, mslist, LI_TEKZP, fif, oldc )
         ENDIF
         IF vybfld = 0 .OR. vybfld = i
            @ nstroka, x SAY sviv
         ENDIF
         slen := Len( sviv )
         dx   := Iif( LI_NAMES <> Nil .AND. Len( LI_NAMES ) >= fif, Len( LI_NAMES[ fif ] ), 0 )
         IF i < LI_NCOLUMNS .AND. ( vybfld = 0 .OR. vybfld = i )
            IF dx > slen
               @ nstroka, x + slen SAY Space( dx - slen )         
            ENDIF
         ENDIF
         x   += Max( slen, dx ) + 1
         fif := Iif( fif == LI_FREEZE, LI_NLEFT, fif + 1 )
      NEXT
      SetColor( oldc )
      IF fif <= LI_COLCOUNT .AND. vybfld = 0
         IF LI_X2 - 1 - x > 0
            sviv := FLDSTR( mslist, fif )
            @ nstroka, x SAY Substr( sviv, 1, LI_X2 - 1 - x )         
         ENDIF
         @ nstroka, LI_X2 - 1 SAY ">"         
      ENDIF
   ENDIF
RETURN

FUNCTION FLDSTR( mslist, numf )

LOCAL fldtype, rez, vartmp, nItem := numf
   IF LI_MSF != Nil
      IF numf <= Len( LI_MSF )
         vartmp := LI_MSF[ numf ]
         IF ( fldtype := Valtype( vartmp ) ) = "B"
            vartmp := Eval( vartmp, mslist, numf )
            IF LI_MSTYP[ numf ] == "C"
               RETURN Padr( vartmp, LI_MSLEN[ numf ] )
            ELSEIF LI_MSTYP[ numf ] $ "NIBYZ842+^"
               RETURN Padl( Str( vartmp, LI_MSLEN[ numf ], LI_MSDEC[ numf ] ), LI_MSLEN[ numf ] )
            ELSEIF LI_MSTYP[ numf ] == "D"
               RETURN Padr( Dtoc( vartmp ), LI_MSLEN[ numf ] )
            ELSEIF LI_MSTYP[ numf ] == "L"
               RETURN Padr( Iif( vartmp, "T", "F" ), LI_MSLEN[ numf ] )
            ELSEIF LI_MSTYP[ numf ] $ "T=@"
               IF LI_MSLEN[ numf ] == 4
                  RETURN Transform( vartmp, "@T" )
               ELSE
                  RETURN Padr( hb_ttoc( vartmp ), LI_MSLEN[ numf ] )
               ENDIF
            ENDIF
         ELSEIF fldtype = "C"
            numf := Fieldpos( vartmp )
         ENDIF
      ENDIF
   ENDIF
   fldtype := dbFieldInfo( 2, numf )
   DO CASE
   CASE fldtype = "C"
      rez := Fieldget( numf )
   CASE fldtype $ "NIBYZ842+^"
      rez := Str( Fieldget( numf ), Iif( LI_MSLEN != Nil .AND. nItem <= Len( LI_MSLEN ) .AND. LI_MSLEN[ nItem ] != Nil, LI_MSLEN[ nItem ], dbFieldInfo( 3, numf ) ), dbFieldInfo( 4, numf ) )
   CASE fldtype = "D"
      rez := Dtoc( Fieldget( numf ) )
   CASE fldtype = "L"
      rez := Iif( Fieldget( numf ), "T", "F" )
   CASE fldtype = "M"
      rez := "  <Memo>  "
   CASE fldtype $ "T=@"
      IF dbFieldInfo( 3, numf ) == 4
         rez := Transform( Fieldget( numf ), "@T" )
      ELSE
         rez := hb_ttoc( Fieldget( numf ) )
      ENDIF
   ENDCASE
   IF LI_BDESHIN <> Nil
      rez := Eval( LI_BDESHIN, rez )
   ENDIF
RETURN rez

PROCEDURE EXT_PRG

LOCAL bufs, i, oldc
   IF Type( "ms_ext_n" ) <> "U"
#ifndef __HARBOUR__
      bufs := Savescreen( 0, 0, 24, 79 )
      oldc := Setcolor()
      Set COLOR TO GR+/N,N/W
      @ 07, 30, 8 + Len( ms_ext_n ), 50 BOX "�Ŀ����� "
      i := Achoice( 08, 31, 7 + Len( ms_ext_n ), 49, ms_ext_n )
      IF i <> 0
         SWPRUNCMD( ms_ext_p[ i ], 0, "", "" )
      ENDIF
      Setcolor( oldc )
      Restscreen( 0, 0, 24, 79, bufs )
#endif
   ENDIF
RETURN

FUNCTION GetBuf

LOCAL srez := ""
   DO WHILE Nextkey() <> 0
      srez += Chr( Inkey( 0 ) )
   ENDDO
   RETURN srez

#ifndef __HARBOUR__
#ifdef COMPAT_53
FUNCTION FieldType( numf )

LOCAL fldtype := dbFieldInfo( 2, numf )
   IF Len( fldtype ) > 1
      IF Left( fldtype, 6 ) $ "SHORTIINTEGEDOUBLE"
         fldtype := "N"
      ELSEIF Left( fldtype, 5 ) $ "BINARIMAGEVARCH"
         fldtype := "M"
      ELSEIF Left( fldtype, 6 ) $ "SHORTD"
         fldtype := "D"
      ENDIF
   ENDIF
   RETURN fldtype
#endif
#endif
