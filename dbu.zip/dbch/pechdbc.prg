/*
 * DBC - Database Control Utility
 * Printing
 *
 * Author: Alexander S.Kresin <alex@kresin.ru>
 *         www - http://www.kresin.ru/
 * Released to Public Domain
*/

#include "deflist.ch"
#include "dbc.ch"
#ifdef __HARBOUR__
#define __NOEXTRA__
#endif

MEMVAR aFiles

STATIC bufekr

FUNCTION PECH

   LOCAL fif, x, sviv, i, kolfld
   PRIVATE prmsf, klfs

   IF !SetPch()
      RETURN .F.
   ENDIF
   // �����
   IF LI_MSF == Nil
      prmsf  := .F.
      kolfld := FCount()
   ELSE
      prmsf := .T.
      FOR i := 1 TO Len( LI_MSF )
         IF LI_MSF[ i ] = Nil
            EXIT
         ENDIF
      NEXT
      kolfld := i - 1
   ENDIF
   klfs := kolfld
   FGOTOP( mslist )
   DO WHILE .NOT. FEOF( mslist )
      IF .NOT. Deleted()
         fif := 1
         ?
         FOR i := 1 TO kolfld
            sviv := FLDSTR( mslist, fif )
            ?? sviv + ' '
            fif ++
         NEXT
      ENDIF
      FSKIP( mslist, 1 )
   ENDDO
   Endpch()

   RETURN .T.

STATIC FUNCTION Setpch

   LOCAL lkey, choic, fname
   LOCAL str1 := aMsg[69], str2 := aMsg[70]
   LOCAL str3 := aMsg[71], str4 := aMsg[72], str5 := aMsg[37]
   LOCAL str6 := aMsg[73]

   bufekr := SaveScreen( 9, 32, 13, 60 )
   SET COLOR TO + GR/B, N/BG, , , + GR/B
   @  9, 32, 13, 60 BOX "�Ŀ����� "
   choic := 1
   @ 10, 34 PROMPT str1
   @ 11, 34 PROMPT str2
   MENU TO choic
   IF choic = 1
#ifndef __NOEXTRA__
      IF .NOT. PRINTREADY( 1 )
         DO WHILE .T.
            @  9, 32, 13, 60 BOX "�Ŀ����� "
            @ 10, 34 SAY str3
            @ 11, 34 SAY str4
            @ 12, 34 SAY str5
            lkey := Inkey( 0 )
            IF lkey = 13
               IF PRINTREADY( 1 )
                  EXIT
               ENDIF
               @  9, 32, 13, 60 BOX "�Ŀ����� "
               Inkey( 1 )
            ELSEIF lkey = 27
               RestScreen( 9, 32, 13, 60, bufekr )
               RETURN .F.
            ENDIF
         ENDDO
      ENDIF
#endif
      fname := "LPT1"
   ELSEIF choic = 0
      RestScreen( 9, 32, 13, 60, bufekr )
      RETURN .F.
   ELSE
      IF Empty( fname := hu_get( str6 ) )
         RETURN .F.
      ENDIF
   ENDIF
   SET ALTERNATE TO &fname
   SET ALTERNATE ON
   SET CONSOLE OFF

   RETURN .T.

STATIC FUNCTION EndPch

   SET CONSOLE ON
   SET ALTERNATE OFF
   CLOSE ALTERNATE
   RestScreen( 9, 32, 13, 60, bufekr )

   RETURN Nil

FUNCTION PrnStru1

   LOCAL i

   IF LastKey() == 281
      Setpch()
      ? aFiles[ improc,AF_NAME ] + ":"
      ? "--------------"
      FOR i := 1 TO Len( m1 )
         ? m1[ i ]
      NEXT
      Endpch()
   ENDIF

   RETURN 2
