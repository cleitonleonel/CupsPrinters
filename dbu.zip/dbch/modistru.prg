/*
 * DBC - Database Control Utility
 * Structure handling
 *
 * Author: Alexander S.Kresin <alex@kresin.ru>
 *         www - http://www.kresin.ru/
 * Released to Public Domain
*/

#include "deflist.ch"
#include "dbc.ch"
#ifdef RDD_ADS
#include "ads.ch"
STATIC aFldTypes := { "C", "N", "D", "L", "M", "INTEGER", "DOUBLE", "SHORTINT", ;
      "SHORTDATE", "BINARY", "IMAGE", "VARCHAR" }
#else
STATIC aFldTypes := { "C", "N", "D", "L", "M", "F", "I", "B", "2", "4", "8", "Y", ;
      "Z", "T", "Q", "V", "P", "W", "G", "0", "+", "^", "=", "@" }
#endif

MEMVAR aFiles

FUNCTION StruMan( prnew )

   LOCAL oldimp := improc, vybkey, rez := .T.
   LOCAL nrec, fi1, fi2, fi3, fi4, kolf, i, j, alsname
   LOCAL aStru
   LOCAL ctrl_ar := { "B/W,W/B", ;
      { { aMsg[37],, 20, 22 }, { aMsg[38],, 20, 37 } } }
   PRIVATE chng_name := .F. , chng_kol := .F. , chng_par := .F.
   PRIVATE aOld, C1, C2
   PRIVATE mslist    := InitArEdit()

   IF !prnew
      alsname := Alias()
   ENDIF

   IF prnew
      aStru := { { "...", "C", 10, 0 } }
   ELSE
      aOld  := dbStruct()
      aStru := dbStruct()
   ENDIF
   LI_BSKIP := { | a, x | DBFL_SKIP( a, x ) }
   LI_CLR   := "GR+/N"
   LI_CLRV  := "N+/W"
   LI_NAMES := { aMsg[39], aMsg[40], aMsg[41], aMsg[42] }
   LI_MSF := { { | mslist, n, var | iif( var == Nil, PadR( LI_MSREC[ LI_TEKZP, 1 ], 10 ), LI_MSREC[ LI_TEKZP, 1 ] := var ) }, ;
      { | mslist, n, var | iif( var == Nil, LI_MSREC[ LI_TEKZP, 2 ], LI_MSREC[ LI_TEKZP, 2 ] := var ) }, ;
      { | mslist, n, var | iif( var == Nil, LI_MSREC[ LI_TEKZP, 3 ], LI_MSREC[ LI_TEKZP, 3 ] := var ) }, ;
      { | mslist, n, var | iif( var == Nil, LI_MSREC[ LI_TEKZP, 4 ], LI_MSREC[ LI_TEKZP, 4 ] := var ) } }
   LI_MSED := { "XXXXXXXXXX", "X", "9999", "99" }
   // LI_LADD       := .T.
   LI_VALID      := Array( 4 )
   LI_VALID[ 1 ] := { || varbuf := Upper( varbuf ), VldStru( 1 ) }
   LI_VALID[ 2 ] := { || varbuf := Upper( varbuf ), VldStru( 2 ) }
   LI_VALID[ 3 ] := { || VldStru( 3 ) }
   LI_VALID[ 4 ] := { || VldStru( 4 ) }
   LI_WHEN       := Array( 4 )
   LI_WHEN[ 3 ]  := { || Left( LI_MSREC[ LI_TEKZP, 2 ], 1 ) $ "CNVT" }
   LI_WHEN[ 4 ]  := { || Left( LI_MSREC[ LI_TEKZP, 2 ], 1 ) = "N" }
   LI_MSTYP      := { "C", "C", "N", "N" }
   LI_MSLEN      := { 10, 1, 4, 2 }
   LI_MSDEC      := { 0, 0, 0, 0 }
   SET COLOR TO B/W
   @  3, 17, 21, 58 BOX "�Ŀ����� "
   @  4, 26 SAY iif( prnew, aMsg[43], aMsg[44] + aFiles[ improc,AF_NAME ] )
   OutCtrls( ctrl_ar )
   DO WHILE rez
      LI_LSOHR := .F.
      vybkey   := Arlist( mslist, 5, 20, 19, 55, aStru, "", { 7, 22, 306 }, ctrl_ar )
      DO CASE
      CASE vybkey = 0 .OR. vybkey = 501
         rez := .F.
      CASE vybkey = 7 .AND. ;
            ( prnew .OR. aFiles[ improc,AF_EXCLU ] .OR. FileLock() )
         LI_KOLZ --
         FOR i := LI_TEKZP TO LI_KOLZ
            LI_MSREC[ i, 1 ] := LI_MSREC[ i + 1, 1 ]
            LI_MSREC[ i, 2 ] := LI_MSREC[ i + 1, 2 ]
            LI_MSREC[ i, 3 ] := LI_MSREC[ i + 1, 3 ]
            LI_MSREC[ i, 4 ] := LI_MSREC[ i + 1, 4 ]
         NEXT
         LI_MSREC := ASize( LI_MSREC, LI_KOLZ )
         chng_kol := .T.
         IF LI_TEKZP > LI_KOLZ
            LI_TEKZP --
         ENDIF
      CASE vybkey = 22 .AND. ;
            ( prnew .OR. aFiles[ improc,AF_EXCLU ] .OR. FileLock() )
         AAdd( LI_MSREC, Array( 4 ) )
         FOR i := LI_KOLZ TO LI_TEKZP STEP - 1
            LI_MSREC[ i + 1, 1 ] := LI_MSREC[ i, 1 ]
            LI_MSREC[ i + 1, 2 ] := LI_MSREC[ i, 2 ]
            LI_MSREC[ i + 1, 3 ] := LI_MSREC[ i, 3 ]
            LI_MSREC[ i + 1, 4 ] := LI_MSREC[ i, 4 ]
         NEXT
         LI_KOLZ ++
         LI_MSREC[ LI_TEKZP, 1 ] := Space( 10 )
         LI_MSREC[ LI_TEKZP, 2 ] := " "
         LI_MSREC[ LI_TEKZP, 3 ] := 0
         LI_MSREC[ LI_TEKZP, 4 ] := 0
         chng_kol                := .T.
      CASE ( vybkey = 306 .OR. vybkey = 502 ) .AND. ;
            ( prnew .OR. aFiles[ improc,AF_EXCLU ] .OR. FileLock() ) .AND. ;
            Alert( aMsg[45], { aMsg[46], aMsg[47] } ) == 2
         aStru := LI_MSREC
         IF prnew
#ifdef RDD_LETO
            fi1 := hu_Get( aMsg[77] )
#else
            fi1 := FileMan( @mypath, "*.dbf", .T. )
#endif
            IF !Empty( fi1 )
               dbCreate( fi1, aStru )
               fdbopen( fi1 )
            ENDIF
         ELSE
            fi1 := mypath + "a0_new"
            dbCreate( fi1, aStru )
            IF chng_name .AND. !chng_kol .AND. !chng_par
               SELECT( improc )
               COPY TO dbcuuuuu.txt SDF
               SELECT 20
               APPEND FROM dbcuuuuu.txt SDF
               //      ERASE dbcuuuuu.txt
            ELSE
               SELECT 20
               USE ( fi1 )
               C1 := Array( Len( aStru ) )
               C2 := Array( Len( aStru ) )
               FOR i := 1 TO Len( aStru )
                  IF ( j := ASCAN( aOld, { | a | a[ 1 ] == Trim( aStru[ i, 1 ] ) } ) ) > 0
                     C2[ i ] = j
                     IF ! ( aStru[ i, 2 ] $ "+=^" )
                        IF aStru[ i, 2 ] == aOld[ j, 2 ] .AND. ( aStru[ i, 2 ] $ "DLM" .OR. ;
                              ( aStru[ i, 3 ] == aOld[ j, 3 ] .AND. aStru[ i, 4 ] == aOld[ j, 4 ] ) )
                           C1[ i ] := &( "{|param|param}" )
                        ELSE
                           IF C1[ i ] == Nil
                              DO CASE
                              CASE aOld[ j, 2 ] == "C" .AND. aStru[ i, 2 ] == "N"
                                 C1[ i ] := &( "{|param|VAL(param)}" )
                              CASE aOld[ j, 2 ] == "N" .AND. aStru[ i, 2 ] == "C"
                                 C1[ i ] := &( "{|param|LTRIM(STR(param," + ;
                                    LTrim( Str( aOld[ j, 3 ], 2 ) ) + "," + LTrim( Str( aOld[ j, 4 ], 2 ) ) + "))}" )
                              CASE aOld[ j, 2 ] == "C" .AND. aStru[ i, 2 ] == "C"
                                 C1[ i ] := &( "{|param|LEFT(param," + LTrim( Str( aStru[ j, 3 ], 4 ) ) + ")}" )
                              CASE aOld[ j, 2 ] == "N" .AND. aStru[ i, 2 ] == "N"
                                 C1[ i ] := &( "{|param|param}" )
                                 OTHERWISE
                                 //           C1[i] := &("{|param|param}")
                              ENDCASE
                           ENDIF
                        ENDIF
                     ENDIF
                  ENDIF
               NEXT
               SELECT( improc )
               DO ANIMA WITH 0, RecCount(), aMsg[48], 8, 6, 72
               GO TOP
               DO WHILE !Eof()
                  SELECT 20
                  APPEND BLANK
                  FOR i := 1 TO Len( aStru )
                     IF C1[ i ] != Nil
                        FieldPut( i, Eval( C1[ i ], ( alsname ) -> ( FieldGet( C2[ i ] ) ) ) )
                     ENDIF
                  NEXT
                  SELECT( improc )
                  DO ANIMA WITH 1
                  SKIP
               ENDDO
               DO ANIMA WITH 2, 0, aMsg[49]
            ENDIF
            SELECT 20
            USE
            IF nServerType > 1 .AND. Left( mypath, 2 ) == "//"
               Alert( aMsg[50] + "a0_new.dbf" )
            ELSE
               SELECT( improc )
               USE
               fi1 := Cutexten( aFiles[ improc,AF_NAME ] )
               FErase ( fi1 + ".bak" )
               FRename( fi1 + ".dbf", fi1 + ".bak" )
               FRename( mypath + "a0_new.DBF", fi1 + ".dbf" )
               IF File( mypath + "a0_new.fpt" )
                  FRename( mypath + "a0_new.fpt", fi1 + ".fpt" )
               ENDIF
               SELECT( improc )
               USE &fi1
            ENDIF
         ENDIF
         prkorf  := .T.
         prkorst := .T.
         rez     := .F.
      ENDCASE
   ENDDO
   SELECT 20
   USE
   SELECT( improc )

   RETURN Nil

PROCEDURE DBFL_SKIP( mslist, kolskip )

   LOCAL tekzp1

   IF LI_KOLZ != 0
      tekzp1   := LI_TEKZP
      LI_TEKZP += kolskip + iif( tekzp1 = 0, 1, 0 )
      IF LI_TEKZP < 1
         LI_TEKZP := 0
      ELSEIF LI_TEKZP > LI_KOLZ
         IF LastKey() != 24 .OR. Empty( Atail( LI_MSREC ) [ 1 ] )
            LI_TEKZP := LI_KOLZ + 1
         ELSE
            LI_KOLZ ++
            LI_TEKZP := LI_KOLZ
            AAdd( LI_MSREC, { Space( 10 ), " ", 0, 0 } )
         ENDIF
      ENDIF
   ENDIF

   RETURN

FUNCTION VldStru( numf )

   LOCAL nrec

   IF varbuf != Eval( LI_MSF[ numf ], mslist, numf )
      IF numf > 1
         chng_par := .T.
      ENDIF
      DO CASE
      CASE numf == 1
         IF Ascan( LI_MSREC, { | a | Trim( a[ 1 ] ) == Trim( varbuf ) } ) > 0
            MsgInf( aMsg[51] )
            RETURN .F.
         ENDIF
         chng_name := .T.

      CASE numf == 2
         varbuf := Upper( RTrim( varbuf ) )
         IF Ascan( aFldTypes, varbuf ) == 0
            MsgInf( aMsg[52] )
            RETURN .F.
         ENDIF

         IF varbuf $ "D=@^" .OR. varbuf == "DOUBLE"
            LI_MSREC[ LI_TEKZP, 3 ] := 8
            LI_MSREC[ LI_TEKZP, 4 ] := 0
         ELSEIF varbuf == "M" .OR. varbuf == "BINARY" .OR. varbuf == "IMAGE"
            LI_MSREC[ LI_TEKZP, 3 ] := 10
            LI_MSREC[ LI_TEKZP, 4 ] := 0
         ELSEIF varbuf $ "I4+" .OR. varbuf == "SHORTDATE" .OR. varbuf == "INTEGER"
            LI_MSREC[ LI_TEKZP, 3 ] := 4
            LI_MSREC[ LI_TEKZP, 4 ] := 0
         ELSEIF varbuf == "SHORTINT"
            LI_MSREC[ LI_TEKZP, 3 ] := 2
            LI_MSREC[ LI_TEKZP, 4 ] := 0
         ELSEIF varbuf = "L"
            LI_MSREC[ LI_TEKZP, 3 ] := 1
            LI_MSREC[ LI_TEKZP, 4 ] := 0
         ENDIF

      CASE numf == 3
         IF LI_MSREC[ LI_TEKZP, 2 ] == "N" .AND. varbuf > 18
            MsgInf( aMsg[53] )
            RETURN .F.
         ELSEIF LI_MSREC[ LI_TEKZP, 2 ] == "C" .AND. varbuf > 1024
            MsgInf( aMsg[53] )
            RETURN .F.
         ENDIF

      CASE numf == 4
         IF varbuf > 15 .OR. varbuf > LI_MSREC[ LI_TEKZP, 3 ] - 2
            MsgInf( aMsg[53] )
            RETURN .F.
         ENDIF
      ENDCASE
   ENDIF
   MsgInf( "" )

   RETURN .T.

   /*   ---------------------------------   */

FUNCTION SelFiel

   LOCAL oldc, bufscr, arez, i
   PRIVATE ar2len := FCount(), aNames[ Fcount() ]
   PRIVATE ctrl_ar1 := { "+W/RB,+W/B", ;
      { { "",, 7, 37, 15, 55 }, ;
      { aMsg[54], , 17, 12 }, { aMsg[55], , 17, 32 } } }
   PRIVATE ctrl_ar2 := { "+W/RB,+W/B", ;
      { { "",, 7, 13, 15, 21 }, ;
      { aMsg[56], , 17, 12 }, { aMsg[57], , 17, 32 }, { aMsg[58], , 17, 46 } } }

   bufscr := SaveScreen( 05, 10, 18, 68 )
   oldc   := Setcolor()
   SET COLOR TO + W/RB
   @ 05, 10, 18, 68 BOX "�Ŀ����� "
   AFields( aNames )
   IF LI_MSF == Nil
      LI_MSF := Array( ar2len )
      AFields( LI_MSF )
      aFiles[ improc,AF_FLD ] := Array( ar2len )
      AFields( aFiles[ improc,AF_FLD ] )
   ENDIF
   SET COLOR TO + W/N, N/W, , , + W/N
   @  6, 12, 16, 22 BOX "�Ŀ����� "
   @  6, 36, 16, 56 BOX "�Ŀ����� "
   @  6, 13 SAY aMsg[59]
   @  6, 38 SAY aMsg[60]
   arez := 1
   KEYBOARD Chr( 9 )
   DO WHILE .T.
      SET COLOR TO + W/RB
      @ 17, 12 CLEAR TO 17, 66
      Outctrls( ctrl_ar1 )
      SET COLOR TO + W/N, N/W, , , + W/N
      IF ( arez := MainMenu( 7, 13, 15, 21, aNames,, { | p1, p2 | userf1( p1, p2 ) },,,, .T. ) ) = 0
         EXIT
      ENDIF
      IF aFiles[ improc,AF_FLD,1 ] != Nil
         SET COLOR TO + W/RB
         @ 17, 12 CLEAR TO 17, 66
         Outctrls( ctrl_ar2 )
         SET COLOR TO + W/N, N/W, , , + W/N
         IF ( arez := MainMenu( 7, 37, 15, 55, aFiles[ improc,AF_FLD ],, { | p1, p2 | userf2( p1, p2 ) },,,, .T. ) ) = 0
            EXIT
         ENDIF
      ENDIF
   ENDDO
   IF aFiles[ improc,AF_FLD,1 ] == Nil
      AFields( aFiles[ improc,AF_FLD ] )
   ENDIF
   Setcolor( oldc )
   RestScreen( 05, 10, 18, 68, bufscr )

   RETURN Nil

FUNCTION Userf1( nind, key )

   LOCAL rez := 2, i, oldc
#ifdef VER_MOUSE

   IF key = 501
      oldc := Setcolor( ctrl_ar1[ 1 ] )
      i    := F_CTRL( ctrl_ar1[ 2 ], , , , , , 1, M_YTEXT(), M_XTEXT() )
      Setcolor( oldc )
   ENDIF
#endif
   DO CASE
   CASE key = 9 .OR. ( key = 501 .AND. i = 1 )
      rez := 1
   CASE key = 22 .OR. ( key = 501 .AND. i = 2 )
      Addfiel( aNames[ nind ] )
      rez := 1
      ar2len ++
      KEYBOARD Chr( 9 )
   CASE key = - 4 .OR. ( key = 501 .AND. i = 3 )
      rez := 1
      AFields( LI_MSF )
      AFields( aFiles[ improc,AF_FLD ] )
      AFields( LI_NAMES )
      ar2len := FCount()
   ENDCASE

   RETURN rez

FUNCTION Userf2( nind, key )

   LOCAL rez := 2, i, oldc
#ifdef VER_MOUSE

   IF key = 501
      oldc := Setcolor( ctrl_ar1[ 1 ] )
      i    := F_CTRL( ctrl_ar2[ 2 ], , , , , , 1, M_YTEXT(), M_XTEXT() )
      Setcolor( oldc )
   ENDIF
#endif
   DO CASE
   CASE key = 9 .OR. ( key = 501 .AND. i = 1 )              // Tab
      rez := 1
   CASE key = 7 .OR. ( key = 501 .AND. i = 3 )              // Del
      Delfiel( nind )
      @  6, 36, 16, 56 BOX "�Ŀ����� "
      rez := 1
      ar2len --
      KEYBOARD Chr( 9 )
   CASE key = 22 .OR. ( key = 501 .AND. i = 2 )             // Ins
      IF Insfiel( nind )
         ar2len ++
      ENDIF
      rez := 1
      KEYBOARD Chr( 9 )
   CASE key = - 5 .OR. ( key = 501 .AND. i = 4 )
      AFields( LI_MSF )
      AFields( LI_NAMES )
      AFill( aFiles[ improc,AF_FLD ], Nil )
      @  6, 36, 16, 56 BOX "�Ŀ����� "
      ar2len := 0
      rez    := 1
   ENDCASE

   RETURN rez

FUNCTION Addfiel( finame )

   IF ASCAN( aFiles[ improc,AF_FLD ], finame ) = 0
      AAdd( aFiles[ improc,AF_FLD ], finame )
      AAdd( LI_NAMES, finame )

      IF LI_MSTYP != Nil
         AAdd( LI_MSTYP, ValType( &finame ) )
      ENDIF
      IF LI_MSLEN != Nil
         AAdd( LI_MSLEN, Nil )
      ENDIF
      IF LI_MSDEC != Nil
         AAdd( LI_MSDEC, Nil )
      ENDIF

      IF .NOT. ( ValType( &finame ) $ "CM" )
         finame := "TRANSFORM(" + finame + ",'@(')"
      ENDIF
      IF ValType( &finame ) = "M"
         AAdd( LI_MSF, finame )
      ELSE
         AAdd( LI_MSF, &( "{||" + finame + "}" ) )
      ENDIF
      ModiType( mslist, Len( LI_MSF ) )
   ENDIF

   RETURN Nil

FUNCTION Insfiel( numfiel )

   LOCAL expfiel := Space( 100 ), i, finame
   LOCAL GetList := {}
   LOCAL oldc, bufscr, txname := Space( 20 )

   bufscr := SaveScreen( 08, 12, 12, 66 )
   oldc   := Setcolor()
   SET COLOR TO + W/RB, B/W, , , + W/RB
   @ 08, 12, 12, 66 BOX "�Ŀ����� "
   @ 09, 14 SAY aMsg[61]
   @ 10, 14 GET expfiel PICTURE "@S50"
   @ 11, 14 SAY aMsg[39] + ":" GET txname
   READ
   Setcolor( oldc )
   RestScreen( 08, 12, 12, 66, bufscr )
   IF LastKey() <> 27 .AND. .NOT. Empty( expfiel )
      IF LI_MSF = Nil
         LI_MSF := Array( FCount() + 1 )
         AFields( LI_MSF )
         aFiles[ improc,AF_FLD ] = Array( FCount() + 1 )
         AFields( aFiles[ improc,AF_FLD ] )
      ELSE
         AAdd( LI_MSF, Nil )
         AAdd( LI_NAMES, Nil )
         AAdd( aFiles[ improc,AF_FLD ], Nil )
      ENDIF
      AIns( LI_MSF, numfiel )
      AIns( LI_NAMES, numfiel )
      AIns( aFiles[ improc,AF_FLD ], numfiel )
      aFiles[ improc,AF_FLD,numfiel ] := expfiel
      LI_NAMES[ numfiel ] = txname
      IF .NOT. ( ValType( &expfiel ) $ "CM" )
         expfiel := "TRANSFORM(" + expfiel + ",'@(')"
      ENDIF
      IF ValType( &expfiel ) = "M"
         LI_MSF[ numfiel ] = expfiel
      ELSE
         LI_MSF[ numfiel ] = &( "{||" + expfiel + "}" )
      ENDIF
      IF LI_MSTYP != Nil
         AAdd( LI_MSTYP, Nil )
         AIns( LI_MSTYP, numfiel )
      ENDIF
      IF LI_MSLEN != Nil
         AAdd( LI_MSLEN, Nil )
      ENDIF
      IF LI_MSDEC != Nil
         AAdd( LI_MSDEC, Nil )
      ENDIF
      ModiType( mslist, numfiel )
      FOR i := numfiel + 1 TO Len( LI_MSF )
         IF ValType( LI_MSF[ i ] ) = "N"
            finame := FIELD( i - 1 )
            IF ValType( &finame ) = "M"
               LI_MSF[ i ] = finame
            ELSE
               LI_MSF[ i ] = &( "{||TRANSFORM(FIELDGET(" + NUM_STR( i - 1, 3 ) + "),'@(')}" )
            ENDIF
         ENDIF
      NEXT
   ELSE
      RETURN .F.
   ENDIF

   RETURN .T.

FUNCTION Delfiel( numfiel )

   LOCAL finame

   IF LI_MSF = Nil
      LI_MSF := Array( FCount() )
      AFields( LI_MSF )
      aFiles[ improc,AF_FLD ] := Array( FCount() )
      AFields( aFiles[ improc,AF_FLD ] )
   ENDIF
   ADel( LI_NAMES, numfiel )
   ASize( LI_NAMES, Len( LI_NAMES ) - 1 )
   ADel( LI_MSF, numfiel )
   ASize( LI_MSF, Len( LI_MSF ) - 1 )
   ADel( aFiles[ improc,AF_FLD ], numfiel )
   ASize( aFiles[ improc,AF_FLD ], Len( aFiles[ improc,AF_FLD ] ) - 1 )
   IF LI_MSTYP != Nil
      ADel( LI_MSTYP, numfiel )
      ASize( LI_MSTYP, Len( LI_MSTYP ) - 1 )
   ENDIF
   IF LI_MSLEN != Nil
      ADel( LI_MSLEN, numfiel )
      ASize( LI_MSLEN, Len( LI_MSLEN ) - 1 )
   ENDIF
   IF LI_MSDEC != Nil
      ADel( LI_MSDEC, numfiel )
      ASize( LI_MSDEC, Len( LI_MSDEC ) - 1 )
   ENDIF

   RETURN Nil

FUNCTION Chngfiel( numfiel )

   LOCAL GetList := {}
   LOCAL oldc, bufscr, txname, expfiel, oldexp
#ifdef __HARBOUR__
   LOCAL oldWidth, nWidth := iif( LI_MSLEN != Nil .AND. numfiel <= Len( LI_MSLEN ) .AND. LI_MSLEN[ numfiel ] != Nil, LI_MSLEN[ numfiel ], dbFieldInfo( 3, numfiel ) )
#else
   LOCAL oldWidth, nWidth := iif( LI_MSLEN != Nil .AND. numfiel <= Len( LI_MSLEN ) .AND. LI_MSLEN[ numfiel ] != Nil, LI_MSLEN[ numfiel ], FieldSize( numfiel ) )
#endif

   oldWidth := nWIdth
   txname   := PadR( LI_NAMES[ numfiel ], 20 )
   oldexp   := expfiel := PadR( iif( aFiles[ improc,AF_FLD ] == Nil, Field( numfiel ), aFiles[ improc,AF_FLD,numfiel ] ), 100 )
   bufscr   := SaveScreen( 08, 12, 12, 66 )
   oldc     := Setcolor()
   SET COLOR TO + W/RB, B/W, , , + W/RB
   @ 08, 12, 13, 66 BOX "�Ŀ����� "
   @ 09, 14 SAY aMsg[39] + ":" GET txname
   @ 10, 14 SAY aMsg[62]
   @ 11, 14 GET expfiel PICTURE "@S50"
   @ 12, 14 SAY aMsg[41] + ":" GET nWidth
   READ
   Setcolor( oldc )
   RestScreen( 08, 12, 11, 66, bufscr )
   IF LastKey() <> 27
      LI_NAMES[ numfiel ] = txname
      IF expfiel != oldexp
         IF LI_MSF == Nil
            LI_MSF := Array( FCount() )
            AFields( LI_MSF )
         ENDIF
         IF aFiles[ improc,AF_FLD ] == Nil
            aFiles[ improc,AF_FLD ] := Array( FCount() )
            AFields( aFiles[ improc,AF_FLD ] )
         ENDIF

         IF Empty( expfiel )
            aFiles[ improc,AF_FLD,numfiel ] := Nil
            LI_MSF[ numfiel ] := Nil
         ELSE
            aFiles[ improc,AF_FLD,numfiel ] := expfiel
            IF ValType( &expfiel ) <> "C"
               expfiel := "TRANSFORM(" + expfiel + ",'@(')"
            ENDIF
            LI_MSF[ numfiel ] = &( "{||" + expfiel + "}" )
         ENDIF
      ENDIF
      IF nWidth != oldWidth
         IF LI_MSLEN == Nil
            LI_MSLEN := Array( FCount() )
         ENDIF
         LI_MSLEN[ numfiel ] := nWidth
      ENDIF
   ENDIF

   RETURN Nil

STATIC FUNCTION MODITYPE( mslist, i )

   LOCAL vartmp := Eval( LI_MSF[ i ], mslist, i )

   IF LI_MSTYP != Nil .AND. LI_MSLEN != Nil .AND. LI_MSDEC != Nil
      LI_MSTYP[ i ] := ValType( vartmp )
      IF LI_MSTYP[ i ] == "C"
         LI_MSLEN[ i ] := Len( vartmp )
      ELSEIF LI_MSTYP[ i ] == "N"
         vartmp        := Str( vartmp )
         LI_MSLEN[ i ] := Len( vartmp )
         LI_MSDEC[ i ] := iif( '.' $ vartmp, LI_MSLEN[ i ] - At( '.', vartmp ), 0 )
      ELSEIF LI_MSTYP[ i ] == "D"
         LI_MSLEN[ i ] := 8
      ELSEIF LI_MSTYP[ i ] == "L"
         LI_MSLEN[ i ] := 1
      ENDIF
   ENDIF

   RETURN Nil
