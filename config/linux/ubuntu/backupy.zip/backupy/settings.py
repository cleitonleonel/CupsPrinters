#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#
import os


BASE_DIR = os.getcwd()
BACKUP_FILE = 'bkup_test.zip'
GDRIVE_ROOT_PATH = 'backup'
GDRIVE_CLIENT_SECRETS_JSON = os.path.join(BASE_DIR, "credenciais/otmasolucoes/client_secrets.json")
GDRIVE_CREDENTIALS_JSON = os.path.join(BASE_DIR, "credenciais/otmasolucoes/credentials.json")
