#!/usr/bin/python3
# -*- encoding: utf-8 -*-
#
# ser2net -p /dev/ttyUSB0 -b 9600 -l 0.0.0.0 --allow-list='192.168.1.124','192.168.1.133','192.168.1.112' -P 3333

import os
import sys
import serial
import threading
import socket
import logging
import signal
import platform
from optparse import OptionParser
from sys import platform as sys_platform

log = logging.getLogger('ser2net')
log.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s %(levelname)-8s %(message)s')
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
log.addHandler(ch)


def get_platform():
    if sys_platform in ('win32', 'cygwin'):
        return 'Windows'
    elif sys_platform == 'darwin':
        return 'Macosx'
    elif sys_platform.startswith('linux'):
        if platform.node() == 'raspberrypi':
            return 'Raspberrypi'
        return 'Linux'
    elif sys_platform.startswith('freebsd'):
        return 'Linux'
    return 'Unknown'


if get_platform() in ['Linux', 'Raspberrypi']:
    os.system('sudo chmod 777 /dev/ttyUSB*')
    os.system('sudo lsof -t -i tcp:3333 | sudo xargs kill -9 2> /dev/null')


class Redirector(object):
    def __init__(self, serial, socket):
        self.serial = serial
        self.socket = socket
        self.alive = False
        self.thread_read = None

    def shortcut(self):
        """connect the serial port to the tcp port by copying everything
           from one side to the other"""
        self.alive = True
        self.thread_read = threading.Thread(target=self.reader)
        self.thread_read.setDaemon(False)
        self.thread_read.start()
        self.writer()

    def reader(self):
        """loop forever and copy serial->socket"""
        while self.alive:
            try:
                data = self.serial.read(1)
                n = self.serial.inWaiting()
                if n:
                    data = data + self.serial.read(n)
                if data:
                    self.socket.sendall(data)
            except socket.error as message:
                log.error(message)
                break
        self.alive = False

    def writer(self):
        """loop forever and copy socket->serial"""
        while self.alive:
            try:
                data = self.socket.recv(1024)
                if not data:
                    break
                if self.serial.write(data) > 0:
                    break
                # self.serial.write(data)
            except socket.error as message:
                log.error(repr(message))
                break
            except Exception as err:
                log.critical(repr(err))
                break

        self.alive = False
        self.thread_read.join()

    def stop(self):
        """Stop copying"""
        if self.alive:
            self.alive = False
            self.thread_read.join()


if __name__ == '__main__':
    ser = serial.Serial()

    descr = 'WARNING: You have to allow connections only from the addresses' \
            'in the "--allow-list" option. e.g.' \
            '--allow-list="10.0.0.1, 172.16.0.1, 192.168.0.1"\n' \
            'NOTICE: This service supports only ' \
            'one tcp connection per instance.'

    usage = "USAGE: %prog [options]\n\nSimple Serial to Network (TCP/IP)" \
            "redirector."

    parser = OptionParser(usage=usage, version='%prog 0.5', description=descr)
    parser.add_option("-p", "--port", dest="serial",
                      help="Serial port, a number, defualt = '/dev/tty0'", type=str, default='/dev/tty0')
    parser.add_option("-b", "--baud", dest="baudrate",
                      help="Baudrate, default 115200", default=115200, type=int)
    parser.add_option("-r", "--rtscts", dest="rtscts",
                      help="Enable RTS/CTS flow control (default off)", action='store_true', default=False)
    parser.add_option("-x", "--xonxoff", dest="xonxoff",
                      help="Enable software flow control (default off)", action='store_true', default=False)
    parser.add_option("-P", "--localport", dest="port",
                      help="TCP/IP port on which to run the server (default 9100)", type=int, default=9100)
    parser.add_option("-l", "--listen", dest="listen",
                      help="Listen address on which to run the server (default '127.0.0.1')", type=str, default='127.0.0.1')
    parser.add_option(
        '--allow-list', dest='acl', type=str, default="127.0.0.1",
        help="List of IP addresses e.g '127.0.0.1, 192.168.0.2'")

    (options, args) = parser.parse_args()

    ser.port = options.serial
    ser.baudrate = options.baudrate
    ser.rtscts = options.rtscts
    ser.xonxoff = options.xonxoff

    if options.acl != "127.0.0.1":

        if ',' not in options.acl:
            options.acl += ','

        access_list = [ip.strip(" ") for ip in options.acl.replace("'", "").split(',')]
    else:
        access_list = None

    ser.timeout = 1

    log.info("TCP/IP to Serial redirector (Ctrl-C to quit)")

    try:
        ser.open()
    except serial.SerialException as e:
        log.fatal("Could not open serial port %s: %s" % (ser.portstr, e))
        sys.exit(1)

    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.bind((options.listen, options.port))
    srv.listen(1)


    def signal_handler():
        try:
            srv.close()
        except Exception as err:
            log.warning(repr(err))
        finally:
            sys.exit(0)


    signal.signal(signal.SIGINT, signal_handler)

    while True:
        connection = ''
        try:
            log.info("Waiting for connection...")
            connection, addr = srv.accept()
            address, port = addr
            log.info('Connecting with tcp://{0}:{1}'.format(address, port))

            if access_list:
                if address in access_list:
                    r = Redirector(ser, connection)
                    r.shortcut()
                else:
                    log.error('Address {0} not in access list.'.format(address))
            else:
                r = Redirector(ser, connection)
                r.shortcut()

        except socket.error as msg:
            log.error(msg)
        finally:
            try:
                connection.close()
                log.info('Disconnecting')
            except NameError:
                pass
            except Exception as e:
                log.warning(repr(e))
