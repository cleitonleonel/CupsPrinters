#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#
from datetime import date
import os


def get_file_name():
    dias = ('seg', 'ter', 'qua', 'qui', 'sex', 'sab', 'dom')
    today = date.today()
    dia = dias[today.weekday()]
    final_name = f'bkup_{dia}.zip'
    return final_name


backup_name = get_file_name()

BASE_DIR = os.getcwd()
BACKUP_FILE = f'{backup_name}'
GDRIVE_ROOT_PATH = 'backup'
GDRIVE_CLIENT_SECRETS_JSON = os.path.join(BASE_DIR, "credenciais/otmasolucoes/client_secrets.json")
GDRIVE_CREDENTIALS_JSON = os.path.join(BASE_DIR, "credenciais/otmasolucoes/credentials.json")
