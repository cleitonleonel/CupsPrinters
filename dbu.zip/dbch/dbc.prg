/*
 * DBC - Database Control Utility
 * Main file
 *
 * Author: Alexander S.Kresin <alex@kresin.ru>
 *         www - http://www.kresin.ru/
 * Released to Public Domain
*/

#ifdef RDD_ADS
#include "ads.ch"
#define __HARBOUR_AX__
#endif
#include "deflist.ch"
#include "dbc.ch"
#include "inkey.ch"
#include "error.ch"

#ifdef __HARBOUR__
#define __NOEXTRA__
#ifdef GT_TRM

   ANNOUNCE HB_GTSYS
   REQUEST HB_GT_TRM_DEFAULT
#endif

#include "hbver.ch"

#endif

#ifdef __UNIX__
#define DEF_SEP      '/'
#else
#define DEF_SEP      '/'
#endif

   REQUEST DESCEND
   REQUEST HB_STRTOUTF8
   REQUEST HB_UTF8TOSTR

   MEMVAR aFiles

FUNCTION Main( fname1 )

   PUBLIC aFiles[N_MAX_FILES,AF_LEN], lenmsf := 0, improc := 0, mypath := "", quepath := ""
   PUBLIC aDateF := { "dd/mm/yy", "mm/dd/yy", "yy/mm/dd", "dd.mm.yy", "dd-mm-yy", "dd/mm/yyyy", "dd.mm.yyyy", "mm/dd/yyyy" }
   PUBLIC modesplit := .F. , dformat := "dd/mm/yy", memownd := .F. , lRdOnly := .F. , lShared := .F.

   // PUBLIC cAppCpage := "RU1251", cDataCpage := "RU866"
   PUBLIC lWinChar := .F.
   PUBLIC nServerType := LOCAL_SERVER
#ifdef RDD_ADS
   PUBLIC aDrivers := { "ADS_CDX", "ADS_NTX", "ADS_ADT" }, numdriv := 1
#else
   PUBLIC aDrivers := { "DBFCDX", "DBFNTX" }, numdriv := 1
#endif
   PUBLIC DRAMKA := "�ͻ���Ⱥ "
   PUBLIC txtinf := ""
   PRIVATE que_simpl := .T.
   PUBLIC lEngl := .T.
   PUBLIC aMMenu[ 4 ]

   // Rdini( FilePath( hb_ArgV( 0 ) ) + "dbc.ini" )
   // Rdini( DEF_SEP + Curdir() + Iif( Empty( Curdir() ), "", DEF_SEP ) + "dbc.ini" )
   ReadIni( FilePath( hb_ArgV( 0 ) ) )
   ReadIni(  DEF_SEP + CurDir() + iif( Empty( CurDir() ), "", "/" ) )

   DeclStrings()

   aMMenu[ 1 ] := aMMenu[ 3 ] := "+GR/B,N/BG,,,N/B"
   aMMenu[ 4 ] := { { " F2 ",, 0, 3 }, { " F3 ",, 0, 12 }, { " F4 ",, 0, 21 }, { " F5 ",, 0, 29 }, ;
      { " F6 ", , 0, 37 }, { " F7 ", , 0, 47 }, { " F8 ", , 0, 56 }, { " F9 ", , 0, 65 }, { " F10", , 0, 73 } }

   IF lShared
      SET EXCLUSIVE OFF
   ELSE
      SET EXCLUSIVE ON
   ENDIF
   SET EPOCH TO 1960

#ifdef __HARBOUR__
   REQUEST HB_CODEPAGE_PTISO
   REQUEST HB_CODEPAGE_PT850
#ifdef __LINUX__
   REQUEST HB_CODEPAGE_PT850
#endif
   REQUEST HB_TRANSLATE

   hb_cdpSelect( "PT850" )

   SET( _SET_FILECASE, 1 )              // Lower !!!
   SET( _SET_DIRCASE, 1 )               // Lower !!!
#endif

   IF Empty( mypath )
      mypath := DEF_SEP + CurDir() + iif( Empty( CurDir() ), "", DEF_SEP )
   ENDIF
   IF IsDigit( Left( mypath, 1 ) )
      mypath := "//" + mypath
   ENDIF

#ifdef RDD_ADS
   rddSetDefault( "ADS" )
   AdsSetServerType( nServerType )
   AdsRightsCheck( .F. )
   SET AXS LOCKING ON
#ifdef __LINUX__
   ? adsConnect60( mypath, ADS_AIS_SERVER )
#else
   SET CHARTYPE TO OEM
#endif
   AdsSetFileType( iif( numdriv == 1, 2, iif( numdriv == 2, 1, 3 ) ) )
#else
#ifdef RDD_LETO
   REQUEST LETO
   rddSetDefault( "LETO" )
   nServerType := 6
#else
   REQUEST DBFNTX
   REQUEST DBFCDX
   rddSetDefault( aDrivers[ numdriv ] )
#endif

#ifdef GTWVT
   ANNOUNCE HB_GTSYS
   REQUEST HB_GT_WVT
   REQUEST HB_GT_WVT_DEFAULT
#include "hbgtinfo.ch"

   // hb_gtinfo( HB_GTI_FONTNAME, "Arial Cyr" )
   hb_gtinfo( HB_GTI_FONTWIDTH, Int( hb_gtinfo( HB_GTI_DESKTOPWIDTH ) / 80 ) )
   hb_gtinfo( HB_GTI_FONTSIZE, Int( ( hb_gtinfo( HB_GTI_DESKTOPHEIGHT ) - 64 ) / 25 ) )
   hb_gtinfo( HB_GTI_CLOSABLE, .F. )
#endif

#endif

   SET DATE FORMAT dformat
   SET WRAP ON
   SET SCORE OFF
   SET COLOR TO N/B
   @  0,  0 CLEAR TO 24, 79
   SET COLOR TO N/W, W +/ RB
   @  2,  0 CLEAR TO 2, 79
   OutCtrls( aMMenu )
   Wrkdoc( fname1 )

   RETURN

STATIC FUNCTION ReadIni( cPath )

   LOCAL hIni := hb_iniRead( cPath + "dbc.ini" ), aSect, cTmp

   IF !Empty( hIni )
      hb_hCaseMatch( hIni, .F. )
      IF !Empty( aSect := hIni[ "MAIN" ] )
         hb_hCaseMatch( aSect, .F. )
         IF hb_hHaskey( aSect, "dateformat" ) .AND. !Empty( cTmp := aSect[ "dateformat" ] )
            IF Ascan( aDateF, cTmp ) != Nil
               dformat := cTmp
            ENDIF
         ENDIF
         IF hb_hHaskey( aSect, "shared" ) .AND. !Empty( cTmp := aSect[ "shared" ] )
            lShared := ( Lower( cTmp ) == "on" )
         ENDIF
         IF hb_hHaskey( aSect, "readonly" ) .AND. !Empty( cTmp := aSect[ "readonly" ] )
            lRdOnly := ( Lower( cTmp ) == "on" )
         ENDIF
         IF hb_hHaskey( aSect, "lengl" ) .AND. !Empty( cTmp := aSect[ "lengl" ] )
            lEngl := ( Lower( cTmp ) == "on" )
         ENDIF
         /*
         IF hb_hHaskey( aSect, "appcodepage" ) .AND. !Empty( cTmp := aSect[ "appcodepage" ] )
            IF Ascan( aCpId, cTmp ) != Nil
               cAppCpage := cTmp
            ENDIF
         ENDIF
         IF hb_hHaskey( aSect, "datacodepage" ) .AND. !Empty( cTmp := aSect[ "datacodepage" ] )
            IF Ascan( aCpId, cTmp ) != Nil
               cDataCpage := cTmp
            ENDIF
         ENDIF
         */
         IF hb_hHaskey( aSect, "index" ) .AND. ( !Empty( cTmp := aSect[ "index" ] ) ;
               .AND. Lower( cTmp ) == "ntx" )
            numdriv := 2
         ENDIF
      ENDIF
#ifdef RDD_ADS
      IF hb_hHaskey( hIni, "ADS" ) .AND. !Empty( aSect := hIni[ "ADS" ] )
         hb_hCaseMatch( aSect, .F. )
         IF hb_hHaskey( aSect, "serverpath" ) .AND. !Empty( cTmp := aSect[ "serverpath" ] )
            mypath := cTmp
         ENDIF
         IF hb_hHaskey( aSect, "servertype" ) .AND. !Empty( cTmp := aSect[ "servertype" ] )
            nServerType := iif( Lower( cTmp ) == "remote", 6, 1 )
         ENDIF
      ENDIF
#endif
#ifdef RDD_LETO
      IF hb_hHaskey( hIni, "LETO" ) .AND. !Empty( aSect := hIni[ "LETO" ] )
         hb_hCaseMatch( aSect, .F. )
         IF hb_hHaskey( aSect, "serverpath" ) .AND. !Empty( cTmp := aSect[ "serverpath" ] )
            mypath := cTmp
         ENDIF
      ENDIF
#endif
   ENDIF

   RETURN Nil

FUNCTION fdbopen( fname, alsname, prend )

   LOCAL i, oldimp := improc, res := .T. , lNetErr := .F. , cAls := Alias()
   LOCAL strerr := aMsg[1] + iif( fname != Nil, fname, Alias() )
   LOCAL bOldError, oError

   IF fname != Nil
      IF Left( fname, 2 ) != "//" .AND. Left( fname, 2 ) != "\\"
         fname := mypath + fname
      ENDIF
      prend := iif( prend = Nil, .F. , prend )
      IF prend
         improc := lenmsf + 1
      ELSE
         FOR i := 1 TO N_MAX_FILES
            IF aFiles[ i,AF_NAME ] = Nil
               improc := i
               EXIT
            ENDIF
         NEXT
      ENDIF
      IF improc > N_MAX_FILES
         improc := oldimp
         MsgSay( aMsg[ 2 ] )
         RETURN .F.
      ENDIF
      SELECT( improc )
      alsname := iif( alsname = Nil, CutExten( CutPath( fname ) ), Trim( CutExten( CutPath( alsname ) ) ) )
      IF ( i := At( '~', alsname ) ) <> 0
         alsname := Stuff( alsname, i, 1, '_' )
      ENDIF
      bOldError := ErrorBlock( { | e | OpenError( e ) } )
      DO WHILE .T.
         BEGIN SEQUENCE
            dbUseArea( , , fname, alsname, , lRdOnly )
         RECOVER USING oError
            IF oError:genCode == EG_BADALIAS .OR. oError:genCode == EG_DUPALIAS
               IF Empty( alsname := hu_Get( aMsg[74], "XXXXXXXX", alsname ) )
                  res := .F.
               ELSE
                  LOOP
               ENDIF
            ELSEIF oError:genCode == EG_OPEN .AND. oError:osCode == 32
               lNetErr := .T.
            ELSE
               res := .F.
            ENDIF
         END SEQUENCE
         EXIT
      ENDDO
      ErrorBlock( bOldError )
      IF !res
         MsgSay( strerr )
         improc := oldimp
         IF !Empty( cAls )
            dbSelectArea( cAls )
         ENDIF
         RETURN .F.
      ENDIF
      IF lNetErr
         IF SET( _SET_EXCLUSIVE )
            SET( _SET_EXCLUSIVE, .F. )
            lShared := .F.
            dbUseArea( , , fname, CutExten( iif( alsname = Nil, fname, alsname ) ), , lRdOnly )
            IF NetErr()
               MsgSay( strerr )
               improc := oldimp
               IF !Empty( cAls )
                  dbSelectArea( cAls )
               ENDIF
               RETURN .F.
            ENDIF
         ELSE
            MsgSay( strerr )
            improc := oldimp
            IF !Empty( cAls )
               dbSelectArea( cAls )
            ENDIF
            RETURN .F.
         ENDIF
      ENDIF
   ENDIF
   IF improc > lenmsf
      lenmsf := improc
   ENDIF
   aFiles[ improc,AF_NAME ]   := iif( fname != Nil, Upper( fname ), Alias() )
   aFiles[ improc,AF_EXCLU ]  := Set( _SET_EXCLUSIVE )
   aFiles[ improc,AF_RDONLY ] := lRdOnly
   aFiles[ improc,AF_ALIAS ]  := Alias()
   aFiles[ improc,AF_DRIVER ] := numdriv
   aFiles[ improc,AF_BRW ]    := InitList()

   RETURN .T.

STATIC FUNCTION OpenError( e )

   BREAK e

   RETURN

FUNCTION fdbclose

   LOCAL i

   IF improc > 0
      SELECT( improc )
      USE
      aFiles[ improc,AF_NAME ] := Nil
      IF improc == lenmsf
         FOR i := lenmsf - 1 TO 1 STEP - 1
            IF aFiles[ i,AF_NAME ] <> Nil
               EXIT
            ENDIF
         NEXT
         lenmsf := i
      ENDIF
      FOR i := 1 TO lenmsf
         IF aFiles[ i,AF_NAME ] != Nil
            EXIT
         ENDIF
      NEXT
      improc := iif( i <= lenmsf, i, 0 )
      prkorf := .T.
   ENDIF

   RETURN Nil

FUNCTION NEXTAREA

   LOCAL i

   FOR i := improc + 1 TO lenmsf
      IF aFiles[ i,AF_NAME ] != Nil
         improc := i
         prkorf := .T.
         EXIT
      ENDIF
   NEXT

   RETURN Nil

FUNCTION PREVAREA

   LOCAL i

   FOR i := improc - 1 TO 1 STEP - 1
      IF aFiles[ i,AF_NAME ] != Nil
         improc := i
         prkorf := .T.
         EXIT
      ENDIF
   NEXT

   RETURN Nil

FUNCTION Wrkdoc( fname )

   LOCAL slkeys := { - 1, - 2, - 3, - 4, - 5, - 6, - 7, - 8, - 9, 2, 7, 9, 22, 402, 385, 307, 308, 280, 281, 287, 289, 290, 274, 418, 419, 294, 305 }
   LOCAL rez      := .T. , vybkey, bl0, y1, nstr1 := 1, nstr2 := 1
   LOCAL i, klcolumn, prlimsf, arScr
   MEMVAR x1, x2, y2, _y2
   PRIVATE prkorf := .T. , prkorst, dbfi_f := 1, dbnumf := 1, prfi, prmemo, _y2
   PRIVATE impr1, impr2, wndfirst, cdata := "", prmsf := .F.
   PRIVATE mslist

   prkorst := !Empty( fname )
   IF ! Empty( fname )
      IF Upper( FilExten( fname ) ) = "VEW"
         RdView( fname )
      ELSEIF Upper( FilExten( fname ) ) = "SCR"
         IF ( arScr := RdScript( fname ) ) <> Nil
            DoScript( arScr )
            MsgSay( aMsg[75], "N/W" )
         ELSE
            MsgSay( aMsg[76] )
         ENDIF
      ELSEIF Upper( FilExten( fname ) ) = "QUE"
         OpenQuery( fname )
         DoQuery()
      ELSE
         fdbopen( fname )
      ENDIF
   ENDIF
   bl0 := { | mslist | DevPos( _y2, LI_X1 + 2 ), DevOut( iif( LI_PRFLT, Str( LI_TEKZP, 6 ), Str( RecNo(), 8 ) ) + ;
      "/" + Str( LI_KOLZ, 8 ) + iif( LI_PRFLT, aMsg[ 3 ] + dbFilter(), "" ) ), DbflUsr( mslist ) }
   DO WHILE rez
      prfi := .T.
      IF improc > 0
         IF prkorf
            mslist := aFiles[ improc,AF_BRW ]
            LI_B1  := bl0
            IF modesplit
               LI_NSTR := iif( wndfirst, nstr1, nstr2 )
            ENDIF
            SELECT( improc )
            IF prkorst .OR. LI_NAMES == Nil
               LI_NAMES := Array( FCount() )
               AFields( LI_NAMES )
               prkorst := .F.
            ENDIF
            prkorf  := .F.
            LI_MSED := iif( aFiles[ improc,AF_RDONLY ], 1, 3 )
            LI_LADD := !aFiles[ improc,AF_RDONLY ]
            IF prkorst
               LI_MSF := Nil
            ENDIF
         ENDIF
         // ��।��塞 ����稥 ���� ����
         prmemo := 0
         IF memownd
            klcolumn := FCount()
            IF ValType( LI_MSF ) == "A"
               prlimsf  := .T.
               klcolumn := Len( LI_MSF )
            ELSE
               prlimsf := .F.
            ENDIF
            FOR i := 1 TO klcolumn
               IF prlimsf .AND. klcolumn >= i
                  IF ValType( LI_MSF[ i ] ) == "C"
                     prmemo := FieldPos( LI_MSF[ i ] )
                     EXIT
                  ELSEIF ValType( LI_MSF[ i ] ) = "N" .AND. LI_MSF[ i ] <> 1 .AND. ValType( &( Field( i ) ) ) = "M"
                     prmemo := i
                     EXIT
                  ENDIF
               ELSEIF FieldType( i ) == "M"
                  prmemo := i
                  EXIT
               ENDIF
            NEXT
         ENDIF
         IF lWinChar
            LI_BDESHIN  := { | stroka | iif( ValType( stroka ) != "U", WinToDos( stroka ), "" ) }
            LI_BDESHOUT := { | stroka | iif( ValType( stroka ) != "U", DosToWin( stroka ), "" ) }
         ELSE
            LI_BDESHIN  := Nil
            LI_BDESHOUT := Nil
         ENDIF
         //
         y1  := iif( modesplit .AND. ! wndfirst, 14, 3 )
         _y2 := iif( modesplit .AND. wndfirst, 13, 24 )
         IF prmemo > 0
            _y2 -= 4
            @ _y2,  0, _y2 + 4, 79 BOX "�Ŀ����� "
         ENDIF
         MsgInf()
         IF ! Empty( cdata )
            KEYBOARD cdata
            cdata := ""
         ENDIF
         LI_LSOHR := .F.
         vybkey   := dbflist( mslist, 0, y1, 79, _y2, iif( aFiles[ improc,AF_EXCLU ], "(Exclusive)  ", "(Shared)  " ) + aFiles[ improc,AF_NAME ] + "  Order: " + iif( IndexOrd() = 0, "None", OrdSetFocus() ) + iif( aFiles[ improc,AF_RDONLY ], ", (ReadOnly)", "" ), slkeys, aMMenu )
      ELSE
         y1  := iif( modesplit .AND. ! wndfirst, 14, 3 )
         _y2 := iif( modesplit .AND. wndfirst, 13, 24 )
         SET COLOR TO W +/ B
         @ y1,  0, _y2, 79 BOX "�Ŀ����� "
#ifdef VER_MOUSE
         vybkey := IN_KM()
#else
         vybkey := Inkey( 0 )
#endif
         IF vybkey = 27 .OR. vybkey = 502
            vybkey := 0
#ifdef VER_MOUSE
         ELSEIF vybkey = 501
            Setcolor( aMMenu[ 1 ] )
            vybkey := F_CTRL( aMMenu[ 2 ], , , , , , 1, M_YTEXT(), M_XTEXT() )
            IF vybkey = 0
               vybkey := F_CTRL( aMMenu[ 4 ], , , , , , 1, M_YTEXT(), M_XTEXT() )
            ENDIF
            vybkey += 500
#endif
         ENDIF
      ENDIF
      DO CASE
      CASE vybkey = 0
         vybkey := 9
         Fmenu( vybkey )
         OutCtrls( aMMenu )
      CASE ( vybkey < 0 .AND. vybkey > - 10 ) .OR. vybkey > 500
         vybkey := iif( vybkey > 500, vybkey - 500, Abs( vybkey ) )
         Fmenu( vybkey )
         OutCtrls( aMMenu )
      CASE vybkey = 7
         IF !Set( _SET_EXCLUSIVE )
            RLock()
         ENDIF
         IF Deleted()
            RECALL
         ELSE
            DELETE
         ENDIF
         IF ! Set( _SET_EXCLUSIVE )
            UNLOCK
         ENDIF
      CASE vybkey = 281                 // Alt-P
         Pech()
      CASE vybkey = 385                 // Alt-0
         Selarea()
      CASE vybkey = 307
         PREVAREA()
      CASE vybkey = 308
         NEXTAREA()
      CASE vybkey = 280
#ifdef __HARBOUR_AX__
         IF nServerType > 1 .AND. Left( mypath, 2 ) == "//"
            fname := hu_Get( aMsg[77] )
         ELSE
            fname := FileMan( @mypath, iif( numdriv == 3, "*.adt", "*.dbf" ), , .T. )
         ENDIF
#else
#ifdef RDD_LETO
         fname := hu_Get( aMsg[77] + " (" + mypath + ")" )
#else
         fname := FileMan( @mypath, "*.dbf", , .T. )
#endif
#endif
         IF !Empty( fname )
            IF fdbopen( iif( ValType( fname ) == "C", fname, fname[ 1 ] ), ;
                  iif( ValType( fname ) == "C", Nil, fname[ 2 ] ) )
               prkorf  := .T.
               prkorst := .T.
            ENDIF
         ENDIF
      CASE vybkey = 274 .OR. vybkey = 2
         EditRec()
      CASE vybkey = 418
         InsFiel( dbfi_f + dbnumf - 1 )
      CASE vybkey = 419
         DelFiel( dbfi_f + dbnumf - 1 )
      CASE vybkey = 294
         F_LOCATE()
      CASE vybkey = 305
         F_CONTIN()
      CASE vybkey = 287
         F_SEEK()
      CASE vybkey = 289
         F_FILTER()
      CASE vybkey = 290
         F_GO()
      CASE vybkey = 9 .AND. modesplit
         IF wndfirst
            impr1 := improc
            nstr1 := LI_NSTR
         ELSE
            impr2 := improc
            nstr2 := LI_NSTR
         ENDIF
         wndfirst := ! wndfirst
         improc   := iif( wndfirst, impr1, impr2 )
         prkorf   := .T.
#ifndef __NOEXTRA__
      CASE vybkey = 402
         IF IS_CLIPBRD()
            SEND_CLIPB( DosToWin( RTrim( LTrim( FLDSTR( dbfi_f + dbnumf - 1 ) ) ) ) )
         ENDIF
      CASE vybkey = 22 .AND. FT_SHIFT()
         IF IS_CLIPBRD()
            GET_CLIPB( @cdata )
            WinToDos( @cdata )
         ENDIF
#endif
      ENDCASE
   ENDDO

   RETURN

FUNCTION DbflUsr( mslist )

   LOCAL v1

   IF prfi
      v1        := LI_NLEFT
      LI_NLEFT  := dbfi_f
      LI_COLPOS := dbnumf
      IF LI_NLEFT == 1
         LI_NLEFT := LI_FREEZE + 1
      ENDIF
      IF v1 <> LI_NLEFT
         LI_NCOLUMNS := FLDCOUNT( mslist, LI_X1 + 2, LI_X2 - 2, LI_NLEFT )
         VIVNAMES( mslist )
         WNDVIVOD( mslist )
      ENDIF
      prfi := .F.
   ELSE
      dbfi_f := LI_NLEFT
      dbnumf := LI_COLPOS
   ENDIF
   IF prmemo > 0
      KEYBOARD Chr( 27 )
      MemoEdit( FieldGet( prmemo ), _y2 + 1, 1, _y2 + 2, 78, .F. )
   ENDIF

   RETURN Nil

FUNCTION Fmenu( nkey )

   LOCAL bufscr, i, ym, xm
   PRIVATE mchoic, ScrClr := .F.

   KEYBOARD Chr( 13 )
   mchoic := nkey
   DO WHILE .T.
      SET COLOR TO + GR/B, N/BG, , , N/B
      mchoic := MainMenu( , , , , aMMenu[ 2 ], , , mchoic )
      bufscr := SaveScreen( 2, 0, 24, 79 )
      DO CASE
      CASE mchoic = 0
         mchoic := 9
      CASE mchoic = 1
         i := Fpgm1()
      CASE mchoic = 2
         i := Fpgm2()
      CASE mchoic = 3
         i := Fpgm3()
      CASE mchoic = 4
         i := Fpgm4()
      CASE mchoic = 5
         i := Fpgm5()
      CASE mchoic = 6
         i := Fpgm6()
      CASE mchoic = 7
         i := Fpgm7()
      CASE mchoic = 8
         i := Fpgm8()
      CASE mchoic = 9
         i := Fpgm9()
      ENDCASE
      RestScreen( 2, 0, 24, 79, bufscr )
      IF ScrClr
         @  3,  0, 24, 79 BOX "�Ŀ����� "
         ScrClr := .F.
      ENDIF
#ifdef VER_MOUSE
      IF i = 501
         ym     := M_YTEXT()
         xm     := M_XTEXT()
         mchoic := F_CTRL( aMMenu[ 2 ], , , , , , 1, ym, xm )
         IF mchoic = 0
            mchoic := F_CTRL( aMMenu[ 4 ], , , , , , 1, ym, xm )
         ENDIF
         IF mchoic > 0
            KEYBOARD Chr( 13 )
         ELSE
            EXIT
         ENDIF
      ELSEIF NextKey() = 0
         EXIT
      ENDIF
#else
      IF NextKey() = 0
         EXIT
      ENDIF
#endif
   ENDDO

   RETURN Nil

FUNCTION Fpgm1

   LOCAL choic := 1, bufscr, fname, i
#ifdef RDD_ADS
   LOCAL submenu := { aMsgM[10], aMsgM[11], aMsgM[12], aMsgM[13], "�", ;
      aMsgM[14], aMsgM[15], aMsgM[16], "�", ;
      aMsgM[17], aMsgM[18], aMsgM[19], aMsgM[20], aMsgM[21] }
#else
   LOCAL submenu := { aMsgM[10], aMsgM[11], aMsgM[12], aMsgM[13], "�", ;
      aMsgM[14], aMsgM[15], aMsgM[16], "�", ;
      aMsgM[17], aMsgM[18], aMsgM[23] }
#endif
   LOCAL aDostup := { .T. , .T. , lenmsf > 0, lenmsf > 0, .T. , lenmsf > 0, lenmsf > 0, lenmsf > 0, ;
      .T. , .T. , .T. , .T. , .T. , .T. }

   DO WHILE .T.
      submenu[ 10 ] = Stuff( submenu[ 10 ], 17, 3, iif( Set( _SET_EXCLUSIVE ), "ON ", "OFF" ) )
      submenu[ 11 ] = Stuff( submenu[ 11 ], 17, 3, iif( lRdOnly, "ON ", "OFF" ) )
#ifdef RDD_ADS
      submenu[ 14 ] = Stuff( submenu[ 14 ], 12, 6, iif( nServerType == 1, aMsg[78], aMsg[79] ) )
      submenu[ 13 ] = Stuff( submenu[ 13 ], 10, Len( aDrivers[ numdriv ] ), aDrivers[ numdriv ] )
#else
      submenu[ 12 ] = Stuff( submenu[ 12 ], 12, Len( aDrivers[ numdriv ] ), aDrivers[ numdriv ] )
#endif
      SET COLOR TO + GR/B, N/BG, , , N/B
      @  2,  1, 17, 22 BOX "�Ŀ����� "
      choic := MainMenu( 3, 2, 16, 21, submenu, aDostup, , 1, 1 )
      IF choic = 0 .OR. choic = 501
         RETURN choic
      ENDIF
      bufscr := SaveScreen( 0, 0, 24, 79 )
      DO CASE
      CASE choic = 1
         StruMan( .T. )
      CASE choic = 2
#ifdef __HARBOUR_AX__
         IF nServerType > 1 .AND. Left( mypath, 2 ) == "//"
            fname := hu_Get( aMsg[77] )
         ELSE
            fname := FileMan( @mypath, iif( numdriv == 3, "*.adt", "*.dbf" ), , .T. )
         ENDIF
#else
#ifdef RDD_LETO
         fname := hu_Get( aMsg[77] )
#else
         fname := FileMan( @mypath, "*.dbf", , .T. )
#endif
#endif
         IF !Empty( fname )
            IF ValType( fname ) == "C"
               fdbopen( fname )
            ELSE
               fdbopen( fname[ 1 ], fname[ 2 ] )
            ENDIF
            prkorf  := .T.
            prkorst := .T.
            KEYBOARD Chr( 27 )
            EXIT
         ENDIF
      CASE choic = 3
         fdbclose()
         KEYBOARD Chr( 27 )
      CASE choic = 4
         PECH()
      CASE choic = 6
         Selarea()
         KEYBOARD Chr( 27 )
         EXIT
      CASE choic = 7
         NEXTAREA()
         KEYBOARD Chr( 27 )
         EXIT
      CASE choic = 8
         PREVAREA()
         KEYBOARD Chr( 27 )
         EXIT
      CASE choic = 10
         SET( _SET_EXCLUSIVE, ! Set( _SET_EXCLUSIVE ) )
         lShared := !lShared
      CASE choic = 11
         lRdOnly := ! lRdOnly
#ifdef RDD_ADS
      CASE choic = 12
      CASE choic = 13
         numdriv ++
         IF numdriv == 4
            numdriv := 1
         ENDIF
         AdsSetFileType( iif( numdriv == 1, 2, iif( numdriv == 2, 1, 3 ) ) )
#else
      CASE choic = 12
         numdriv := iif( numdriv = 1, 2, 1 )
         rddSetDefault( aDrivers[ numdriv ] )
#endif

#ifdef __HARBOUR_AX__
      CASE choic == 14
         nServerType := iif( nServerType == 1, 2, 1 )
         AdsSetServerType( nServerType )
         IF nServerType > 1
            fname := hu_Get( aMsg[80] )
            IF LastKey() != 27 .AND. !Empty( fname )
               IF Right( fname ) != "/" .AND. Right( fname ) != "\"
                  fname += DEF_SEP
               ENDIF
            ENDIF
            IF LastKey() == 27 .OR. Empty( fname ) .OR. !AdsConnect( fname )
               nServerType := 1
               AdsSetServerType( nServerType )
               Alert( aMsg[81] )
            ELSE
               mypath := fname
            ENDIF
         ENDIF
#endif

      ENDCASE
      RestScreen( 0, 0, 24, 79, bufscr )
   ENDDO

   RETURN 0

FUNCTION Fpgm2

   LOCAL choic := 1, bufscr, msind[ 1 ], i, indname
   LOCAL submenu := { aMsgM[24], aMsgM[25], aMsgM[26], aMsgM[27] }
   LOCAL aDostup := { lenmsf > 0, lenmsf > 0, lenmsf > 0, lenmsf > 0 }

   DO WHILE .T.
      SET COLOR TO + GR/B, N/BG, , , N/B
      @  2,  8, 7, 35 BOX "�Ŀ����� "
      choic := MainMenu( 3, 9, 6, 34, submenu, aDostup, , 1, 1 )
      IF choic = 0 .OR. lenmsf = 0 .OR. choic = 501
         RETURN choic
      ENDIF
      bufscr := SaveScreen( 0, 0, 24, 79 )
      DO CASE
      CASE choic = 1
         msind[ 1 ] = "0 None"
         i := 1
         DO WHILE ! Empty( indname := OrdName( i ) )
            AAdd( msind, Str( i, 1 ) + " " + PadR( indname, 10 ) + PadR( OrdKey( i ), 50 ) + " " + OrdBagName( i ) )
            i ++
         ENDDO
         @  5,  1, 11, 78 BOX "�Ŀ����� "
         i := MainMenu( 6, 2, 10, 77, msind, , , IndexOrd() + 1, , i )
         IF i > 0
            SET ORDER TO i - 1
            KEYBOARD Chr( 27 )
            EXIT
         ENDIF
      CASE choic = 2
         NewIndex()
      CASE choic = 3
         indname := FileMan( @mypath, iif( numdriv = 1, "*.?dx", "*.ntx" ), , )
         IF ! Empty( indname )
            OrdListAdd( mypath + indname )
         ENDIF
      CASE choic = 4
         OrdListClear()
      ENDCASE
      RestScreen( 0, 0, 24, 79, bufscr )
   ENDDO

   RETURN 0

FUNCTION Fpgm3

   LOCAL choic := 1, bufscr
#ifdef __NOEXTRA__
   LOCAL submenu := { aMsgM[28], "�", aMsgM[29], "�", aMsgM[30], aMsgM[31], aMsgM[32], aMsgM[33] }
   LOCAL aDostup := { lenmsf > 0, lenmsf > 0, .T. , lenmsf > 0, .T. , lenmsf > 0, lenmsf > 0, lenmsf > 0, lenmsf > 0, .T. }
#else
   LOCAL submenu := { aMsgM[28], "�", aMsgM[29], "�", aMsgM[30], aMsgM[31], aMsgM[32], aMsgM[33], "�", aMsgM[34], aMsgM[35] }
   LOCAL aDostup := { lenmsf > 0, lenmsf > 0, .T. , lenmsf > 0, .T. , lenmsf > 0, lenmsf > 0, lenmsf > 0, lenmsf > 0, .T. , lenmsf > 0, lenmsf > 0 }
#endif
   PRIVATE prmsf := .F.

   DO WHILE .T.
      SET COLOR TO + GR/B, N/BG, , , N/B
      @  2, 17, 17, 46 BOX "�Ŀ����� "
      IF lenmsf > 0
         @  3, 19 SAY aMsg[82] + Str( FCount(), 3 )
         @  4, 19 SAY aMsg[83] + Str( RecSize(), 6 ) + aMsg[84]
      ENDIF
      choic := MainMenu( 6, 18, 16, 45, submenu, aDostup, , 1, 1 )
      IF choic = 0 .OR. lenmsf = 0 .OR. choic = 501
         RETURN choic
      ENDIF
      bufscr := SaveScreen( 0, 0, 24, 79 )
      DO CASE
      CASE choic = 1
         StruMan( .F. )
      CASE choic = 3
         EditRec()
      CASE choic = 5
         SelFiel()
      CASE choic = 6
         InsFiel( dbfi_f + dbnumf - 1 )
      CASE choic = 7
         DelFiel( dbfi_f + dbnumf - 1 )
      CASE choic = 8
         ChngFiel( dbfi_f + dbnumf - 1 )
#ifndef __NOEXTRA__
      CASE choic = 10
         IF IS_CLIPBRD()
            SEND_CLIPB( DosToWin( RTrim( LTrim( FLDSTR( dbfi_f + dbnumf - 1 ) ) ) ) )
         ENDIF
      CASE choic = 11
         IF IS_CLIPBRD()
            GET_CLIPB( @cdata )
            WinToDos( @cdata )
         ENDIF
#endif
      ENDCASE
      RestScreen( 0, 0, 24, 79, bufscr )
      KEYBOARD Chr( 27 )
      EXIT
   ENDDO

   RETURN 0

FUNCTION Fpgm4

   LOCAL choic   := 1, bufscr, nrec
   LOCAL submenu := { " 1 LOCATE     Alt-L", " 2 CONTINUE   Alt-N", " 3 SEEK       Alt-S", ;
      " 4 SET FILTER Alt-F", " 5 GO TO      Alt-G" }
   LOCAL aDostup  := { lenmsf > 0, lenmsf > 0, lenmsf > 0, lenmsf > 0, lenmsf > 0 }
   PRIVATE strfnd

   DO WHILE .T.
      SET COLOR TO + GR/B, N/BG, , , N/B
      @  2, 25, 8, 46 BOX "�Ŀ����� "
      choic := MainMenu( 3, 26, 7, 44, submenu, aDostup, , 1, 1 )
      IF choic = 0 .OR. lenmsf = 0 .OR. choic = 501
         RETURN choic
      ENDIF
      DO CASE
      CASE choic = 1
         F_LOCATE()
      CASE choic = 2
         F_CONTIN()
      CASE choic = 3
         F_SEEK()
      CASE choic = 4
         F_FILTER()
      CASE choic = 5
         F_GO()
      ENDCASE
      KEYBOARD Chr( 27 )
      EXIT
   ENDDO

   RETURN 0

FUNCTION Fpgm5

   LOCAL choic   := 1
   LOCAL submenu := { " 1 REPLACE", " 2 DELETE", " 3 RECALL", " 4 COUNT", " 5 SUM", ;
      " 6 APPEND FROM", " 7 COPY TO", " 8 REINDEX", " 9 PACK", " 0 ZAP", "�", " DO SCRIPT", "�", " MEMO      ", " SET RELATION" }
   LOCAL aDostup := { lenmsf > 0 .AND. ! lRdOnly, lenmsf > 0 .AND. ! lRdOnly, lenmsf > 0 .AND. ! lRdOnly, ;
      lenmsf > 0, lenmsf > 0, lenmsf > 0 .AND. ! lRdOnly, lenmsf > 0, lenmsf > 0 .AND. ! lRdOnly, ;
      lenmsf > 0 .AND. ! lRdOnly, lenmsf > 0 .AND. ! lRdOnly, lenmsf > 0, lenmsf > 0, lenmsf > 0, lenmsf > 0, lenmsf > 0 }
   LOCAL arScr := {}, obl, fname

   DO WHILE .T.
      SET COLOR TO + GR/B, N/BG, , , N/B
      @  2, 36, 18, 52 BOX "�Ŀ����� "
      choic := MainMenu( 3, 37, 17, 51, submenu, aDostup, , 1, 1 )
      IF choic = 0 .OR. lenmsf = 0 .OR. choic = 501
         RETURN choic
      ENDIF
      DO CASE
      CASE choic = 1
         C_REPL()
      CASE choic = 2 .OR. choic = 3
         C_DELE( iif( choic = 2, .T. , .F. ) )
      CASE choic = 4
         C_COUN()
      CASE choic = 5
         C_SUM()
      CASE choic = 6
         C_APPE()
      CASE choic = 7
         C_COPY()
      CASE choic = 8
         C_REIN()
      CASE choic = 9
         C_PACK()
      CASE choic = 10
         C_ZAP()
      CASE choic = 12
         fname := FileMan( "", "*.scr" )
         IF ! Empty( fname )
            IF ( arScr := RdScript( fname ) ) <> Nil
               obl := Select()
               FGOTOP( mslist )
               DO ANIMA WITH 0, iif( LI_PRFLT, LI_KOLZ, RecCount() ), aMsg[85] + fname + aMsg[86], 8, 6, 72
               DO WHILE ! FEOF( mslist )
                  DoScript( arScr )
                  DO ANIMA WITH 1
                  SELECT( obl )
                  FSKIP( mslist, 1 )
               ENDDO
               DO ANIMA WITH 2, 0, aMsg[75]
            ELSE
               MsgSay( aMsg[76] )
            ENDIF
         ENDIF
      CASE choic = 14
         MemoFuncs()
      CASE choic = 15
         C_SETR()
      ENDCASE
   ENDDO

   RETURN 0

FUNCTION Fpgm6

   LOCAL choic := 1, bufscr, fname, rez
   LOCAL submenu := { aMsgM[36], aMsgM[37] }

   DO WHILE .T.
      SET COLOR TO + GR/B, N/BG, , , N/B
      @  2, 44, 5, 58 BOX "�Ŀ����� "
      choic := MainMenu( 3, 45, 4, 57, submenu, , , 1, 1 )
      IF choic = 0 .OR. choic = 501
         RETURN choic
      ENDIF
      bufscr := SaveScreen( 0, 0, 24, 79 )
      DO CASE
      CASE choic = 1
         fname := FileMan( "", "*.vew" )
         IF ! Empty( fname )
            RdView( mypath + fname )
         ENDIF
      CASE choic = 2
         fname := FileMan( "", "*.vew", .T. )
         IF LastKey() <> 27 .AND. ! Empty( fname )
            WrView( fname )
         ENDIF
      ENDCASE
      RestScreen( 0, 0, 24, 79, bufscr )
      KEYBOARD Chr( 27 )
      EXIT
   ENDDO

   RETURN 0

FUNCTION Fpgm7

   LOCAL choic := 1, bufscr, fname, rez
#ifdef __HARBOUR_AX__
   LOCAL submenu := { aMsgM[38], aMsgM[39], aMsgM[40], aMsgM[41] }
#else
   LOCAL submenu := { aMsgM[38], aMsgM[39], aMsgM[40], aMsgM[41], aMsgM[42] }
#endif

   DO WHILE .T.
#ifndef __HARBOUR_AX__
      submenu[ 5 ] = Stuff( submenu[ 5 ], 16, 3, iif( que_simpl, "ON ", "OFF" ) )
#endif
      SET COLOR TO + GR/B, N/BG, , , + GR/B
      @  2, 52, 8, 73 BOX "�Ŀ����� "
      choic := MainMenu( 3, 53, 7, 72, submenu, , , 1, 1 )
      IF choic = 0 .OR. choic = 501
         RETURN choic
      ENDIF
      bufscr := SaveScreen( 0, 0, 24, 79 )
      DO CASE
      CASE choic = 1
         CreatQuery()
      CASE choic = 2
         fname := FileMan( @quepath, "*.que" )
         IF ! Empty( fname )
            OpenQuery( quepath + fname )
            EditQuery()
         ENDIF
      CASE choic = 3
         CreatQuery( .T. )
      CASE choic = 4
         WriteQuery()
#ifndef __HARBOUR_AX__
      CASE choic = 5
         que_simpl := ! que_simpl
#endif
      ENDCASE
      RestScreen( 0, 0, 24, 79, bufscr )
   ENDDO

   RETURN 0

FUNCTION Fpgm8

   LOCAL choic := 1, bufscr, expr, rez, i
   LOCAL arScr := {}, fname, clr
   LOCAL submenu := { aMsgM[43], aMsgM[44], aMsgM[45], ;
      aMsgM[46], aMsgM[47], aMsgM[48], aMsgM[49] }

   DO WHILE .T.
      submenu[ 5 ] = Stuff( submenu[ 5 ], 11, 4, iif( lWinChar, "ANSI", "OEM " ) )
      submenu[ 6 ] = Stuff( submenu[ 6 ], 20, 3, iif( memownd, "ON ", "OFF" ) )
      SET COLOR TO + GR/B, N/BG, , , + GR/B
      @  2, 51, 10, 79 BOX "�Ŀ����� "
      choic := MainMenu( 3, 52, 9, 78, submenu, , , 1, 1 )
      IF choic = 0 .OR. choic = 501
         RETURN choic
      ENDIF
      DO CASE
      CASE choic = 1
         lEngl := !lEngl
         DeclStrings()
         clr := Setcolor( "N/B" )
         @ 1, 0 CLEAR TO 1, 79
         Setcolor( clr )
         KEYBOARD Chr( 27 )
         EXIT
      CASE choic = 2
         modesplit := ! modesplit
         IF modesplit
            impr1 := improc
            impr2 := 0
            FOR i := improc + 1 TO lenmsf
               IF aFiles[ i,AF_NAME ] != Nil
                  impr2 := i
                  EXIT
               ENDIF
            NEXT
            IF impr2 = 0
               FOR i := improc - 1 TO 1 STEP - 1
                  IF aFiles[ i,AF_NAME ] != Nil
                     impr2 := i
                     EXIT
                  ENDIF
               NEXT
            ENDIF
            wndfirst := .T.
         ENDIF
         ScrClr := .T.
         KEYBOARD Chr( 27 )
         EXIT
      CASE choic = 3
         Calc_exp()
      CASE choic = 4
         Dateman( 6, 60, 14, 72 )
      CASE choic = 5
         lWinChar := !lWinChar
      CASE choic = 6
         memownd := ! memownd
      CASE choic = 7
         fname := FileMan( "", "*.scr" )
         IF ! Empty( fname )
            IF ( arScr := RdScript( fname ) ) <> Nil
               DoScript( arScr )
               MsgSay( aMsg[75], "N/W" )
            ELSE
               MsgSay( aMsg[76] )
            ENDIF
         ENDIF
         KEYBOARD Chr( 27 )
         EXIT
      ENDCASE
   ENDDO

   RETURN 0

FUNCTION Fpgm9

   LOCAL choic := 1, bufscr
   LOCAL submenu := { aMsg[87] }
   LOCAL stra1   := aMsg[88]
   LOCAL stra3   := aMsg[89]
   LOCAL stra4   := aMsg[90]
#ifdef __HARBOUR__
#ifdef RDD_ADS
   LOCAL stra2 := aMsg[91] + "( ADS )"
#else
#ifdef RDD_LETO
   LOCAL stra2 := aMsg[91] + "( Leto )"
#else
   LOCAL stra2 := aMsg[91]
#endif
#endif
#else
   LOCAL stra2 := aMsg[91]
#endif

   DO WHILE .T.
      SET COLOR TO + GR/B, N/BG, , , + GR/B
      @  2, 45, 12, 79 BOX "�Ŀ����� "
      @  3, 46 SAY Padc( stra1, 33 )
      @  4, 46 SAY Padc( stra2, 33 )
#ifdef __HARBOUR__
      @  5, 46 SAY Padc( "Harbour " + LTrim( Str(hb_Version(HB_VERSION_MAJOR ) ) ) + "." + LTrim( Str(hb_Version(HB_VERSION_MINOR ) ) ) + "." + LTrim( Str(hb_Version(HB_VERSION_RELEASE ) ) ), 33 )
      @  6, 46 SAY Padc( hb_Compiler(), 33 )
#endif
      @  8, 46 SAY Padc( stra3, 33 )
      @  9, 46 SAY Padc( stra4, 33 )
      @  10, 46 TO 10, 78
      choic := MainMenu( 11, 58, 11, 64, submenu, , , 1, 1 )
      IF choic = 0 .OR. choic = 501
         RETURN choic
      ENDIF
      DO CASE
      CASE choic = 1
         CLOSE ALL
         SET COLOR TO W/N
         @  0,  0 CLEAR TO 24, 79
         QUIT
      ENDCASE
   ENDDO

   RETURN 0

FUNCTION FileLock()

   LOCAL fname := aFiles[ improc,AF_NAME ]

   IF !aFiles[ improc,AF_EXCLU ]
      USE &fname EXCLUSIVE
      IF NetErr()
         MsgSay( aMsg[92] )
         USE &fname SHARED
         RETURN .F.
      ELSE
         aFiles[ improc,AF_EXCLU ] := .T.
      ENDIF
   ENDIF

   RETURN .T.

FUNCTION FileMan( cPath, fspec, prnew, lAlias )

   LOCAL fname, aFiles, arr
   LOCAL i, bufscr, oldc, lkey
   LOCAL aDisk := {}, chgpath := .T. , curdr, drLetter, cDrive
   LOCAL filename  := Space( 30 ), prfirst := .T. , choic := 1
   PRIVATE aCtrl   := { { "", { || __keyboard( Chr( K_TAB ) ) }, 8, 24, 12, 45 }, { "", { || __keyboard( Chr( K_UP ) ) }, 7, 54, 7, 56 }, { "",, 16, 22, 16, 56 } }
   PRIVATE Ctrlist := { "W+/RB,W+/B", aCtrl }
   PRIVATE GetList := {}

   fspec  := Upper( fspec )
   prnew  := iif( prnew = Nil, .F. , prnew )
   lAlias := iif( lAlias == Nil, .F. , lALias )
   bufscr := SaveScreen( 4, 20, 18, 60 )
   oldc   := Setcolor()
   DO WHILE .T.
      IF prfirst
#ifndef __NOEXTRA__
         IF SubStr( cPath, 2, 1 ) = ":"
            curdr := Asc( cPath ) - 64
         ELSE
            curdr := CurrDrive()
         ENDIF
         cDrive := drLetter := Chr( curdr + 64 )
#endif
         Setcolor( "W+/RB" )
         @  4, 20, 18, 60 BOX DRAMKA
         @  5, 22 SAY "Choose file:"
         IF lAlias
            @ 15, 22 SAY "Alias:"
         ENDIF
#ifndef __NOEXTRA__
         @  5, 52 SAY "Drive:"
         cPath := iif( Empty( cPath ), drLetter + ":/" + CurDir() + iif( Empty( CurDir() ), "", "/" ), cPath )
#else
         cPath := iif( Empty( cPath ), DEF_SEP + CurDir() + iif( Empty( CurDir() ), "", DEF_SEP ), cPath )
#endif
         IF prnew
            @ 16, 22 SAY filename COLOR "N/W"
         ENDIF
         @ 17, 22 SAY cPath
#ifndef __NOEXTRA__
         @  6, 53, 8, 57 BOX "�Ŀ����� "
         @  7, 55 SAY drLetter
#endif
         @  6, 22, 14, 47 BOX "�Ŀ����� "
         Setcolor( "N/W,W+/N" )
         @  7, 23 CLEAR TO 13, 46
         IF chgpath
            arr  := Directory( cPath + "*", "D" )
            aFiles := {}
            FOR i := 1 TO Len( arr )
               IF "D" $ arr[ i,5 ]
                  IF !( "." == arr[ i,1 ] )
                     AAdd( aFiles, " " + arr[ i,1 ] )
                  ENDIF
               ELSEIF CmpMsk( Upper( arr[ i,1 ] ), fspec )
                  AAdd( aFiles, arr[ i,1 ] )
               ENDIF
            NEXT
#ifdef __UNIX__
            IF Ascan( aFiles, " .." ) == 0
               AAdd( aFiles, " .." )
            ENDIF
#endif
            ASort( aFiles, , , { |z, y|Lower( z ) < Lower( y ) } )
            chgpath := .F.
            choic   := 1
         ENDIF

         i := MainMenu( 7, 23, 13, 46, aFiles, , { | p1, p2 | userfi( p1, p2 ) }, @choic )
         IF i = 0
            EXIT
         ENDIF
      ELSE
         i       := 1001
         prfirst := .T.
      ENDIF
      IF i == 1001
#ifndef __NOEXTRA__
         ReadExit( .T. )
         @  7, 55 GET drLetter VALID !Empty( drLetter := DriveChoose( aDisk, drLetter ) )
         READ
         ReadExit( .F. )
         IF cDrive <> drLetter .AND. LastKey() <> 27
            cDrive  := drLetter
            cPath   := drLetter + ":\"
            chgpath := .T.
         ENDIF
         IF LastKey() == K_TAB
            i := 1001
         ENDIF
#endif
      ELSEIF i < 500
         IF Left( aFiles[ i ], 1 ) != " "
            IF prnew
               // LOOP
            ELSE
               IF !IsDigit( aFiles[ choic ] )
                  EXIT
               ENDIF
            ENDIF
         ELSE
            IF Left( aFiles[ i ], 2 ) == " ."
               j := RAt( DEF_SEP, Left( cPath, Len( cPath ) - 1 ) )
               IF j > 0
                  cPath := Left( cPath, j )
               ENDIF
            ELSE
               cPath += SubStr( aFiles[ i ], 2 ) + DEF_SEP
            ENDIF
            chgpath := .T.
            LOOP
         ENDIF
      ENDIF
      IF ( prnew .OR. lAlias ) .AND. ! ( chgpath .AND. i = 1001 )
         IF lAlias .OR. LastKey() == 13
            filename := PadR( CutExten( aFiles[ choic ] ), 30 )
         ENDIF
         ReadExit( .T. )
         @ 16, 22 GET filename COLOR "N/W,N/W"
         READ
         ReadExit( .F. )
         lkey := LastKey()
         DO CASE
         CASE lkey = K_SH_TAB .OR. lkey = K_UP
            prfirst := .F.
         CASE lkey == K_ENTER .AND. ! Empty( filename )
            IF prnew
               IF At( ".", filename ) = 0
                  filename := RTrim( filename ) + "." + FilExten( fspec )
               ELSE
                  filename := RTrim( filename )
               ENDIF
               IF !File( cPath + filename ) .OR. MsgYesNo( filename + aMsg[93] )
                  EXIT
               ELSE
                  filename := PadR( filename, 30 )
               ENDIF
            ELSE
               EXIT
            ENDIF
         CASE lkey = 27 .OR. ( lkey = K_ENTER .AND. Empty( filename ) )
            i := 0
            EXIT
         ENDCASE
      ENDIF
   ENDDO
   Setcolor( oldc )
   RestScreen( 4, 20, 18, 60, bufscr )

   RETURN iif( i == 0, "", iif( prnew, filename, iif( lAlias .AND. !Empty( filename ), { aFiles[ choic ], filename }, aFiles[ choic ] ) ) )

#ifndef __NOEXTRA__

STATIC FUNCTION DriveChoose( aDisk, drLetter )

   LOCAL j, j1, bufs1, choic := 1

   IF Empty( aDisk )
      j  := 1
      j1 := 0
      DO WHILE .T.
         IF DiskAbout( j ) < 18
            AAdd( aDisk, " " + Chr( j + 64 ) + " " )
            j1 := 0
         ELSEIF j1 > 2
            EXIT
         ELSE
            j1 ++
         ENDIF
         j ++
      ENDDO
   ENDIF
   drLetter := Upper( drLetter )
   IF ASCAN( aDisk, ' ' + drLetter + ' ' ) == 0
      bufs1 := SaveScreen( 8, 53, 15, 57 )
      @  8, 53, 15, 57 BOX "�Ŀ����� "
      MainMenu( 9, 54, 14, 56, aDisk, , , @choic )
      RestScreen( 8, 53, 15, 57, bufs1 )
   ELSE
      RETURN AllTrim( drLetter )
   ENDIF

   RETURN AllTrim( aDisk[ choic ] )

#endif

FUNCTION Userfi( nind, key )

   LOCAL rez := 2, i
#ifdef VER_MOUSE

   IF key = 501
      i := F_CTRL( aCtrl, , , , , , 1, M_YTEXT(), M_XTEXT() )
   ENDIF
#endif
   DO CASE
   CASE key = K_TAB .OR. ( key = 501 .AND. i = 2 )
      rez := 1001
   CASE key = K_SH_TAB .OR. ( key = 501 .AND. i = 3 )
      rez := 1002
   ENDCASE

   RETURN rez

FUNCTION DateMan( y1, x1, y2, x2 )

   LOCAL i, bufscr

   bufscr := SaveScreen( y1, x1, y2, x2 )
   @ y1, x1, y2, x2 BOX "�Ŀ����� "
   i := MainMenu( y1 + 1, x1 + 1, y2 - 1, x2 - 1, aDateF, , , , , , .T. )
   RestScreen( y1, x1, y2, x2, bufscr )
   IF i > 0 .AND. i < 500
      dformat := aDateF[ i ]
      SET DATE FORMAT dformat
   ENDIF

   RETURN Nil

FUNCTION NewIndex

   LOCAL bufsc, oldc, indname, i, prmulti := "Y", tagname := "          "
   LOCAL expkey := Space( 100 ), expfor := Space( 100 )

   indname := PadR( CutExten( CutPath( aFiles[ improc,AF_NAME ] ) ) + IndexExt(), 46 )
   bufsc   := SaveScreen( 6, 20, 13, 70 )
   oldc    := Setcolor()
   SET COLOR TO + W/GR, N +/ W, , , + W/GR
   @  6, 20, 14, 70 BOX "�Ŀ����� "
   @  7, 25 SAY aMsg[94] + CutPath( aFiles[ improc,AF_NAME ] ) COLOR "+GR/GR"
   @  8, 22 SAY aMsg[39] GET indname  PICTURE Replicate( 'X', 36 )
   IF aFiles[ improc,AF_DRIVER ] = 1
      @  9, 22 SAY "MultiBag (Y/N)" GET prmulti PICTURE "X" VALID prmulti $ "YyNn"
      @  9, 40 SAY "�ag" GET tagname PICTURE "XXXXXXXXXX" WHEN prmulti $ "Yy"
   ENDIF
   @ 10, 22 SAY aMsg[95]
   @ 12, 22 SAY aMsg[96]
   @ 11, 22 GET expkey PICTURE "@S36"
   @ 13, 22 GET expfor PICTURE "@S36"
   READ
   IF LastKey() != 27
      MsgInf( aMsg[17] )
      indname := mypath + indname
      IF numdriv = 1 .AND. prmulti $ "Yy"
         IF Empty( expfor )
            OrdCreate( RTrim( indname ), RTrim( tagname ), RTrim( expkey ), &( "{||" + RTrim( expkey ) + "}" ) )
         ELSE
            ordCondSet( RTrim( expfor ), &( "{||" + RTrim( expfor ) + "}" ), , , , , RecNo(), , , , )
            OrdCreate( RTrim( indname ), RTrim( tagname ), RTrim( expkey ), &( "{||" + RTrim( expkey ) + "}" ) )
         ENDIF
      ELSE
         IF Empty( expfor )
            dbCreateIndex( RTrim( indname ), RTrim( expkey ), &( "{||" + RTrim( expkey ) + "}" ) )
         ELSE
            ordCondSet( RTrim( expfor ), &( "{||" + RTrim( expfor ) + "}" ), , , , , RecNo(), , , , )
            OrdCreate( RTrim( indname ), , RTrim( expkey ), &( "{||" + RTrim( expkey ) + "}" ) )
         ENDIF
      ENDIF
      MsgInf( aMsg[97] )
   ENDIF
   RestScreen( 6, 20, 13, 70, bufsc )
   Setcolor( oldc )

   RETURN Nil

FUNCTION EditRec

   LOCAL bufc, oldc, i, kolf := FCount(), firstf, lastf, lkey, prupdt, fType
   PRIVATE GetList := {}
   PRIVATE maspic[ kolf ], varname

   IF Eof()
      RETURN Nil
   ENDIF
   bufsc := SaveScreen( 4, 3, 22, 76 )
   oldc  := Setcolor()
   FOR i := 1 TO kolf
      varname := "get" + NUM_STR( i, 2 )
      PRIVATE &varname
   NEXT
   DO FLMSFLD WITH maspic, .T. , 60
   firstf := 1
   lastf  := Min( kolf, 16 )
   prupdt := .F.
   DO WHILE .T.
      SET COLOR TO + GR/RB
      @  4,  3, 22, 76 BOX "�Ŀ����� "
      IF lRdOnly
         @  4,  6 SAY "(ReadOnly)"
      ENDIF
      IF lastf < kolf
         @ 22,  6 SAY " Page Down  "
      ENDIF
      IF firstf > 1
         @ 22, 21 SAY " Page Up  "
      ENDIF
      FOR i := firstf TO lastf
         @  6 + i - firstf, 5 SAY FieldName( i )
      NEXT
      SET COLOR TO + W/RB, N +/ W, , , + W/RB
      FOR i := firstf TO lastf
         varname := "get" + NUM_STR( i, 2 )
         fType   := dbFieldInfo( 2, i )
         IF lWinChar .AND. ( fType == "C" .OR. fType == "M" ) .AND. ValType( &varname ) != "U"
            &varname := WinToDos( &varname )
         ELSEIF ftype == "T" .AND. dbFieldInfo( 3, i ) == 4
            &varname := Transform( &varname, "@T" )
         ENDIF
         @  6 + i - firstf, 15 GET &varname PICTURE iif( fType == "M", "@S50", maspic[i] )
      NEXT
      SET KEY 30 TO f_ctrl_pg
      SET KEY 31 TO f_ctrl_pg
      READ
      SET KEY 31 TO
      SET KEY 30 TO
      IF Updated()
         prupdt := .T.
      ENDIF
      lkey := LastKey()
      DO CASE
      CASE lkey = 27
         lkey := NextKey()
         IF ( prupdt .OR. Updated() ) .AND. !aFiles[ improc,AF_RDONLY ]
            IF MsgYesNo( aMsg[98] )
               IF ! Set( _SET_EXCLUSIVE )
                  RLock()
               ENDIF
               FOR i := 1 TO kolf
                  varname := "get" + NUM_STR( i, 2 )
                  fType   := dbFieldInfo( 2, i )
                  IF lWinChar .AND. ( fType == "C" .OR. fType == "M" )
                     &varname := DosToWin( &varname )
                  ELSEIF ftype == "T" .AND. dbFieldInfo( 3, i ) == 4
                     &varname := &( 't"' + &varname + '"' )
                  ELSEIF ftype $ "+=^"
                     LOOP
                  ENDIF
                  FieldPut( i, &varname )
               NEXT
               IF ! Set( _SET_EXCLUSIVE )
                  UNLOCK
               ENDIF
            ENDIF
         ENDIF
         IF !Empty( lkey ) .AND. lkey != 27
            KEYBOARD Chr( lkey ) + Chr( 2 )
         ENDIF
         EXIT
      CASE lkey = 3
         IF lastf < kolf
            firstf := lastf + 1
            lastf  := Min( kolf, lastf + 16 )
         ENDIF
      CASE lkey = 18
         IF firstf > 1
            firstf -= 16
            lastf  := firstf + 15
         ENDIF
      ENDCASE
   ENDDO
   Setcolor( oldc )
   RestScreen( 4, 3, 22, 76, bufsc )

   RETURN Nil

STATIC FUNCTION f_ctrl_pg

   KEYBOARD Chr( 27 ) + iif( LastKey() == 30, Chr( 24 ), Chr( 5 ) )

   RETURN Nil

STATIC FUNCTION Calc_exp

   LOCAL GetList := {}
   LOCAL oldc, bufscr, txget := Space( 200 ), xRez, bOldError, lRes

   bufscr := SaveScreen( 08, 12, 13, 66 )
   oldc   := Setcolor()
   SET COLOR TO + W/RB, B/W, , , + W/RB
   @ 08, 12, 13, 66 BOX "�Ŀ����� "
   DO WHILE .T.
      @ 09, 14 SAY aMsg[ 5 ]
      @ 10, 14 GET txget PICTURE "@S50"
      READ
      IF LastKey() = 27
         EXIT
      ENDIF
      lRes := .T.
      bOldError := ErrorBlock( { |e|break( e ) } )
      BEGIN SEQUENCE
         xRez := &( Trim( txget ) )
      RECOVER
         MsgSay( aMsg[ 4 ] )
         lRes := .F.
      END SEQUENCE
      IF lRes
         @ 11, 14 SAY aMsg[ 6 ]
         @ 12, 14 CLEAR TO 12, 65
         @ 12, 14 SAY iif( xRez == Nil, "Nil", Transform( xRez, "@B" ) )
      ENDIF
   ENDDO
   Setcolor( oldc )
   RestScreen( 08, 12, 13, 66, bufscr )

   RETURN Nil

FUNCTION MsgYesNo( tsoob )

   LOCAL GetList := {}
   LOCAL oldc, bufscr, txget := " "

   bufscr := SaveScreen( 07, 15, 13, 65 )
   oldc   := Setcolor()
   SET COLOR TO + W/R, B/W, , , + W/RB
   @ 07, 15, 13, 65 BOX DRAMKA
   @ 09, 16 SAY PADC( tsoob, 49 )
   @ 11, 23 SAY "(Yes/No)"        GET txget PICTURE "X" VALID txget $ "YyNn"
   READ
   Setcolor( oldc )
   RestScreen( 07, 15, 13, 65, bufscr )
   IF LastKey() = 27
      RETURN .F.
   ENDIF

   RETURN txget $ "Yy"

FUNCTION MsgInf( tsoob )

   LOCAL oldc

   oldc := Setcolor()
   SET COLOR TO "N/W"
   @  2,  0 CLEAR TO 2, 22
   IF tsoob <> Nil
      txtinf := tsoob
   ENDIF
   @  2,  0 SAY txtinf
   IF tsoob = Nil
      txtinf := ""
   ENDIF
   Setcolor( oldc )

   RETURN Nil

PROCEDURE SHADOW( y1, x1, y2, x2 )

   SET COLOR TO N +/ N
   @ y2 + 1, x1 + 1, y2 + 1, x2 + 1 BOX Replicate( Chr( 220 ), 9 )
   @ y1 + 1, x2 + 1 CLEAR TO y2, x2 + 1
   @ y1, x2 + 1 SAY Chr( 223 )

   RETURN

FUNCTION Deshf

   RETURN

FUNCTION Selarea

   LOCAL i := 0, oldc

   oldc := Setcolor()
   SET COLOR TO + GR/B, B/W
   Vldareas( @i, .T. )
   IF i > 0
      improc := i
      prkorf := .T.
   ENDIF
   Setcolor( oldc )

   RETURN Nil

FUNCTION CmpMsk( strcmp, mask )

   LOCAL lenm := Len( mask ), i, poz1 := 1, poz2, symb

   FOR i := 1 TO lenm
      symb := SubStr( mask, i, 1 )
      IF symb = "*"
         IF i = lenm
            RETURN .T.
         ELSE
            symb := SubStr( mask, i + 1, 1 )
            DO WHILE .T.
               poz2 := At( symb, SubStr( strcmp, poz1 ) )
               IF poz2 = 0
                  RETURN .F.
               ENDIF
               poz1 += poz2 - 1
               IF CmpMsk( SubStr( strcmp, poz1 ), SubStr( mask, i + 1 ) )
                  RETURN .T.
               ENDIF
               poz1 ++
            ENDDO
         ENDIF
      ELSEIF symb = "?"
         poz1 ++
      ELSE
         IF symb <> SubStr( strcmp, poz1, 1 )
            RETURN .F.
         ENDIF
         poz1 ++
      ENDIF
   NEXT

   RETURN .T.

FUNCTION OutCtrls( mctrl )

   LOCAL i, j, oldc

   oldc := Setcolor()
   FOR i := 1 TO Len( mctrl )
      IF ValType( mctrl[ i ] ) = "C"
         Setcolor( mctrl[ i ] )
      ELSE
         FOR j := 1 TO Len( mctrl[ i ] )
            @ mctrl[ i, j, 3 ], mctrl[ i, j, 4 ] SAY mctrl[ i, j, 1 ]
         NEXT
      ENDIF
   NEXT
   Setcolor( oldc )

   RETURN .T.

#ifdef __HARBOUR__

   EXIT PROCEDURE ExitDBC

#ifdef RDD_ADS
   AdsApplicationExit()
#endif

   RETURN

#endif

#ifdef __HARBOUR_AX__

   ANNOUNCE RDDSYS
#endif
