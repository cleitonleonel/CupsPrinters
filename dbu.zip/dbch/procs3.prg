/*
 * Common procedures
 * 
 *
 * Author: Alexander S.Kresin <alex@kresin.ru>
 *         www - http://www.kresin.ru/
 * Released to Public Domain
*/

#include "fileio.ch"
#include "deflist.ch"

MEMVAR kolz

FUNC NUM_STR( NOM, KOLZN )

   NOM := Int( NOM )
RETURN ( Replicate( "0", KOLZN - Len( Ltrim( Str( NOM ) ) ) ) + Ltrim( Str( NOM ) ) )

FUNCTION ACondAdd( arr, kolItems, aItems )

LOCAL i, nIndex
   kolItems := Iif( kolItems == Nil, Len( arr ), kolItems )
   IF ( nIndex := ASCAN( arr, { | aVal | aVal[ 1 ] == aItems[ 1 ] }, 1, kolItems ) ) == 0
      IF ++ kolItems > Len( arr )
         Aadd( arr, Array( Len( aItems ) ) )
         Afill( arr[ Len( arr ) ], 0 )
      ENDIF
      arr[ kolItems, 1 ] := aItems[ 1 ]
      nIndex             := kolItems
   ENDIF
   FOR i := 2 TO Len( aItems )
      IF Valtype( aItems[ i ] ) == "N"
         arr[ nIndex, i ] += aItems[ i ]
      ENDIF
   NEXT
RETURN nIndex

FUNCTION AsortM( arr, lDesc, n )

   IF n == Nil; n := 1; ENDIF
RETURN Iif( lDesc == Nil .OR. !lDesc, Asort( arr,,, { | z, y | z[ n ] < y[ n ] } ), Asort( arr,,, { | z, y | z[ n ] > y[ n ] } ) )

FUNCTION AFind( fsch, nItem, arr, kolItems )

LOCAL i, rsum := 0, aFnd, kola
STATIC aTmp, nTmp

   IF fsch == Nil
      aTmp := arr
      nTmp := kolItems
   ELSE
      nItem := Iif( nItem == Nil, 2, nItem )
      aFnd  := Iif( arr == Nil, aTmp, arr )
      kola  := Iif( kolItems == 0, nTmp, kolItems )
      FOR i := 1 TO kola
         IF aFnd[ i, 1 ] = fsch
            rsum += aFnd[ i, nItem ]
         ENDIF
      NEXT
   ENDIF

RETURN rsum

FUNCTION PLIF( n )

RETURN Iif( n > 0, n, 0 )

FUNCTION TRANSNUM( vnum )

RETURN Iif( m->rou_dec = 0, Transform( vnum, "999 999 999 999" ), Transform( vnum, "999 999 999 999.99" ) )


FUNCTION OBRSUB( sseek, blockf, block0, lAdd )
LOCAL bind, nrec, kolz := 0
Memvar mslist

   IF lAdd == Nil 
      lAdd := .F.
   ENDIF

   carr_Init( @LI_CARR,512 )
   SEEK sseek
   IF !Eof()
      bind := &( "{||" + Ordkey() + "}" )
      IF blockf = Nil
         blockf := { || .T. }
      ELSE
         blockf := &( "{||" + blockf + "}" )
      ENDIF
      DO WHILE !Eof() .AND. Eval( bind ) = sseek
         IF Eval( blockf )
            kolz ++
            IF kolz == 1
               nrec := Recno()
            ENDIF
            IF lAdd
               carr_Put( @LI_CARR, Recno(), kolz )
            ENDIF
            IF block0 != Nil
               Eval( block0 )
            ELSEIF !lAdd
               EXIT
            ENDIF
         ENDIF
         SKIP
      ENDDO
      IF kolz > 0
         GO nrec
      ENDIF
   ENDIF
   IF lAdd
      LI_PRFLT := .T.
      LI_TEKZP := 1
   ENDIF
RETURN kolz


FUNCTION SDIV( str, rlen )

LOCAL i, strtmp, vname, poz1
MEMVAR part1, part2, part3, part4, part5

   STORE Space( rlen ) TO part2, part3, part4, part5
   str := Trim( str )
   FOR i := 1 TO 5
      vname := "part" + Str( i, 1 )
      IF ( poz1 := At( ";;", str ) ) > 0 .AND. poz1 <= rlen
         &vname := Substr( str, 1, poz1 - 1 )
         str    := Substr( str, poz1 + 2 )
      ELSE
         IF Len( str ) <= rlen
            &vname := str
            EXIT
         ENDIF
         strtmp := Substr( str, 1, rlen )
         poz1   := Max( Rat( " ", strtmp ), Rat( ",", strtmp ) )
         poz1   := Max( poz1, Rat( ".", strtmp ) )
         IF poz1 = 0
            poz1 := rlen
         ENDIF
         &vname := Substr( str, 1, poz1 )
         str    := Substr( str, poz1 + 1 )
      ENDIF
   NEXT
RETURN part1

FUNCTION StrinDiv( stroka, partLen, partNum )

LOCAL i := 1, strtmp, pos := 1, pos1
   DO WHILE i <= partNum
      strtmp := Substr( stroka, pos, partLen )
      IF Len( strtmp ) < partLen
         pos1 := 0
      ELSE
         pos1 := Max( Max( Rat( " ", strtmp ), Rat( ",", strtmp ) ), Rat( ".", strtmp ) )
      ENDIF
      pos += Iif( pos1 = 0, partLen, pos1 )
      i ++
   ENDDO
RETURN Iif( pos1 = 0, strtmp, Left( strtmp, pos1 ) )

FUNCTION MsgSay( tsoob, clr )

LOCAL oldc, bufscr, ln := Len( tsoob ), x1
   x1     := 40 - Int( ln / 2 ) - 3
   bufscr := Savescreen( 10, x1, 12, x1 + ln + 4 )
   oldc   := Setcolor()
   Setcolor( Iif( clr = Nil, "+W/R", clr ) )
   @ 10, x1, 12, x1 + ln + 4 BOX "�Ŀ����� "
   @ 11, x1 + 2 SAY tsoob         
   WAIT ""
   Setcolor( oldc )
   Restscreen( 10, x1, 12, x1 + ln + 4, bufscr )
RETURN .T.

FUNCTION hu_Get( tsoob, tpict, txget, clr )

LOCAL GetList := {}
LOCAL oldc, bufscr, x1, lennm := Max( 52, Len( tsoob ) )

   txget  := Iif( Empty(txget).AND.Valtype(txget)!="N", Space( 200 ), Iif( Valtype( txget ) $ "CM", Padr( txget, 200 ), txget ) )
   x1     := Int( ( 76 - lennm ) / 2 ) - 2
   bufscr := Savescreen( 08, x1, 11, x1 + lennm + 4 )
   IF clr == Nil; clr := "+W/RB,B/W,,,+W/RB"; ENDIF
   oldc   := Setcolor( clr )
   @ 08, x1, 11, x1 + lennm + 4 BOX "�Ŀ����� "
   @ 09, x1 + 2 SAY tsoob                                                   
   @ 10, x1 + 2 GET txget PICTURE Iif( tpict <> Nil, tpict, "@S50" )        
   READ
   Setcolor( oldc )
   Restscreen( 08, x1, 11, x1 + lennm + 4, bufscr )
   IF Lastkey() = 27
      RETURN ""
   ENDIF
RETURN Iif( Valtype( txget ) = "C", Trim( txget ), txget )

FUNCTION MsgMGet( title, aGets, cColor )

LOCAL GetList := {}
LOCAL i, oldc, bufscr
LOCAL nCols   := Len( title ), nRows := Len( aGets ) + 4, nCols1 := 0
LOCAL x1, y1

   IF cColor == Nil
      cColor := "+W/RB,B/W,,,+W/RB"
   ENDIF
   FOR i := 1 TO Len( aGets )
      nCols1 := Max( nCols1, Len( aGets[ i, 1 ] ) )
   NEXT
   nCols  := Min( 76, Max( nCols, Max( nCols1 + 30, 52 ) ) )
   x1     := Int( ( 76 - nCols ) / 2 ) - 2
   y1     := Int( ( 24 - nRows ) / 2 )
   bufscr := Savescreen( y1, x1, y1 + nRows - 1, x1 + nCols + 4 )
   oldc   := Setcolor( cColor )
   @ y1, x1, y1 + nRows - 1, x1 + nCols + 4 BOX "�Ŀ����� "
   @ y1, x1 + Int( ( nCols - Len( title ) ) / 2 ) SAY title         

   FOR i := 1 TO Len( aGets )
      aGets[ i, 3 ] := Iif( aGets[ i, 3 ] = Nil, Space( 200 ), Iif( Valtype( aGets[ i, 3 ] ) = "C", Padr( aGets[ i, 3 ], 200 ), aGets[ i, 3 ] ) )
      @ y1 + 1 + i, x1 + 2          SAY aGets[ i, 1 ]                                                                   
      @ y1 + 1 + i, x1 + nCols1 + 3 GET aGets[ i, 3 ] PICTURE Iif( aGets[ i, 2 ] <> Nil, aGets[ i, 2 ], "@S30" )        
   NEXT
   READ

   Setcolor( oldc )
   Restscreen( y1, x1, y1 + nRows - 1, x1 + nCols + 4, bufscr )

RETURN ( Lastkey() != 27 )

FUNCTION ASUM( ms1, n1, n2 )

LOCAL rez := 0

   n1 := Iif( n1 = Nil, 1, n1 )
   n2 := Iif( n2 = Nil, Len( ms1 ), n2 )
   Aeval( ms1, { | value | rez += value }, n1, n2 )

RETURN rez

FUNCTION DosToWin( stroka )

LOCAL i, slen := Len( stroka ), ia
   FOR i := 1 TO slen
      ia := Asc( Substr( stroka, i, 1 ) )
      IF ia >= 128 .AND. ia <= 159
         stroka := Stuff( stroka, i, 1, Chr( ia + 64 ) )
      ELSEIF ia >= 160 .AND. ia <= 175
         stroka := Stuff( stroka, i, 1, Chr( ia + 64 ) )
      ELSEIF ia >= 224 .AND. ia <= 239
         stroka := Stuff( stroka, i, 1, Chr( ia + 16 ) )
      ELSEIF ia == 241
         stroka := Stuff( stroka, i, 1, Chr( 184 ) )
      ENDIF
   NEXT
RETURN stroka

FUNCTION WinToDos( stroka )

LOCAL i, slen := Len( stroka ), ia
   FOR i := 1 TO slen
      ia := Asc( Substr( stroka, i, 1 ) )
      IF ia >= 192 .AND. ia <= 223
         stroka := Stuff( stroka, i, 1, Chr( ia - 64 ) )
      ELSEIF ia >= 224 .AND. ia <= 239
         stroka := Stuff( stroka, i, 1, Chr( ia - 64 ) )
      ELSEIF ia >= 240 .AND. ia <= 255
         stroka := Stuff( stroka, i, 1, Chr( ia - 16 ) )
      ELSEIF ia == 184
         stroka := Stuff( stroka, i, 1, Chr( 241 ) )
      ENDIF
   NEXT
RETURN stroka

PROCEDURE ReadParam( _par1, _par2, _par3 )

LOCAL i, vartmp

   FOR i := 1 TO 3
      vartmp := Iif( i == 1, _par1, Iif( i == 2, _par2, _par3 ) )
      IF vartmp != Nil
         m->mypath := vartmp
      ENDIF
   NEXT
RETURN

FUNCTION StrOut( y, x, stroka )

   @ y, x SAY stroka         
RETURN .T.

FUNCTION ASCAN2( arr, value, n )

   IF n == Nil; n := 1; ENDIF
RETURN Ascan( arr, { | a | a[ n ] == value } )

FUNCTION ASUM2( arr, nItem )

LOCAL nSum := 0
   Aeval( arr, { | a | nSum += a[ nItem ] } )
RETURN nSum

FUNCTION ASUMA( arr1, arr2, n1, n2, ab )
LOCAL i

   n2 := Iif( n2 = Nil, Len( arr1 ), n2 )
   IF arr2 == Nil
      FOR i := Iif( n1 = Nil, 1, n1 ) TO n2
         IF arr1[i] == Nil .OR. Valtype( arr1[i] ) == "N"
            arr1[i] := 0
         ELSEIF Valtype( arr1[i] ) == "A"
            AsumA( arr1[i] )
         ENDIF
      NEXT
   ELSE
      FOR i := Iif( n1 = Nil, 1, n1 ) TO n2
         IF arr1[i] == Nil
            arr1[i] := 0
         ELSEIF Valtype( arr1[i] ) == "A"
            AsumA( arr1[i], arr2[i],,, ab )
         ENDIF
         IF Valtype( arr2[i] ) == "N"
            IF ab != Nil
               arr1[i] += Eval( ab[1], arr2[i], Iif( Len(ab)>1, ab[2], Nil ) )
            ELSE
               arr1[i] += arr2[i]
            ENDIF
         ENDIF
      NEXT
   ENDIF

RETURN .T.

FUNCTION AisEmpty( arr, n1, n2, lRecur )
Local i

   IF Empty(n1); n1 := 1; ENDIF
   IF Empty(n2)
      n2 := Len(arr)
   ELSE
      n2 := n2 -n1 + 1
   ENDIF
   IF lRecur == Nil; lRecur := .F.; ENDIF
   FOR i := n1 TO n2
      IF lRecur .AND. Valtype( arr[i] ) == "A"
         IF !AisEmpty( arr[i],,, lRecur )
            RETURN .F.
         ENDIF
      ELSEIF !Empty( arr[i] )
         RETURN .F.
      ENDIF
   NEXT
RETURN .T.

FUNCTION AGetEl1( arr, x1 )
   LOCAL n := Ascan( arr, {|a|a[1]==x1} )
   
RETURN Iif( n==0, Nil, arr[n,2] )

FUNCTION RedirOn( fname )

   Set( 19, fname, .F. )
   Set( 18, "ON" )
   Set( 17, "OFF" )
RETURN Nil

FUNCTION RedirOff( fname )

   Set( 17, "ON" )
   Set( 18, "OFF" )
   Set( 19, "" )
   RETURN Nil

#ifdef __HARBOUR__
FUNCTION Mash_Nam()

   RETURN Netname()
#endif

FUNCTION XRound( nValue, nDigits )

LOCAL nMul   := Val( "1" + Replicate( "0", nDigits + 1 ) )
LOCAL cValue

   nValue := Int( nValue * nMul + 0.00000001 )
   cValue := Str( nValue )
   nValue := Val( Left( cValue, Len( cValue ) - 1 ) )

   IF Right( cValue, 1 ) >= '5'
      nValue ++
   ENDIF

RETURN Round( nValue * 10 / nMul, nDigits )

FUNCTION StrN2Arr( stroka )

LOCAL arr := {}, pos

   stroka := Ltrim( Rtrim( stroka ) )
   DO WHILE !Empty( stroka )
      pos := At( ',', stroka )
      IF pos == 0
         pos := Len( stroka ) + 1
      ENDIF
      Aadd( arr, Val( Trim( Left( stroka, pos - 1 ) ) ) )
      stroka := Substr( stroka, pos + 1 )
   ENDDO

RETURN arr

FUNCTION EXECUTE( expres )

LOCAL vartmp, poz
PRIVATE pend := .T.

   DO WHILE pend
      poz := FIND_Z( expres )
      IF poz <> 0
         vartmp := &( Substr( expres, 1, poz - 1 ) )
         expres := Substr( expres, poz + 1 )
      ELSE
         IF .NOT. Empty( expres )
            vartmp := &expres
            EXIT
         ENDIF
      ENDIF
   ENDDO
RETURN vartmp

FUNCTION FCHOICE( forms, y1, x1, color1, colorv, title, lNoSohr )
LOCAL i, x2, y2, lennm, kolforms := Len( forms ), lMulti := ( !Empty(forms).AND.Valtype( forms[ 1 ] ) == "A" )
LOCAL xmin   := Iif( x1 == Nil, 70, 78 - x1 ), ymin := Iif( y1 == Nil, 16, 23 - y1 )
LOCAL mslist := InitArEdit()

   IF lNoSohr != Nil .AND. lNoSohr
      LI_LSOHR := .F.
   ENDIF
   LI_CLR  := Iif( color1 == Nil, "W+/GR", color1 )
   LI_CLRV := Iif( colorv == Nil, "R/W", colorv )

   lennm := Iif( title != Nil, Len( title ), 0 )
   FOR i := 1 TO kolforms
      lennm := Max( lennm, Len( Iif( lMulti, forms[ i, 1 ], forms[ i ] ) ) )
   NEXT
   lennm := Min( lennm, xmin )

   IF x1 == Nil
      x1 := Int( ( 76 - lennm ) / 2 )
   ENDIF
   x2       := x1 + lennm + 4
   kolforms := Min( kolforms, ymin )
   IF y1 == Nil
      y1 := Int( ( 20 - kolforms ) / 2 )
   ENDIF
   y2 := y1 + kolforms + 1

   IF lMulti
      IF Valtype( forms[1,2] ) == "L"
         LI_MSF := { {|mslist| Iif(LI_MSREC[LI_TEKZP,2],"[X]","[ ]")},{|mslist| LI_MSREC[LI_TEKZP,1]} }
         LI_MSTYP := { "C","C" }
         LI_MSLEN := { 3,lennm }
         x2 += 5
         DO WHILE .T.
            i := Arlist( mslist, y1, x1, y2, x2, forms, title, { 32 } )
            IF i == 32
               LI_MSREC[LI_TEKZP,2] := !LI_MSREC[LI_TEKZP,2]
            ELSEIF i == 0
               RETURN 0
            ELSE
               RETURN LI_TEKZP
            ENDIF
         ENDDO
      ELSE
         LI_MSF := { {|mslist| LI_MSREC[LI_TEKZP,1]} }
      ENDIF
   ELSE
      LI_MSF := { { | mslist | LI_MSREC[ LI_TEKZP ] } }
   ENDIF
   LI_MSTYP := { "C" }
   LI_MSLEN := { lennm }

RETURN Iif( Arlist( mslist, y1, x1, y2, x2, forms, title ) == 0, 0, LI_TEKZP )

FUNCTION TRN_NUM( xNum, nDec, cRzd )
LOCAL cNum, i

   IF cRzd == Nil; cRzd := " "; ENDIF
   IF Valtype( xNum ) == "N"
      IF nDec == Nil
         xNum := Str( xNum )
      ELSE
         xNum := Str( xNum,19,nDec )
      ENDIF
   ENDIF
   xNum := Ltrim( xNum )
   IF ( i := Rat( ".",xNum ) ) == 0
      cNum := ""
      i := Len( xNum )
   ELSE
      cNum := Substr( xNum, i )
      i --
   ENDIF

   DO WHILE .T.
      i -= 3
      IF i <= 0
         cNum := Left( xNum, i+3 ) + cNum
         EXIT
      ELSE
         cNum := cRzd + Substr(xNum, i+1, 3 ) + cNum
      ENDIF
   ENDDO
RETURN cNum

